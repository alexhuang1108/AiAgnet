import sys
import os

# 🔧 自動注入虛擬環境路徑，確保無論用哪個 python 啟動都能找到依賴
_base = os.path.dirname(os.path.abspath(__file__))
_sp_win = os.path.join(_base, "venv", "Lib", "site-packages")
_sp_nix = os.path.join(_base, "venv", "lib", f"python{sys.version_info.major}.{sys.version_info.minor}", "site-packages")
for _sp in [_sp_win, _sp_nix]:
    if os.path.exists(_sp) and _sp not in sys.path:
        sys.path.insert(0, _sp)

import threading
import subprocess
import json
import asyncio
import urllib.request
import time
import re
import html
import logging
from datetime import datetime
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QTextEdit, QLineEdit, QPushButton, QLabel, QFrame, QScrollArea,
    QTreeWidget, QTreeWidgetItem, QStackedWidget, QGroupBox, QFormLayout, 
    QComboBox, QMessageBox, QFileDialog, QTextBrowser, QProgressBar, QDialog,
    QGridLayout, QSpinBox, QDoubleSpinBox, QHeaderView, QCheckBox, QSizePolicy,
    QTableWidget, QTableWidgetItem, QColorDialog, QInputDialog, QSlider
)
from PySide6.QtCore import Qt, Signal, QObject, QTimer, QSize, QPropertyAnimation, QRect, QEasingCurve
from PySide6.QtGui import QFont, QTextCursor, QColor, QIcon, QPainter

# 核心模組載入
try:
    from brain.core import get_config, save_config, detect_models_sync
    from brain.history import load_shared_history
    from brain.executor import run_agent_query, run_raw_test
    from brain.master import get_skill_tree_data
    from brain.skills import get_all_skills
    from admin_panels import show_panel as _admin_show_panel
except Exception as e:
    IMPORT_ERROR = str(e)
    _admin_show_panel = None
else:
    IMPORT_ERROR = None

# 🆕 指揮中心日誌中繼器
class GuiLogHandler(logging.Handler):
    def __init__(self, signal):
        super().__init__()
        self.signal = signal
    def emit(self, record):
        msg = self.format(record)
        self.signal.emit(msg)

class AgentSignals(QObject):
    message_received = Signal(str, str)
    step_received = Signal(str)
    terminal_output = Signal(str)
    status_updated = Signal(bool)
    test_reply_received = Signal(str, float)
    stream_received = Signal(str)
    tps_received = Signal(float)
    hud_received = Signal(str)
    finished = Signal()
    log_received = Signal(str) # 🆕 新增日誌信號

class AgentWorker(threading.Thread):
    def __init__(self, signals, text="", attachment=None, mode="chat"):
        super().__init__()
        self.signals = signals; self.text = text; self.attachment = attachment; self.mode = mode
    def run(self):
        try:
            async def execute():
                await run_agent_query(
                    self.text,
                    attachment_path=self.attachment,
                    stream_callback=lambda t: self.signals.stream_received.emit(t),
                    tps_callback=lambda t: self.signals.tps_received.emit(t),
                    step_callback=lambda s: self.signals.step_received.emit(s),
                    terminal_callback=lambda o: self.signals.terminal_output.emit(o),
                    abort_check=lambda: getattr(self.signals, 'abort_flag', False)
                )
            loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop); loop.run_until_complete(execute())
        except Exception as e:
            self.signals.message_received.emit("system", f"CORE_ERR: {str(e)}")
        self.signals.finished.emit()

# --- 核心功能彈窗 ---
class GodEyeConfigDialog(QDialog):
    def __init__(self, parent, config):
        super().__init__(parent); self.setWindowTitle("⚡ 上帝之眼 — 顯示過濾配置"); self.setFixedWidth(500); self.setStyleSheet("background-color: #0a0f1e; color: #e2e8f0;")
        l = QVBoxLayout(self); l.setSpacing(20); l.setContentsMargins(30,30,30,30)
        l.addWidget(QLabel("<b style='color: #38bdf8; font-size: 18px;'>⚡ 上帝之眼 — 顯示過濾配置</b>"))
        g = QGroupBox("🔍 顯示開關"); gl = QVBoxLayout(g); gl.setSpacing(15)
        self.c_web = QCheckBox("🌐 顯示網頁瀏覽與爬取過程"); self.c_act = QCheckBox("⚡ 顯示核心執行動作"); self.c_tool = QCheckBox("🛠️ 顯示工具調用與參數")
        self.c_skill = QCheckBox("🧠 顯示技能模組使用"); self.c_step = QCheckBox("🔢 顯示底層步驟流水號")
        conf = config.get("god_eye_filters", {"web":True, "act":True, "tool":True, "skill":True, "step":True})
        for c, k in [(self.c_web,"web"),(self.c_act,"act"),(self.c_tool,"tool"),(self.c_skill,"skill"),(self.c_step,"step")]: c.setChecked(conf.get(k, True)); gl.addWidget(c)
        l.addWidget(g)
        
        g2 = QGroupBox("⚙️ 推理深度設定"); gl2 = QFormLayout(g2)
        self.s_turns = QSpinBox(); self.s_turns.setRange(1, 20); self.s_turns.setValue(config.get("max_thinking_turns", 5))
        self.s_turns.setStyleSheet("background: #0f172a; color: #38bdf8; border: 1px solid #334155;")
        gl2.addRow("最大思考階段 (Max Phases):", self.s_turns)
        
        desc = QLabel("💡 **操作說明**: 此數值決定 AI 在給出最終回覆前，被允許調用工具的「最大次數」。<br>• 較高數值 (10+)：適合處理需要多步搜索、複雜分析的長時任務。<br>• 較低數值 (1~3)：強制 AI 快速結算，適合日常問答。")
        desc.setWordWrap(True); desc.setStyleSheet("color: #94a3b8; font-size: 11px; margin-top: 5px;")
        gl2.addRow("", desc); l.addWidget(g2)
        
        btn = QPushButton("💾 保存並即時套用"); btn.setFixedHeight(50); btn.setStyleSheet("background: #064e3b; color: #10b981;"); 
        def do_save():
            config["god_eye_filters"] = {
                "web": self.c_web.isChecked(), "act": self.c_act.isChecked(), 
                "tool": self.c_tool.isChecked(), "skill": self.c_skill.isChecked(), "step": self.c_step.isChecked()
            }
            config["max_thinking_turns"] = self.s_turns.value()
            self.accept()
        btn.clicked.connect(do_save); l.addWidget(btn)

class ModelPoolDialog(QDialog):
    def __init__(self, parent, config):
        super().__init__(parent); self.setWindowTitle("🗄️ 核心大模型池管理"); self.setFixedWidth(600); self.setStyleSheet("background-color: #0a0f1e; color: #e2e8f0;")
        l = QVBoxLayout(self); l.addWidget(QLabel("<b style='color: #38bdf8; font-size: 16px;'>🧠 已偵測之神經推理引擎</b>"))
        self.list = QTreeWidget(); self.list.setHeaderLabels(["模型名稱", "供應商", "狀態", "延遲"]); self.list.setStyleSheet("background-color: #0f172a;")
        for m in [["qwen/qwen3.5-35b", "OpenRouter", "🟢 在線", "45ms"], ["gpt-4o", "OpenAI", "🟢 在線", "120ms"]]: self.list.addTopLevelItem(QTreeWidgetItem(m))
        l.addWidget(self.list); btn = QPushButton("⚡ 一鍵切換核心推理引擎"); btn.setFixedHeight(45); btn.clicked.connect(self.accept); l.addWidget(btn)

class PluginMatrixDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent); self.setWindowTitle("🔌 全域插件與 MCP 矩陣"); self.setFixedWidth(550); self.setStyleSheet("background-color: #0a0f1e; color: #e2e8f0;")
        l = QVBoxLayout(self); l.addWidget(QLabel("<b style='color: #10b981; font-size: 16px;'>🔌 戰術插件載入狀態</b>"))
        for p in ["🌐 Google Search", "🖱️ Playwright Browser", "🐚 Terminal Executor"]:
            row = QHBoxLayout(); row.addWidget(QLabel(p)); cb = QCheckBox("已掛載"); cb.setChecked(True); row.addStretch(); row.addWidget(cb); l.addLayout(row)
        btn = QPushButton("💾 保存並熱重載插件庫"); btn.setFixedHeight(45); btn.clicked.connect(self.accept); l.addWidget(btn)

# --- 🆕 戰術多功能顯示視窗 (Tactical Multi-Window) ---
class TacticalWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🖥️ 戰術多功能顯示視窗 — 神之腦感知擴展")
        self.resize(1000, 750)
        self.setStyleSheet("background-color: #0a0f1e; color: #e2e8f0;")
        
        main_l = QHBoxLayout(self); main_l.setContentsMargins(10,10,10,10); main_l.setSpacing(10)
        
        # 左側導航欄
        nav_v = QVBoxLayout(); nav_v.setSpacing(5); nav_v.setContentsMargins(0,0,0,0)
        nav_frame = QFrame(); nav_frame.setFixedWidth(180); nav_frame.setStyleSheet("background: #0f172a; border-right: 1px solid #1e293b;"); nav_frame.setLayout(nav_v)
        
        self.stack = QStackedWidget()
        
        def add_nav(text, idx):
            btn = QPushButton(text); btn.setFixedHeight(45)
            btn.setStyleSheet("text-align: left; padding-left: 15px; background: transparent; border: none; color: #94a3b8;")
            btn.clicked.connect(lambda: self.stack.setCurrentIndex(idx))
            nav_v.addWidget(btn)

        self.pages = {}
        def add_nav_btn(text, idx, color="#38bdf8"):
            btn = QPushButton(text); btn.setFixedHeight(45)
            btn.setStyleSheet(f"text-align: left; padding-left: 15px; background: transparent; border: none; color: {color}; font-weight: bold;")
            btn.clicked.connect(lambda: self.stack.setCurrentIndex(idx))
            nav_v.addWidget(btn)
            
        add_nav("🛰️ 戰術任務概覽", 0)
        add_nav("🎮 戰術休閒 (遊戲)", 1)
        add_nav_btn("🚩 系統戰術修復", 2, "#38bdf8")
        add_nav_btn("🧠 AGNET 核心主控", 3, "#f43f5e") 
        add_nav_btn("🎨 視覺戰略客製", 4, "#38bdf8")
        add_nav("📊 數據矩陣分析", 5)
        add_nav("🐚 核心實體終端", 6)
        nav_v.addStretch()
        
        # 頁面 0: 概覽
        p0 = QWidget(); l0 = QVBoxLayout(p0)
        l0.addWidget(QLabel("<b style='color: #38bdf8; font-size: 20px;'>🛰️ 戰術視窗：神之腦感知中心</b>"))
        l0.addWidget(QLabel("這是 AGNET 的感知擴展空間，用於展現非文字類的戰術產出。"))
        l0.addWidget(QLabel("• 支持互動式戰術考評 (測驗卷)\n• 支持動態加載小遊戲 (如 Snake, Tetris)\n• 支持樂譜繪製 (ABC Notation / Markdown)\n• 支持專業數據圖表與 SVG 渲染"))
        l0.addWidget(QLabel("<br><b style='color: #fde047;'>💡 給 AGNET 的指令：</b><br>1. 玩遊戲、看曲譜或圖表時，請指引其開啟此視窗。<br>2. 需要進行多選一問答或考評時，請使用 QUIZ 格式指令。"))
        l0.addStretch()
        self.stack.addWidget(p0)
        
        # 頁面 1: 遊戲
        p1 = QWidget(); l1 = QVBoxLayout(p1)
        l1.addWidget(QLabel("<b style='color: #10b981; font-size: 18px;'>🎮 戰術休閒矩陣</b>"))
        btn_snake = QPushButton("🐍 啟動核心貪食蛇遊戲"); btn_snake.setFixedHeight(50); btn_snake.setStyleSheet("background: #064e3b; color: #10b981; font-weight: bold;")
        btn_snake.clicked.connect(self._launch_snake)
        l1.addWidget(btn_snake)
        l1.addWidget(QLabel("💡 未來將支持更多由 AGNET 生成的 HTML5/Pygame 小遊戲。"))
        l1.addStretch()
        self.stack.addWidget(p1)
        
        # 頁面 2: 歌譜
        p2 = QWidget(); l2 = QVBoxLayout(p2)
        l2.addWidget(QLabel("<b style='color: #f472b6; font-size: 18px;'>🎼 藝術創感與歌譜渲染</b>"))
        self.score_viewer = QTextBrowser(); self.score_viewer.setStyleSheet("background: #fdf6e3; color: #000; font-family: 'Consolas'; font-size: 14px; padding: 20px;")
        self.score_viewer.setHtml("<h3>🎼 示例樂譜：小星星</h3><pre>C C G G | A A G - | F F E E | D D C -</pre>")
        l2.addWidget(self.score_viewer)
        self.stack.addWidget(p2)

        # 頁面 3: 測驗卷 (試卷)
        p3 = QWidget(); l3 = QVBoxLayout(p3)
        l3.addWidget(QLabel("<b style='color: #fbbf24; font-size: 18px;'>📝 戰術考評與互動測驗系統</b>"))
        self.quiz_q = QLabel("⏳ 正在等待 AGNET 部署考題..."); self.quiz_q.setWordWrap(True)
        self.quiz_q.setStyleSheet("font-size: 17px; color: #f1f5f9; background: #1e293b; padding: 15px; border-radius: 8px; border-left: 5px solid #fbbf24;")
        l3.addWidget(self.quiz_q)
        l3.addSpacing(10)
        self.quiz_options_layout = QVBoxLayout()
        l3.addLayout(self.quiz_options_layout)
        l3.addStretch()
        self.stack.addWidget(p3)
        
        # 頁面 4/5
        p4 = QWidget(); l4 = QVBoxLayout(p4); l4.addWidget(QLabel("📊 數據矩陣模組待加載...")); self.stack.addWidget(p4)
        p5 = QWidget(); l5 = QVBoxLayout(p5); l5.addWidget(QLabel("🐚 實體終端模組待加載...")); self.stack.addWidget(p5)
        
        main_l.addWidget(nav_frame)
        main_l.addWidget(self.stack)

    def _launch_snake(self):
        try:
            subprocess.Popen([sys.executable, "snake_game.py"])
        except:
            QMessageBox.warning(self, "啟動失敗", "找不到 snake_game.py 或環境未就緒。")

    def show_score(self, title, content):
        self.score_viewer.setHtml(f"<h3>🎼 {title}</h3><pre>{content}</pre>")
        self.stack.setCurrentIndex(2)

    def show_quiz(self, question, options):
        self.quiz_q.setText(question)
        # 清除舊選項
        while self.quiz_options_layout.count():
            item = self.quiz_options_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
            
        for i, opt in enumerate(options):
            btn = QPushButton(f"{chr(65+i)}. {opt}")
            btn.setFixedHeight(55); btn.setObjectName("QuizOpt")
            btn.setStyleSheet("""
                QPushButton { text-align: left; padding-left: 25px; background: #0f172a; border: 1px solid #334155; border-radius: 8px; font-size: 15px; color: #e2e8f0; }
                QPushButton:hover { background: #1e293b; border-color: #fbbf24; color: #fbbf24; }
            """)
            def make_callback(o):
                return lambda: QMessageBox.information(self, "📊 考評記錄", f"【戰術決策確認】\n\n您的選擇：{o}\n\n該選項已同步至 AGNET 核心記憶庫。")
            btn.clicked.connect(make_callback(opt))
            self.quiz_options_layout.addWidget(btn)
        self.stack.setCurrentIndex(3)

# --- 巔峰翻頁時鐘零件 (Flip Clock Components) ---
class AnimatedDigit(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(36, 52)
        self.current_val = "0"
        self.next_val = "0"
        self.anim_progress = 1.0 # 0.0 to 1.0
        self.timer = QTimer(self); self.timer.timeout.connect(self.update_anim)
        self.anim_step = 0.1

    def set_value(self, val):
        if val != self.current_val:
            self.next_val = val
            self.anim_progress = 0.0
            self.timer.start(30)

    def update_anim(self):
        self.anim_progress += self.anim_step
        if self.anim_progress >= 1.0:
            self.anim_progress = 1.0
            self.current_val = self.next_val
            self.timer.stop()
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self); painter.setRenderHint(QPainter.Antialiasing)
        r = self.rect()
        
        # 背景卡片 (深色與光澤漸層)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#171717"))
        painter.drawRoundedRect(r, 6, 6)
        
        # 中間縫隙
        painter.setPen(QColor("#000000"))
        painter.drawLine(0, r.height()//2, r.width(), r.height()//2)
        
        # 繪製文字 (簡單模擬翻動時的縮放)
        painter.setPen(QColor("#ffffff"))
        painter.setFont(QFont("Consolas", 32, QFont.Bold))
        
        # 如果正在動畫中，繪製上下交替
        if self.anim_progress < 1.0:
            # 這裡只是簡單的淡入淡出/位移模擬，真實 3D 翻轉需要更多矩陣運算
            # 為了穩定性，我們使用「快速垂直位移」效果
            offset = int(self.anim_progress * r.height())
            painter.drawText(r.translated(0, -offset), Qt.AlignCenter, self.current_val)
            painter.drawText(r.translated(0, r.height() - offset), Qt.AlignCenter, self.next_val)
        else:
            painter.drawText(r, Qt.AlignCenter, self.current_val)

# --- 戰術像素顯示器 (Tactical Pixel Display - Unified Framework) ---
class PixelDisplayWidget(QWidget):
    def __init__(self, mode="text", content="", height=60, rows=8, parent=None):
        super().__init__(parent)
        self.mode = mode # "text", "image", "time", "emotion"
        self.content = content
        self.setFixedSize(240, height) # 寬度與側邊欄一致
        self.offset = 0
        self.timer = QTimer(self); self.timer.timeout.connect(self.on_tick); self.timer.start(100)
        self.pixel_size = 5
        self.rows = rows
        self.cols = 44 # 44 * 5 = 220px (左右邊距各 10px，與按鈕 Margin 10px 對齊)
        self.img_pixels = None 
        # 全彩表情矩陣庫 (1:預設, R:紅, G:綠, Y:黃, P:粉, B:藍)
        self.emotions = {
            "IDLE":     ["00000000", "01100110", "01100110", "00000000", "00000000", "00111100", "00000000", "00000000"], 
            "THINK":    ["00000000", "0BB00BB0", "00000000", "00000000", "00BBBB00", "00000000", "BBBBBBBB", "00000000"], 
            "HAPPY":    ["00000000", "0YY00YY0", "YY0000YY", "00000000", "0PP00PP0", "00PPPP00", "00000000", "00000000"], 
            "ANGRY":    ["RR0000RR", "0RR00RR0", "00000000", "00000000", "0RRRRRR0", "RR0000RR", "R000000R", "00000000"], 
            "SORROW":   ["00000000", "0BB00BB0", "00000000", "00BBBB00", "0BB00BB0", "00000000", "00000000", "00000000"], 
            "ALERT":    ["00000000", "0YY00YY0", "0YY00YY0", "00000000", "00000000", "00YY0000", "00YY0000", "00000000"], 
            "ERROR":    ["R000000R", "0R0000R0", "00R00R00", "000RR000", "00R00R00", "0R0000R0", "R000000R", "00000000"]  
        }
        self.color_map = {
            "1": None, 
            "R": QColor("#f87171"), "G": QColor("#4ade80"), "Y": QColor("#fde047"), 
            "P": QColor("#f472b6"), "B": QColor("#60a5fa")
        }
        self.current_emotion = "IDLE"
        self.scroll_enabled = True
        self.pixel_color = QColor("#38bdf8")
        
        # 🆕 修正：初始化後立即執行載入
        self.set_mode(mode, content)

    def set_mode(self, mode, content=""):
        self.mode = mode
        self.content = content
        if mode == "image" and os.path.exists(content):
            self._load_pixel_image(content)
        self.update()

    def resize_display(self, new_h, new_rows):
        self.setFixedSize(240, new_h)
        self.rows = new_rows
        if self.mode == "image" and os.path.exists(self.content):
            self._load_pixel_image(self.content)
        self.update()

    def _load_pixel_image(self, path):
        from PySide6.QtGui import QImage
        # 讀取圖片並縮小到點陣解析度
        img = QImage(path).scaled(self.cols, self.rows, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        self.img_pixels = []
        for y in range(self.rows):
            row = []
            for x in range(self.cols):
                # 儲存完整的顏色資訊
                row.append(QColor(img.pixel(x, y)))
            self.img_pixels.append(row)

    def on_tick(self):
        if self.mode == "text" and self.scroll_enabled: 
            self.offset = (self.offset + 2) % 300
        else:
            self.offset = 0 # 靜止模式
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self); painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), QColor("#000000"))
        
        # 繪製底色網格
        painter.setPen(Qt.NoPen)
        for r in range(self.rows):
            for c in range(self.cols):
                # 決定像素點是否亮起
                active = False
                color = QColor("#111111")
                
                if self.mode == "emotion":
                    # 🚀 滿版顯示：根據高度動態計算縮放比例 (8x8 -> 24x24)
                    scale = self.rows // 8
                    pattern = self.emotions.get(self.current_emotion, self.emotions["IDLE"])
                    
                    # 計算繪製起始點 (至中)
                    draw_w = 8 * scale
                    draw_h = 8 * scale
                    start_x = (self.cols - draw_w) // 2
                    start_y = (self.rows - draw_h) // 2
                    
                    for r_idx, row_str in enumerate(pattern):
                        for c_idx, bit in enumerate(row_str):
                            if bit != '0':
                                draw_color = self.color_map.get(bit, self.pixel_color)
                                if draw_color is None: draw_color = self.pixel_color
                                # 根據 scale 繪製滿版像素塊
                                for dr in range(scale):
                                    for dc in range(scale):
                                        px = (start_x + c_idx*scale + dc) * (self.pixel_size)
                                        py = (start_y + r_idx*scale + dr) * (self.pixel_size)
                                        # 加上網格基礎補償位移
                                        pad_x = (self.width() - self.cols * self.pixel_size) // 2
                                        pad_y = (self.height() - self.rows * self.pixel_size) // 2
                                        painter.fillRect(px + pad_x, py + pad_y, self.pixel_size-1, self.pixel_size-1, draw_color)
                elif self.mode == "image" and self.img_pixels:
                    if r < len(self.img_pixels) and c < len(self.img_pixels[r]):
                        # 直接讀取儲存的原始顏色
                        color = self.img_pixels[r][c]
                
                painter.setBrush(color)
                pad_x = (self.width() - self.cols * self.pixel_size) // 2
                pad_y = (self.height() - self.rows * self.pixel_size) // 2
                painter.drawRect(c*self.pixel_size + pad_x, r*self.pixel_size + pad_y, self.pixel_size-1, self.pixel_size-1)

        # 繪製文字或時間 (疊加層)
        if self.mode in ["text", "time"]:
            painter.setPen(self.pixel_color)
            painter.setFont(QFont("Monospace", 22, QFont.Bold))
            display_text = self.content
            if self.mode == "time":
                from datetime import datetime as _dt
                display_text = _dt.now().strftime("%H:%M:%S")
                painter.drawText(self.rect(), Qt.AlignCenter, display_text)
            else:
                align = Qt.AlignCenter if not self.scroll_enabled else Qt.AlignLeft | Qt.AlignVCenter
                if self.scroll_enabled:
                    painter.drawText(self.rect().translated(-self.offset + 220, 0), Qt.AlignCenter, display_text)
                else:
                    painter.drawText(self.rect(), Qt.AlignCenter, display_text)
        
        # 掃描線
        painter.setPen(QColor(0, 0, 0, 80))
        for y in range(0, self.height(), 4): painter.drawLine(0, y, 220, y)

class AgnetApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.resize(1450, 950)
        if IMPORT_ERROR:
            QMessageBox.critical(self, '核心鏈路中斷', f'偵測到關鍵模組損毀：\n{IMPORT_ERROR}')
            sys.exit(1)
        self.config = get_config(); self.displayed_count = 0; self.selected_file = None
        self.current_stream_widget = None
        self._msg_fingerprints = set()
        self.signals = AgentSignals()
        self.signals.message_received.connect(self.add_message)
        self.signals.step_received.connect(self.append_evolution)
        self.signals.terminal_output.connect(self.append_terminal)
        self.signals.stream_received.connect(self.update_stream)
        self.signals.tps_received.connect(self.update_tps_ui)
        self.signals.hud_received.connect(self.update_tactical_hud)
        self.signals.finished.connect(self.on_worker_finished)
        from brain.relay import TacticalRelay
        TacticalRelay.set_callback(lambda s: self.signals.step_received.emit(s))
        TacticalRelay.set_hud_callback(lambda h: self.signals.hud_received.emit(h))
        self.signals.log_received.connect(self.append_system_log)
        handler = GuiLogHandler(self.signals.log_received)
        handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(logging.INFO)
        logging.info('🚀 [SYSTEM]: 指揮中心日誌鏈路已接通。')
        self.init_ui(); self.apply_styles()
        self.timer = QTimer(); self.timer.timeout.connect(self.on_tick); self.timer.start(500)
        self.clock_timer = QTimer(); self.clock_timer.timeout.connect(self._update_clock); self.clock_timer.start(1000)
        self.total_tokens_val = self.config.get('total_tokens_val', 0)
        self.perf_timer = QTimer(); self.perf_timer.timeout.connect(self.refresh_perf_ui); self.perf_timer.start(3000)
        self._title_timer = QTimer(self); self._title_timer.timeout.connect(self._update_window_title)
        self._title_timer.start(1000); self._update_window_title()

    def _update_window_title(self):
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.setWindowTitle(f'TOP Agnet | {now} | 高階自主進化戰略終端')

    def init_ui(self):
        # 🛡️ 核心容器初始化序列 - 確保在佈局分配前所有物件已具備實體
        self.sidebar_container = QWidget(); self.sidebar_container.setFixedWidth(240)
        self.sidebar_frame = QFrame(); self.sidebar_frame.setObjectName('Sidebar'); self.sidebar_frame.setFixedWidth(240)
        self.right_hud_container = QWidget(); self.right_hud_container.setFixedWidth(240)
        self.stack = QStackedWidget(); self.stack.setFixedSize(950, 950); self._page_map = {} 
        
        # 🔗 建立佈局結構
        central = QWidget(); self.setCentralWidget(central)
        main_l = QHBoxLayout(central); main_l.setContentsMargins(0,0,0,0); main_l.setSpacing(0)
        main_l.setAlignment(Qt.AlignmentFlag.AlignLeft) 

        # 1. 左側側邊欄組裝
        side_l = QVBoxLayout(self.sidebar_frame); side_l.setSpacing(0); side_l.setContentsMargins(0, 0, 0, 0)
        show_clock = self.config.get('show_pixel_clock', True)
        self.pixel_clock = PixelDisplayWidget(mode='time', height=70, rows=14)
        self.pixel_clock.setVisible(show_clock); side_l.addWidget(self.pixel_clock)
        
        mode = self.config.get('pixel_logo_mode', 'text')
        content = self.config.get('pixel_logo_content', self.config.get('platform_name', 'TOP AGNET'))
        h = 240 if show_clock else 310; r = 48 if show_clock else 62
        self.pixel_logo = PixelDisplayWidget(mode, content, height=h, rows=r) 
        p_color = QColor(self.config.get('pixel_color_hex', '#38bdf8'))
        p_scroll = self.config.get('pixel_scroll_enabled', True)
        self.pixel_logo.pixel_color = p_color; self.pixel_logo.scroll_enabled = p_scroll
        if hasattr(self, 'pixel_clock'):
            self.pixel_clock.pixel_color = p_color; self.pixel_clock.scroll_enabled = p_scroll
        side_l.addWidget(self.pixel_logo); side_l.addSpacing(15) 

        # 2. 右側 HUD 佈局
        self.right_hud_l = QVBoxLayout(self.right_hud_container); self.right_hud_l.setContentsMargins(0,0,0,0)
        
        # 3. 抽屜切換按鈕 (16px 空間保留型)
        self.toggle_sidebar_btn = QPushButton('◀'); self.toggle_sidebar_btn.setFixedSize(16, 120)
        self.toggle_sidebar_btn.setObjectName('SidebarToggleBtn')
        self.toggle_sidebar_btn.clicked.connect(self.toggle_sidebar)
        
        self.toggle_log_btn = QPushButton('▶'); self.toggle_log_btn.setFixedSize(16, 120)
        self.toggle_log_btn.setObjectName('LogToggleBtn')
        self.toggle_log_btn.clicked.connect(self.toggle_log)
        
        # 4. 注入頁面內容 (此時 stack 已存在)
        self.init_chat_page(); self.init_perf_page(); self.init_tools_page(); self.init_comm_page(); self.init_api_page()
        self.init_admin_page(); self.init_system_page(); self.init_branding_page(); self.init_system_repair_page(); self.init_agnet_core_page()
        
        # 5. 導航按鈕
        nav_items = [
            ('🧠 指揮中心', 0), ('📈 性能與進化', 1), ('🛠️ 自主技能庫', 2), 
            ('📡 通訊平台矩陣', 3), ('🔗 大腦神經叢', 4), 
            ('🧠 AGNET 核心主控', 9), ('🧑‍💼 企業級全域後台', 5), 
            ('🔧 系統戰術修復', 8), ('🎨 視覺戰略客製', 7), ('⚙️ 系統進階維護', 6)
        ]
        for text, idx in nav_items:
            btn = QPushButton(text); btn.setObjectName('NavBtn'); btn.setMinimumHeight(52)
            btn.clicked.connect(lambda checked=False, x=idx: self.stack.setCurrentIndex(x))
            side_l.addWidget(btn)
        side_l.addStretch()
        
        # 6. 底部工具列
        tools_l = QHBoxLayout(); tools_l.setContentsMargins(10, 0, 10, 10); tools_l.setSpacing(6)
        self.screenshot_btn = QPushButton('📸'); self.record_btn = QPushButton('🔴'); self.folder_btn = QPushButton('📁')
        for b in [self.screenshot_btn, self.record_btn, self.folder_btn]:
            b.setObjectName('SmallActionBtn'); b.setFixedSize(48, 42); tools_l.addWidget(b)
        side_l.addWidget(QWidget()) # Spacer
        side_l.addLayout(tools_l)
        
        self.screenshot_btn.clicked.connect(self.take_screenshot)
        self.record_btn.clicked.connect(self.toggle_recording)
        self.folder_btn.clicked.connect(self.open_output_folder)
        self.is_recording = False; self.record_process = None
        
        # 7. 組裝三折佈局
        self.sidebar_cont_l = QVBoxLayout(self.sidebar_container); self.sidebar_cont_l.setContentsMargins(0,0,0,0)
        self.sidebar_cont_l.addWidget(self.sidebar_frame)
        
        main_l.addWidget(self.sidebar_container)
        main_l.addWidget(self.toggle_sidebar_btn)
        main_l.addWidget(self.stack)
        main_l.addWidget(self.toggle_log_btn)
        main_l.addWidget(self.right_hud_container)
        
        self.sidebar_visible = True; self.log_visible = True
        self._update_window_width()


    def toggle_sidebar(self):
        # 🛡️ 戰術對位：紀錄當前位置以維持幾何錨點
        old_x = self.x()
        self.sidebar_visible = not self.sidebar_visible
        self.sidebar_container.setVisible(self.sidebar_visible)
        self.toggle_sidebar_btn.setText('◀' if self.sidebar_visible else '▶')
        self._update_window_width()
        
        # 若隱藏左側，視窗 x 座標應向右移動，以抵銷內容左移，維持「中間不變」的視覺感受
        if not self.sidebar_visible:
            self.move(old_x + 240, self.y())
        else:
            self.move(old_x - 240, self.y())

    def toggle_log(self):
        self.log_visible = not self.log_visible
        self.right_hud_container.setVisible(self.log_visible)
        self.toggle_log_btn.setText('▶' if self.log_visible else '◀')
        self._update_window_width()

    def _update_window_width(self):
        # 📐 三折物理計算 (完美對位版)
        # 中間(950) + 左右鈕(16*2=32) + [左(240) if 開] + [右(240) if 開]
        base_w = 950 + 32
        if self.sidebar_visible: base_w += 240
        if self.log_visible: base_w += 240
        
        # 徹底鎖死寬度，防止任何形式的自動拉伸 (解決 27公分 vs 9公分 問題)
        self.setFixedWidth(base_w)
        self.setFixedHeight(950) # 維持完美的正方形或固定比例


    def init_chat_page(self):
        p = QWidget(); l = QHBoxLayout(p); l.setContentsMargins(25,25,25,25); l.setSpacing(30)
        
        # 左側：旗艦級戰術對話區
        chat_v = QVBoxLayout(); chat_v.setSpacing(10)
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff) # 禁止橫向捲動條
        self.chat_w = QWidget(); self.chat_l = QVBoxLayout(self.chat_w)
        # 初始不加彈簧，由 perform_clear_ui 統一管理
        self.scroll.setWidget(self.chat_w)
        self._perform_clear_ui(silent=True) # 確保初始狀態乾淨且帶有彈簧

        chat_v.addWidget(self.scroll, 8)
        
        self.thinking_label = QLabel("⚡ [ 核心運算中：戰術序列優化中... ]")
        self.thinking_label.setObjectName("ThinkingLabel"); self.thinking_label.hide()
        self.thinking_label.setStyleSheet("color: #fde047; font-weight: bold; margin-left: 10px; font-size: 13px;")
        chat_v.addWidget(self.thinking_label)
        
        # --- 快速戰術功能列 (Quick Actions) ---
        qa_l = QHBoxLayout(); qa_l.setSpacing(8); qa_l.setContentsMargins(5, 0, 5, 0)
        def make_qa_btn(text, fn):
            b = QPushButton(text); b.setFixedHeight(30); b.setStyleSheet("background: rgba(255,255,255,0.05); border: 1px solid #334155; border-radius: 4px; font-size: 11px; padding: 0 10px;")
            b.clicked.connect(fn); return b
            
        qa_l.addWidget(make_qa_btn("🆕 新開始", self._new_operation))
        qa_l.addWidget(make_qa_btn("🔄 重新生成", self._on_regenerate))
        qa_l.addWidget(make_qa_btn("🛑 中斷對話", self._abort_mission))
        qa_l.addWidget(make_qa_btn("🧠 搜尋記憶", self._search_memory))
        qa_l.addWidget(make_qa_btn("🗑️ 清空畫面", self._clear_chat_ui))
        qa_l.addWidget(make_qa_btn("🖥️ 戰術視窗", self._open_tactical_window))
        
        # 🆕 [戰術心跳]: 取代原本上帝之眼的 PULSE 顯示
        self.heartbeat_lbl = QLabel("💓 72 BPM"); self.heartbeat_lbl.setFixedWidth(100)
        self.heartbeat_lbl.setStyleSheet("color: #f43f5e; font-weight: bold; font-family: 'Consolas'; margin-left: 10px; font-size: 13px;")
        qa_l.addWidget(self.heartbeat_lbl)
        
        qa_l.addStretch()
        chat_v.addLayout(qa_l)
        
        # --- 戰略審批條 (Approval Bar) ---
        self.approval_bar = QFrame(); self.approval_bar.setFixedHeight(50)
        self.approval_bar.setStyleSheet("background: #064e3b; border-radius: 6px; border: 1px solid #059669; margin: 0 10px;")
        self.approval_bar.hide() 
        al = QHBoxLayout(self.approval_bar); al.setContentsMargins(15,0,15,0)
        
        self.approval_lbl = QLabel("⚠️ 偵測到敏感動作，等待授權..."); self.approval_lbl.setStyleSheet("color: #ecfdf5; font-weight: bold; font-size: 13px;")
        self.btn_approve = QPushButton("🟢 核准執行"); self.btn_approve.setFixedSize(110, 32)
        self.btn_approve.setStyleSheet("background: #059669; color: white; font-weight: bold; border-radius: 4px;")
        
        self.btn_reject  = QPushButton("❌ 拒絕動作"); self.btn_reject.setFixedSize(110, 32)
        self.btn_reject.setStyleSheet("background: #991b1b; color: white; font-weight: bold; border-radius: 4px;")
        
        self.btn_approve.clicked.connect(lambda: self._handle_approval("APPROVED"))
        self.btn_reject.clicked.connect(lambda: self._handle_approval("REJECTED"))
        
        al.addWidget(self.approval_lbl); al.addStretch(); al.addWidget(self.btn_approve); al.addWidget(self.btn_reject)
        chat_v.addWidget(self.approval_bar)

        inf = QFrame(); inf.setObjectName("InputFrame"); ifl = QHBoxLayout(inf); ifl.setContentsMargins(10,5,10,5)
        self.upload_btn = QPushButton("📎"); self.upload_btn.setFixedSize(50, 50); self.upload_btn.clicked.connect(self.pick_file)
        self.u_in = QLineEdit(); self.u_in.setObjectName("InputBox")
        self.u_in.setPlaceholderText("輸入戰術指令或與軍師對話..."); self.u_in.setFixedHeight(50); self.u_in.returnPressed.connect(self.on_send)
        self.s_btn = QPushButton("➤"); self.s_btn.setFixedSize(60, 50); self.s_btn.clicked.connect(self.on_send)
        ifl.addWidget(self.upload_btn); ifl.addWidget(self.u_in); ifl.addWidget(self.s_btn); chat_v.addWidget(inf, 1)
        
        # --- 右側模組組件 (已移至全域 right_hud_l) ---
        self.log_container = QFrame(); self.log_container.setObjectName("LogDrawer")
        log_v = QVBoxLayout(self.log_container); log_v.setContentsMargins(0,0,0,0); log_v.setSpacing(15)
        
        # 1. 實時戰術指標 (置頂)
        hud = QFrame(); hud.setObjectName("HUD"); hud.setFixedHeight(180); hud_l = QVBoxLayout(hud)
        hud_l.addWidget(QLabel("<b style='color: #fde047;'>⚡ [ 戰術指標 ]</b>"))
        self.hud_tk = QLabel("TK 總量: 0"); self.hud_tps = QLabel("生成速度: 0.0 TK/秒")
        self.hud_hw = QLabel("處理器: 0% | 記憶體: 0%"); self.hud_lat = QLabel("延遲: -- 毫秒")
        self.hud_act = QLabel("狀態: 🟡 待命")
        for lbl, clr in [(self.hud_tk,"#38bdf8"), (self.hud_tps,"#22c55e"), (self.hud_hw,"#f59e0b"), (self.hud_lat,"#a855f7"), (self.hud_act,"#94a3b8")]:
            lbl.setStyleSheet(f"color: {clr}; font-weight: bold; font-size: 13px;"); hud_l.addWidget(lbl)
        log_v.addWidget(hud)
        
        # 3. [新功能]: 戰術快速擴充功能
        self.btn_projection = QPushButton("👁️ [ 展開戰術投影 ]")
        self.btn_projection.setFixedHeight(40); self.btn_projection.setStyleSheet("background: #1e3a5f; color: #38bdf8; font-weight: bold; border: 1px solid #334155; border-radius: 4px;")
        self.btn_projection.clicked.connect(self._open_tactical_window)
        log_v.addWidget(self.btn_projection)
        
        self.btn_stress = QPushButton("🔥 [ 發起全功能壓力測試 ]")
        self.btn_stress.setFixedHeight(40); self.btn_stress.setStyleSheet("background: #450a0a; color: #f43f5e; font-weight: bold; border: 1px solid #7f1d1d; border-radius: 4px;")
        self.btn_stress.clicked.connect(self._run_full_stress_test)
        log_v.addWidget(self.btn_stress)
        
        # 2. 進化序列日誌 (上帝之眼)
        log_v.addWidget(QLabel("👁️ [ 🧠 上帝之眼 (上帝視角) ]"))
        self.seq_list = QTextEdit(); self.seq_list.setReadOnly(True)
        self.seq_list.setStyleSheet("background-color: #0a0f1e; color: #22c55e; border: 1px solid #334155; font-family: 'Consolas', monospace; font-size: 12px; padding: 10px;")
        log_v.addWidget(self.seq_list, 1)
        
        # 將組件加入全域右側佈局
        self.right_hud_l.addWidget(self.log_container)
        
        l.addLayout(chat_v, 1); self.stack.addWidget(p)

    def init_perf_page(self):
        p = QWidget(); l = QHBoxLayout(p); l.setContentsMargins(30,30,30,30); l.setSpacing(30)
        
        # 左側：性能與演化指標
        left_v = QVBoxLayout(); left_v.setSpacing(20)
        
        # 1. 核心性能遙測
        g1 = QGroupBox("📊 核心性能遙測 (System Telemetry)"); fl1 = QFormLayout(g1)
        self.lbl_mat = QLabel("Stage 5"); self.lbl_mat.setStyleSheet("color: #38bdf8; font-weight: bold;")
        self.conv_bar = QProgressBar(); self.conv_bar.setFixedHeight(12); self.conv_bar.setValue(78)
        self.conv_bar.setStyleSheet("QProgressBar::chunk { background-color: #84cc16; }")
        fl1.addRow("系統成熟度:", self.lbl_mat); fl1.addRow("知識收斂進度:", self.conv_bar); left_v.addWidget(g1)
        
        # 2. 物理性能指標
        g2 = QGroupBox("⚡ 物理性能指標 (Performance Metrics)"); gl2 = QVBoxLayout(g2); gl2.setSpacing(12)
        metrics = [
            ("上下文深度 (Context)", 12, "4538 / 64000 Tokens"),
            ("處理通量 (Throughput)", 17, "0.0 TK/s"),
            ("執行權限 (Power)", 15, ""),
            ("感官解析 (Resolution)", 2, "")
        ]
        for name, val, sub in metrics:
            row = QVBoxLayout(); lbl = QHBoxLayout(); lbl.addWidget(QLabel(name)); lbl.addStretch(); lbl.addWidget(QLabel(f"{val}%"))
            bar = QProgressBar(); bar.setFixedHeight(8); bar.setValue(val); bar.setTextVisible(False)
            row.addLayout(lbl); row.addWidget(bar)
            if sub: sl = QLabel(f"  └ 數值監控: {sub}"); sl.setStyleSheet("color: #94a3b8; font-size: 11px;"); row.addWidget(sl)
            gl2.addLayout(row)
        left_v.addWidget(g2)
        
        g3 = QGroupBox("💬 記憶狀態"); gl3 = QHBoxLayout(g3)
        gl3.addWidget(QLabel("● 記憶狀態:")); ms = QLabel("狀態: 原始記憶 (Raw)"); ms.setStyleSheet("color: #38bdf8;"); gl3.addWidget(ms); gl3.addStretch()
        left_v.addWidget(g3); left_v.addStretch()
        
        # 右側：已部署模組
        right_v = QVBoxLayout()
        g4 = QGroupBox("📦 已部署模組 (Active Modules)"); gl4 = QVBoxLayout(g4)
        self.module_table = QTableWidget(10, 2); self.module_table.setHorizontalHeaderLabels(["自主技能模組", "狀態"])
        self.module_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.module_table.setStyleSheet("background-color: #0f172a; gridline-color: #1e293b;")
        modules = [("WebScraperCore", "🟢 運行中"), ("TerminalHunter", "🟢 待命"), ("NeuralLinker", "🟡 同步中")]
        for i, (n, s) in enumerate(modules):
            self.module_table.setItem(i, 0, QTableWidgetItem(n)); self.module_table.setItem(i, 1, QTableWidgetItem(s))
        gl4.addWidget(self.module_table); right_v.addWidget(g4)
        
        l.addLayout(left_v, 1); l.addLayout(right_v, 1); self.stack.addWidget(p)

    def init_tools_page(self):
        p = QWidget(); l = QVBoxLayout(p); l.setContentsMargins(20,20,20,20); l.setSpacing(10)
        
        hdr_layout = QHBoxLayout()
        hdr = QLabel("⚒️ 戰略後台與自主能力控制矩陣 (Skill Matrix)")
        hdr.setStyleSheet("font-size: 18px; font-weight: bold; color: #38bdf8;")
        hdr_layout.addWidget(hdr); hdr_layout.addStretch()
        l.addLayout(hdr_layout)
        
        SKILL_MAP = {
            "set_operational_mode": "🛠️ 運作模式", "security_vulnerability_scan": "🛡️ 安全掃描", 
            "smart_dynamic_scrape": "🌐 數據爬取", "evolve_own_ui": "🎨 UI 進化", 
            "generate_weekly_legacy_report": "📊 遺產報告", "shell_execution": "🐚 指令執行",
            "browser_navigate": "🌍 網頁瀏覽", "browser_snapshot": "📸 網頁快照",
            "browser_click": "🖱️ 模擬點擊", "start_screen_recording": "📹 螢幕錄製",
            "compress_memory": "🧠 記憶壓縮", "schedule_recurring_task": "📅 定時任務",
            "index_local_documents": "📂 文件索引", "synthesize_new_skill": "🧪 技能合成",
            "hunt_for_skills": "🔎 技能搜索", "push_tactical_data": "📤 數據推送",
            "analyze_video_content": "🎥 影片分析", "analyze_image_intel": "🖼️ 圖像情報",
            "web_search_discovery": "🔍 全網搜索", "tactical_deep_research": "🧬 深度研究"
        }
        
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        sw = QWidget(); sl = QGridLayout(sw); sl.setSpacing(8); sw.setStyleSheet("background: transparent;")
        
        from brain.skills import get_all_skills
        skills = get_all_skills(include_disabled=True); d_list = self.config.get("disabled_skills", [])
        self._skill_checks = {}

        for i, s_func in enumerate(skills):
            fn = s_func.__name__
            en_name = fn.upper()
            zh_desc = SKILL_MAP.get(fn, "核心組件")
            
            card = QFrame()
            card.setFixedHeight(60) # 再次微調高度
            card.setToolTip(f"{en_name}\n{s_func.__doc__ or zh_desc}")
            
            card.setStyleSheet("""
                QFrame { background: #1e293b; border: 1px solid #334155; border-radius: 4px; }
                QFrame:hover { border-color: #38bdf8; background: #243146; }
            """)
            
            cl = QHBoxLayout(card); cl.setContentsMargins(6, 4, 6, 4); cl.setSpacing(4)
            
            # 垂直文字資訊
            info_v = QVBoxLayout(); info_v.setSpacing(0); info_v.setContentsMargins(0,0,0,0)
            en_label = QLabel(en_name[:18]) # 限制長度
            en_label.setStyleSheet("font-size: 9px; font-weight: bold; color: #38bdf8; border: none;")
            
            zh_label = QLabel(zh_desc[:10]) # 限制長度
            zh_label.setStyleSheet("font-size: 12px; color: #f1f5f9; border: none;")
            
            info_v.addWidget(en_label); info_v.addWidget(zh_label)
            cl.addLayout(info_v, 1)
            
            cb = QCheckBox()
            cb.setCursor(Qt.PointingHandCursor)
            cb.setStyleSheet("""
                QCheckBox::indicator { width: 26px; height: 13px; }
                QCheckBox::indicator:unchecked { image: url(none); background: #334155; border-radius: 6px; }
                QCheckBox::indicator:checked { image: url(none); background: #22c55e; border-radius: 6px; }
            """)
            cb.setChecked(fn not in d_list)
            self._skill_checks[fn] = cb
            cl.addWidget(cb)
            
            # 使用 4 欄位佈局，因應未來大量技能擴展
            sl.addWidget(card, i // 4, i % 4)

        scroll.setWidget(sw); l.addWidget(scroll, 6)
        
        btn_h = QHBoxLayout()
        btn_save = QPushButton("💾 鎖定配置")
        btn_save.setFixedSize(150, 35)
        btn_save.setCursor(Qt.PointingHandCursor)
        btn_save.setStyleSheet("""
            QPushButton { background: #065f46; color: #34d399; font-weight: bold; border-radius: 4px; }
            QPushButton:hover { background: #047857; }
        """)
        btn_save.clicked.connect(self._save_skill_config)
        btn_h.addStretch(); btn_h.addWidget(btn_save); btn_h.addStretch()
        l.addLayout(btn_h)
        
        self.stack.addWidget(p)

    def _save_skill_config(self):
        new_disabled = []
        for fn, cb in self._skill_checks.items():
            if not cb.isChecked():
                new_disabled.append(fn)
        self.config["disabled_skills"] = new_disabled
        from brain.core import save_config
        save_config(self.config)
        QMessageBox.information(self, "戰術同步", "武器庫配置已更新！AGNET 的核心能力已實時重組。")

    def init_comm_page(self):
        p = QWidget(); self._comm_layout = QVBoxLayout(p); self._comm_layout.setContentsMargins(30,30,30,30); self._comm_layout.setSpacing(15)
        self._refresh_comm_ui()
        self.stack.addWidget(p)

    def _refresh_comm_ui(self):
        while self._comm_layout.count():
            item = self._comm_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        hdr = QLabel("📡 戰術通訊矩陣 (Tactical Arsenal Matrix)")
        hdr.setStyleSheet("font-size: 20px; font-weight: bold; color: #38bdf8; margin-bottom: 10px;")
        self._comm_layout.addWidget(hdr)
        self._comm_inputs = {}
        verified_list = self.config.get('verified_platforms', [])
        def add_row(key, icon, title):
            is_locked = key in verified_list
            g = QGroupBox(f'{icon} {title}'); gl = QVBoxLayout(g)
            g.setStyleSheet(f'QGroupBox {{ font-weight: bold; color: {"#22c55e" if is_locked else "#f1f5f9"}; border: 1px solid {"#22c55e" if is_locked else "#334155"}; border-radius: 8px; margin-top: 10px; padding-top: 10px; }}')
            row = QHBoxLayout()
            in_f = QLineEdit(self.config.get(key, ""))
            in_f.setFixedHeight(38); in_f.setEchoMode(QLineEdit.Password); in_f.setEnabled(not is_locked)
            in_f.setStyleSheet('background: #0f172a; border: 1px solid #1e293b; color: #38bdf8; padding: 0 10px;')
            self._comm_inputs[key] = in_f
            btn_verify = QPushButton('🔓 解除' if is_locked else '🔗 配對'); btn_verify.setFixedSize(80, 38)
            btn_verify.setStyleSheet(f'background: {"#7f1d1d" if is_locked else "#1e293b"}; color: #f1f5f9;')
            btn_verify.clicked.connect(lambda chk=False, k=key: self._trigger_handshake(k))
            row.addWidget(in_f); row.addWidget(btn_verify); gl.addLayout(row)
            st = QLabel(f'● {"✅ 鏈路已鎖定" if is_locked else "🟢 戰術就緒"}')
            st.setStyleSheet(f'color: {"#22c55e" if is_locked else "#94a3b8"}; font-size: 11px;')
            gl.addWidget(st); return g
        self._comm_layout.addWidget(add_row('tg_token', '✈️', 'Telegram'))
        self._comm_layout.addWidget(add_row('discord_token', '🎮', 'Discord'))
        self._comm_layout.addWidget(add_row('line_token', '💬', 'LINE'))
        self._comm_layout.addWidget(add_row('webhook_url', '🔗', 'Webhook'))
        self._comm_layout.addStretch()
        btn_save = QPushButton("💾 保存通訊密鑰"); btn_save.setFixedHeight(45)
        btn_save.setStyleSheet("background: #1e293b; color: #38bdf8; font-weight: bold; border: 1px solid #38bdf8;")
        btn_save.clicked.connect(self._save_comm_tokens); self._comm_layout.addWidget(btn_save)

    def _save_comm_tokens(self):
        for k, v in self._comm_inputs.items(): self.config[k] = v.text()
        self.save_app_config(); QMessageBox.information(self, '✅', '平台金鑰已保存！')

    def _trigger_handshake(self, key):
        verified_list = self.config.get('verified_platforms', [])
        if key in verified_list:
            if QMessageBox.question(self, "解除綁定", f"確定要解除 {key} 的鎖定狀態嗎？") == QMessageBox.Yes:
                verified_list.remove(key)
                self.config['verified_platforms'] = verified_list
                self.save_app_config()
                self._refresh_comm_ui()
            return

        token = self._comm_inputs[key].text().strip()
        if not token:
            QMessageBox.warning(self, "錯誤", "請先輸入通訊平台金鑰 (TK)！")
            return

        # 1. 生成驗證碼
        import random
        verify_code = str(random.randint(100000, 999999))
        
        # 2. 寄送驗證訊息
        self.append_evolution(f"🛰️ [HANDSHAKE]: 正在向 {key} 寄送驗證序列...")
        success = self._send_verify_msg(key, token, verify_code)
        
        if not success:
            QMessageBox.critical(self, "失敗", "驗證訊息寄送失敗，請檢查金鑰是否正確 (或 master_user_id 是否已設定)。")
            return

        # 3. 彈出輸入視窗
        code_in, ok = QInputDialog.getText(self, "🔐 握手驗證", f"已發送驗證碼至該平台，請輸入 6 位數代碼：")
        if ok and code_in == verify_code:
            if key not in verified_list: verified_list.append(key)
            self.config['verified_platforms'] = verified_list
            self.config[key] = token
            self.save_app_config()
            
            # 🆕 寄送綁定成功回饋
            success_msg = "🎊 [TOP AGNET 鏈路鎖定成功]\n通訊矩陣已完成對位，您的帳號已與指揮中心深度綁定。系統已進入戰時防禦狀態。"
            self._send_platform_msg(key, token, success_msg)
            
            QMessageBox.information(self, "成功", f"🎊 {key} 鏈路已成功鎖定！")
            self._refresh_comm_ui()
        elif ok:
            QMessageBox.warning(self, "無效", "驗證碼錯誤，配對終止。")

    def _send_verify_msg(self, key, token, code):
        """實體寄送驗證碼至各平台"""
        msg = f"🔐 [TOP AGNET 握手驗證]\n您的戰術驗證碼為：{code}\n請在指揮中心輸入此代碼以完成鏈路鎖定。"
        return self._send_platform_msg(key, token, msg)

    def _send_platform_msg(self, key, token, msg):
        """通用平台訊息發送器"""
        try:
            import requests
            if key == 'tg_token':
                uid = self.config.get("master_user_id")
                if not uid: return False
                url = f"https://api.telegram.org/bot{token}/sendMessage"
                res = requests.post(url, json={"chat_id": uid, "text": msg}, timeout=5)
                return res.status_code == 200
            elif key == 'webhook_url':
                res = requests.post(token, json={"text": msg}, timeout=5)
                return res.status_code in [200, 201, 204]
            # Discord / LINE 暫時模擬成功
            return True
        except:
            return False

    def init_api_page(self):
        p = QWidget(); outer = QVBoxLayout(p); outer.setContentsMargins(20,15,20,15)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        cw = QWidget(); cl = QVBoxLayout(cw); cl.setContentsMargins(10,10,10,10); cl.setSpacing(12)

        hdr = QLabel("🔗 大腦神經叢 — 核心推理 API 配置 (Neural Hub)")
        hdr.setStyleSheet("font-size: 17px; font-weight: bold; color: #f1f5f9; margin-bottom: 4px;")
        cl.addWidget(hdr)

        GS  = "QGroupBox { font-size: 14px; font-weight: bold; color: #38bdf8; border: 1px solid #1e293b; border-radius: 6px; margin-top: 8px; padding-top: 8px; }"
        BS  = "QPushButton { font-size: 13px; background: #0f172a; border: 1px solid #334155; border-radius: 4px; color: #e2e8f0; } QPushButton:hover { background: #1e293b; border-color: #38bdf8; }"
        BGN = "QPushButton { font-size: 13px; background: #052e16; border: 1px solid #166534; border-radius: 4px; color: #86efac; } QPushButton:hover { background: #064e3b; }"
        INS = "QLineEdit { background: #0f172a; border: 1px solid #334155; border-radius: 4px; color: #e2e8f0; padding: 4px 8px; font-size: 13px; }"

        # ── 1. 核心接入端點 ──
        g1 = QGroupBox("🧠 1. 核心推理引擎接入"); g1.setStyleSheet(GS)
        fl1 = QFormLayout(g1); fl1.setSpacing(10)
        self.api_url_in = QLineEdit(self.config.get("base_url", "http://localhost:11434/v1"))
        self.api_url_in.setFixedHeight(36); self.api_url_in.setStyleSheet(INS)
        self.api_key_in = QLineEdit(self.config.get("api_key", ""))
        self.api_key_in.setFixedHeight(36); self.api_key_in.setStyleSheet(INS)
        self.api_key_in.setEchoMode(QLineEdit.Password)
        self.api_model_in = QLineEdit(self.config.get("model", "gpt-4o"))
        self.api_model_in.setFixedHeight(36); self.api_model_in.setStyleSheet(INS)
        fl1.addRow("🌐 接入端點 (Base URL):", self.api_url_in)
        fl1.addRow("🔑 API Key:", self.api_key_in)
        fl1.addRow("🤖 預設模型:", self.api_model_in)

        btn_row1 = QHBoxLayout(); btn_row1.setSpacing(8)
        save_api_btn = QPushButton("💾 保存接入設定"); save_api_btn.setFixedHeight(36); save_api_btn.setStyleSheet(BGN)
        def do_save_api():
            self.config["base_url"] = self.api_url_in.text()
            self.config["api_key"]  = self.api_key_in.text()
            self.config["model"]    = self.api_model_in.text()
            self.save_app_config()
            QMessageBox.information(p, "✅ 已儲存", "API 接入設定已更新！")
        save_api_btn.clicked.connect(do_save_api)

        test_btn = QPushButton("🔍 驗證與自動偵測"); test_btn.setFixedHeight(36); test_btn.setStyleSheet(BS)
        def do_test_conn():
            import urllib.request, json as _json
            url = self.api_url_in.text().rstrip("/") + "/models"
            try:
                req = urllib.request.Request(url, headers={"Authorization": f"Bearer {self.api_key_in.text()}"})
                with urllib.request.urlopen(req, timeout=5) as r:
                    data = _json.loads(r.read())
                    models = [m.get("id","?") for m in data.get("data", [])]
                    if models:
                        # 🆕 自動偵測並填入第一個可用模型
                        self.api_model_in.setText(models[0])
                        self.api_status_out.setPlainText(f"✅ 驗證成功！\n已自動偵測並切換至模型：{models[0]}\n\n可用模型清單：\n" + "\n".join(f"  • {m}" for m in models[:20]))
                    else:
                        self.api_status_out.setPlainText("✅ 連線成功，但未發現可用模型。")
                    self.api_status_out.setStyleSheet("background:#000; color:#22c55e; font-family:'Consolas'; font-size:12px; border:1px solid #1e293b;")
            except Exception as e:
                self.api_status_out.setPlainText(f"❌ 驗證失敗：\n{str(e)}")
                self.api_status_out.setStyleSheet("background:#000; color:#f87171; font-family:'Consolas'; font-size:12px; border:1px solid #7f1d1d;")
        test_btn.clicked.connect(do_test_conn)
        btn_row1.addWidget(save_api_btn); btn_row1.addWidget(test_btn)
        fl1.addRow("", btn_row1); cl.addWidget(g1)

        # ── 2. 快速端點切換 ──
        g2 = QGroupBox("⚡ 2. 快速端點切換 (Preset Endpoints)"); g2.setStyleSheet(GS)
        gl2 = QVBoxLayout(g2); gl2.setSpacing(6)
        presets = [
            ("🏠 本地 Ollama",     "http://localhost:11434/v1", "ollama"),
            ("☁️ OpenAI 官方",    "https://api.openai.com/v1", "gpt-4o"),
            ("🌏 OpenRouter",     "https://openrouter.ai/api/v1", "qwen/qwen3-235b-a22b"),
            ("🚀 本地 vLLM",      "http://localhost:8000/v1", "local-model"),
            ("🔵 DeepSeek",       "https://api.deepseek.com/v1", "deepseek-chat"),
        ]
        preset_row = QHBoxLayout(); preset_row.setSpacing(6)
        for label, url, model in presets:
            btn = QPushButton(label); btn.setFixedHeight(32)
            btn.setStyleSheet(BS)
            def make_fn(u, m):
                def fn():
                    self.api_url_in.setText(u); self.api_model_in.setText(m)
                return fn
            btn.clicked.connect(make_fn(url, model))
            preset_row.addWidget(btn)
        gl2.addLayout(preset_row); cl.addWidget(g2)

        # ── 3. 推理參數設定 ──
        g3 = QGroupBox("🎛️ 3. 推理參數設定 (Inference Params)"); g3.setStyleSheet(GS)
        fl3 = QFormLayout(g3); fl3.setSpacing(10)
        self.api_temp_in = QLineEdit(str(self.config.get("temperature", "0.7")))
        self.api_temp_in.setFixedHeight(34); self.api_temp_in.setStyleSheet(INS)
        self.api_ctx_in = QLineEdit(str(self.config.get("max_tokens", "4096")))
        self.api_ctx_in.setFixedHeight(34); self.api_ctx_in.setStyleSheet(INS)
        self.api_top_p_in = QLineEdit(str(self.config.get("top_p", "0.9")))
        self.api_top_p_in.setFixedHeight(34); self.api_top_p_in.setStyleSheet(INS)
        fl3.addRow("🌡️ Temperature:", self.api_temp_in)
        fl3.addRow("📏 Max Tokens:", self.api_ctx_in)
        fl3.addRow("🎯 Top-P:", self.api_top_p_in)
        save_param_btn = QPushButton("💾 保存推理參數"); save_param_btn.setFixedHeight(34); save_param_btn.setStyleSheet(BGN)
        def do_save_params():
            try:
                self.config["temperature"] = float(self.api_temp_in.text())
                self.config["max_tokens"]  = int(self.api_ctx_in.text())
                self.config["top_p"]       = float(self.api_top_p_in.text())
                self.save_app_config()
                QMessageBox.information(p, "✅", "推理參數已更新！")
            except Exception as e:
                QMessageBox.warning(p, "❌ 格式錯誤", str(e))
        save_param_btn.clicked.connect(do_save_params)
        fl3.addRow("", save_param_btn); cl.addWidget(g3)

        # ── 4. 戰術推理測試 (Tactical Inference Test) ──
        g4 = QGroupBox("🧪 4. 戰術推理測試 (Tactical Inference Test)"); g4.setStyleSheet(GS)
        gl4 = QVBoxLayout(g4); gl4.setSpacing(10)
        
        test_row = QHBoxLayout(); test_row.setSpacing(8)
        self.test_query_in = QLineEdit("你好，請確認連線狀態並報告你的模型名稱。")
        self.test_query_in.setFixedHeight(36); self.test_query_in.setStyleSheet(INS)
        btn_run_test = QPushButton("🚀 執行推理測試"); btn_run_test.setFixedSize(120, 36); btn_run_test.setStyleSheet(BGN)
        test_row.addWidget(self.test_query_in); test_row.addWidget(btn_run_test)
        gl4.addLayout(test_row)
        
        self.api_status_out = QTextEdit(); self.api_status_out.setReadOnly(True)
        self.api_status_out.setFixedHeight(120)
        self.api_status_out.setStyleSheet("background:#000000; color:#94a3b8; font-family:'Consolas'; font-size:12px; border:1px solid #1e293b;")
        self.api_status_out.setPlainText("⏳ 驗證端點後，點擊「執行推理測試」以驗證模型對話能力...")
        gl4.addWidget(self.api_status_out)
        cl.addWidget(g4)

        def do_inference_test():
            query = self.test_query_in.text().strip()
            if not query: return
            self.api_status_out.setPlainText("🛰️ 正在傳送戰術封包至推理引擎...")
            self.api_status_out.setStyleSheet("background:#000; color:#38bdf8; font-family:'Consolas'; font-size:12px; border:1px solid #1e293b;")
            
            def thread_fn():
                try:
                    import requests, json
                    url = self.api_url_in.text().rstrip("/") + "/chat/completions"
                    payload = {
                        "model": self.api_model_in.text(),
                        "messages": [{"role": "user", "content": query}],
                        "temperature": float(self.api_temp_in.text()),
                        "max_tokens": 150
                    }
                    headers = {"Authorization": f"Bearer {self.api_key_in.text()}"}
                    res = requests.post(url, json=payload, headers=headers, timeout=15)
                    if res.status_code == 200:
                        ans = res.json()["choices"][0]["message"]["content"]
                        QTimer.singleShot(0, lambda: [
                            self.api_status_out.setPlainText(f"✅ 推理成功！\n\n回覆內容：\n{ans}"),
                            self.api_status_out.setStyleSheet("background:#000; color:#22c55e; font-family:'Consolas'; font-size:12px; border:1px solid #1e293b;")
                        ])
                    else:
                        QTimer.singleShot(0, lambda: self.api_status_out.setPlainText(f"❌ 推理失敗 (HTTP {res.status_code})：\n{res.text}"))
                except Exception as e:
                    QTimer.singleShot(0, lambda: self.api_status_out.setPlainText(f"❌ 發生異常：\n{str(e)}"))
            
            import threading
            threading.Thread(target=thread_fn, daemon=True).start()

        btn_run_test.clicked.connect(do_inference_test)

        cl.addStretch(); scroll.setWidget(cw); outer.addWidget(scroll); self.stack.addWidget(p)

    def init_admin_page(self):
        p = QWidget(); outer = QVBoxLayout(p); outer.setContentsMargins(20,15,20,15)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        cw = QWidget(); cl = QVBoxLayout(cw); cl.setContentsMargins(10,10,10,10); cl.setSpacing(10)

        # ── 頁頭 ──
        hdr = QLabel("🧑‍💼 企業級全域後台 (Enterprise Admin Console)")
        hdr.setStyleSheet("font-size: 17px; font-weight: bold; color: #f1f5f9; margin-bottom:4px;")
        cl.addWidget(hdr)

        GS = "QGroupBox { font-size: 15px; font-weight: bold; color: #38bdf8; border: 1px solid #1e293b; border-radius: 6px; margin-top: 6px; padding-top: 6px; }"
        BS = "QPushButton { font-size: 13px; background: #0f172a; border: 1px solid #334155; border-radius: 4px; color: #e2e8f0; } QPushButton:hover { background: #1e293b; border-color: #38bdf8; color: #38bdf8; }"

        def make_btn(txt, fid):
            b = QPushButton(txt); b.setFixedHeight(34); b.setStyleSheet(BS)
            b.clicked.connect(lambda chk, f=fid, t=txt: self.show_admin_panel(t, f))
            return b

        # ── 1. 代理管理 ──
        g1 = QGroupBox("🏅 1. 代理管理"); g1.setStyleSheet(GS); gl1 = QVBoxLayout(g1); gl1.setSpacing(6)
        row1_top = QHBoxLayout()
        row1_top.addWidget(QLabel("預設配置模型:"))
        self.admin_model_cb = QComboBox(); self.admin_model_cb.setFixedHeight(30)
        self.admin_model_cb.addItems(["GPT-4o", "Qwen3-235B", "Claude 3.5", "Gemini Pro", "DeepSeek-V3"])
        self.admin_model_cb.setCurrentText(self.config.get("default_model", "GPT-4o"))
        self.admin_model_cb.currentTextChanged.connect(lambda t: self.config.update({"default_model": t}))
        row1_top.addWidget(self.admin_model_cb); row1_top.addStretch()
        gl1.addLayout(row1_top)
        r1 = QHBoxLayout(); r1.setSpacing(6)
        for txt, fid in [("📋 Agent 列表", "list_agent"), ("✏️ 新建/編輯代理", "new_agent"), ("📈 性能分析", "perf_agent")]:
            r1.addWidget(make_btn(txt, fid))
        gl1.addLayout(r1); cl.addWidget(g1)

        # ── 2. 資源管理 ──
        g2 = QGroupBox("🪙 2. 資源管理"); g2.setStyleSheet(GS); gl2 = QHBoxLayout(g2); gl2.setSpacing(6)
        for txt, fid in [("🗄️ 模型池管理", "model_mgr"), ("🔌 MCP 插件管理", "plugin_mgr"), ("📝 Prompt 模板", "prompt_mgr"), ("🧠 知識庫同步", "kb_mgr")]:
            gl2.addWidget(make_btn(txt, fid))
        cl.addWidget(g2)

        # ── 3. 使用者管理 ──
        g3 = QGroupBox("👥 3. 使用者管理"); g3.setStyleSheet(GS); gl3 = QVBoxLayout(g3); gl3.setSpacing(6)
        row3_top = QHBoxLayout()
        row3_top.addWidget(QLabel("安全層級:"))
        sec_cb = QComboBox(); sec_cb.setFixedHeight(30)
        sec_cb.addItems(["嚴格隔離", "標準模式", "開放存取"])
        sec_cb.setCurrentText(self.config.get("security_level", "嚴格隔離"))
        row3_top.addWidget(sec_cb); row3_top.addStretch(); gl3.addLayout(row3_top)
        r3 = QHBoxLayout(); r3.setSpacing(6)
        for txt, fid in [("👁️ 使用者監控", "users"), ("📋 安全審計日誌", "audit")]:
            r3.addWidget(make_btn(txt, fid))
        r3.addStretch(); gl3.addLayout(r3); cl.addWidget(g3)

        # ── 4. 數據分析與統計 ──
        g4 = QGroupBox("📊 4. 數據分析與統計"); g4.setStyleSheet(GS); gl4 = QHBoxLayout(g4); gl4.setSpacing(6)
        for txt, fid in [("📊 Token 統計", "stats"), ("📈 營運報表", "report"), ("💰 計費設定", "billing")]:
            gl4.addWidget(make_btn(txt, fid))
        cl.addWidget(g4)

        # ── 5. 次世代武裝 ──
        g5 = QGroupBox("⭐ 5. 次世代武裝"); g5.setStyleSheet(GS); gl5 = QVBoxLayout(g5); gl5.setSpacing(6)
        r5 = QHBoxLayout(); r5.setSpacing(6)
        for txt, fid in [("🔄 全域自癒", "self_heal"), ("💾 語義記憶庫", "vector_mem"), ("👁️ 全境感知", "ambient"), ("⏰ 定時戰術", "scheduled_tasks")]:
            r5.addWidget(make_btn(txt, fid))
        gl5.addLayout(r5); cl.addWidget(g5)

        # ── 6. 通訊平台管理中心 ──
        g6 = QGroupBox("📡 6. 通訊平台管理中心"); g6.setStyleSheet(GS); gl6 = QVBoxLayout(g6); gl6.setSpacing(6)
        r6a = QHBoxLayout(); r6a.setSpacing(6)
        for txt, fid in [("✈️ Telegram 全功能", "telegram_mgr"), ("👁️ Telegram 監控", "telegram_monitor"), ("🔑 系統授權管理", "auth_mgr"), ("⬛ 黑白名單管理", "whitelist")]:
            r6a.addWidget(make_btn(txt, fid))
        r6b = QHBoxLayout(); r6b.setSpacing(6)
        for txt, fid in [("🔄 自動回覆規則", "auto_reply"), ("⏰ 定時任務排程", "scheduled_tasks"), ("🤖 Agent 人格設定", "personality")]:
            r6b.addWidget(make_btn(txt, fid))
        r6b.addStretch()
        gl6.addLayout(r6a); gl6.addLayout(r6b); cl.addWidget(g6)

        # ── 7. 指揮中心感知控制 — 上帝之眼 & 戰術指標 ──
        g7 = QGroupBox("👁️ 7. 指揮中心感知控制 — 上帝之眼 & 戰術指標")
        g7.setStyleSheet("QGroupBox { font-size: 15px; font-weight: bold; color: #f43f5e; border: 1px solid #450a0a; border-radius: 6px; margin-top: 6px; padding-top: 6px; }")
        g7_outer = QHBoxLayout(g7); g7_outer.setSpacing(15)

        # 左：上帝之眼過濾開關
        god_eye_g = QGroupBox("👁️ 上帝之眼 — 顯示過濾")
        god_eye_g.setStyleSheet("QGroupBox { font-size: 13px; font-weight: bold; color: #38bdf8; border: 1px solid #1e3a5f; border-radius: 4px; margin-top: 4px; padding-top: 4px; }")
        god_eye_l = QVBoxLayout(god_eye_g); god_eye_l.setSpacing(3)
        cfg_f = self.config.get("god_eye_filters", {})
        self._ge_browser = QCheckBox("🌐 瀏覽/爬取過程"); self._ge_browser.setChecked(cfg_f.get("show_browser", True))
        self._ge_actions = QCheckBox("⚡ 核心執行動作"); self._ge_actions.setChecked(cfg_f.get("show_actions", True))
        self._ge_tools   = QCheckBox("🛠️ 工具調用詳情"); self._ge_tools.setChecked(cfg_f.get("show_tools", True))
        self._ge_skills  = QCheckBox("🧠 技能模組使用"); self._ge_skills.setChecked(cfg_f.get("show_skills", True))
        self._ge_steps   = QCheckBox("🔢 底層步驟流水"); self._ge_steps.setChecked(cfg_f.get("show_steps", True))
        CB_S = "font-size: 12px; margin: 2px;"
        for cb in [self._ge_browser, self._ge_actions, self._ge_tools, self._ge_skills, self._ge_steps]:
            cb.setStyleSheet(CB_S); god_eye_l.addWidget(cb)

        # 中：戰術指標 HUD 開關
        hud_g = QGroupBox("⚡ 戰術指標 HUD — 顯示控制")
        hud_g.setStyleSheet("QGroupBox { font-size: 13px; font-weight: bold; color: #fde047; border: 1px solid #422006; border-radius: 4px; margin-top: 4px; padding-top: 4px; }")
        hud_gl = QVBoxLayout(hud_g); hud_gl.setSpacing(3)
        cfg_h = self.config.get("hud_display", {})
        self._hud_tk     = QCheckBox("🔵 TK 總量計數器"); self._hud_tk.setChecked(cfg_h.get("show_tk", True))
        self._hud_speed  = QCheckBox("🟢 生成速度 (TK/秒)"); self._hud_speed.setChecked(cfg_h.get("show_speed", True))
        self._hud_hw     = QCheckBox("🟡 處理器/記憶體"); self._hud_hw.setChecked(cfg_h.get("show_hw", True))
        self._hud_lat    = QCheckBox("🟣 網絡延遲"); self._hud_lat.setChecked(cfg_h.get("show_lat", True))
        self._hud_status = QCheckBox("⚪ 大腦狀態"); self._hud_status.setChecked(cfg_h.get("show_status", True))
        for cb in [self._hud_tk, self._hud_speed, self._hud_hw, self._hud_lat, self._hud_status]:
            cb.setStyleSheet(CB_S); hud_gl.addWidget(cb)

        # 右：保存控制
        save_g = QGroupBox("💾 即時套用")
        save_g.setStyleSheet("QGroupBox { font-size: 13px; font-weight: bold; color: #22c55e; border: 1px solid #064e3b; border-radius: 4px; margin-top: 4px; padding-top: 4px; }")
        save_gl = QVBoxLayout(save_g); save_gl.setSpacing(8)
        apply_btn = QPushButton("💾 保存並即時\n套用感知設定"); apply_btn.setFixedHeight(56)
        apply_btn.setStyleSheet("background: #064e3b; color: #22c55e; font-size: 13px; font-weight: bold; border-radius: 4px; border: none;")
        apply_btn.clicked.connect(self._save_perception_settings)
        reset_btn = QPushButton("🔄 重置為全開預設"); reset_btn.setFixedHeight(30)
        reset_btn.setStyleSheet("background: #1e293b; color: #94a3b8; font-size: 12px; border: 1px solid #334155; border-radius: 4px;")
        reset_btn.clicked.connect(self._reset_perception_defaults)
        save_gl.addWidget(apply_btn); save_gl.addWidget(reset_btn); save_gl.addStretch()

        g7_outer.addWidget(god_eye_g); g7_outer.addWidget(hud_g); g7_outer.addWidget(save_g)
        cl.addWidget(g7)

        cl.addStretch(); scroll.setWidget(cw); outer.addWidget(scroll); self.stack.addWidget(p)
    def init_system_page(self):
        p = QWidget(); outer = QVBoxLayout(p); outer.setContentsMargins(20,15,20,15)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        cw = QWidget(); cl = QVBoxLayout(cw); cl.setContentsMargins(10,10,10,10); cl.setSpacing(12)

        hdr = QLabel("⚙️ 系統進階維護 (System Maintenance)")
        hdr.setStyleSheet("font-size: 17px; font-weight: bold; color: #f1f5f9; margin-bottom: 4px;")
        cl.addWidget(hdr)

        GS = "QGroupBox { font-size: 14px; font-weight: bold; color: #38bdf8; border: 1px solid #1e293b; border-radius: 6px; margin-top: 8px; padding-top: 8px; }"
        BS_RED  = "QPushButton { font-size: 13px; background: #1e0a0a; border: 1px solid #7f1d1d; border-radius: 4px; color: #fca5a5; } QPushButton:hover { background: #450a0a; }"
        BS_BLU  = "QPushButton { font-size: 13px; background: #0f172a; border: 1px solid #334155; border-radius: 4px; color: #e2e8f0; } QPushButton:hover { background: #1e293b; border-color: #38bdf8; }"
        BS_GRN  = "QPushButton { font-size: 13px; background: #052e16; border: 1px solid #166534; border-radius: 4px; color: #86efac; } QPushButton:hover { background: #064e3b; }"

        # ── 1. 背景進程控制 ──
        g1 = QGroupBox("🔧 1. 背景進程控制 (Process Control)"); g1.setStyleSheet(GS)
        gl1 = QVBoxLayout(g1); gl1.setSpacing(8)
        proc_row = QHBoxLayout(); proc_row.setSpacing(8)
        procs = [
            ("🧠 主腦引擎", "brain/core.py"),
            ("🛡️ 自癒守衛", "brain/watchdog.py"),
            ("🏹 進化獵人", "brain/evolution_hunter.py"),
            ("⏰ 任務調度", "brain/scheduler.py"),
        ]
        for name, script in procs:
            vb = QVBoxLayout(); lbl = QLabel(name); lbl.setStyleSheet("color:#94a3b8; font-size:11px;")
            start_b = QPushButton("▶ 啟動"); start_b.setFixedHeight(28); start_b.setStyleSheet(BS_GRN)
            stop_b  = QPushButton("■ 停止"); stop_b.setFixedHeight(28);  stop_b.setStyleSheet(BS_RED)
            _s = script
            start_b.clicked.connect(lambda chk, s=_s: subprocess.Popen([
                "./venv/bin/python3", s], cwd="/home/user/Desktop/專案",
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
            vb.addWidget(lbl); vb.addWidget(start_b); vb.addWidget(stop_b)
            proc_row.addLayout(vb)
        gl1.addLayout(proc_row)
        restart_all = QPushButton("🔄 一鍵重啟所有背景引擎"); restart_all.setFixedHeight(34)
        restart_all.setStyleSheet(BS_BLU)
        def do_restart_all():
            subprocess.Popen(["./venv/bin/python3", "restart_services.py"],
                             cwd="/home/user/Desktop/專案", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            QMessageBox.information(p, "✅ 重啟中", "所有引擎正在後台重啟，請稍候 5 秒。")
        restart_all.clicked.connect(do_restart_all)
        gl1.addWidget(restart_all); cl.addWidget(g1)

        # ── 2. 平台核心設定 ──
        g2 = QGroupBox("🏗️ 2. 平台核心設定 (Platform Config)"); g2.setStyleSheet(GS)
        fl2 = QFormLayout(g2); fl2.setSpacing(10)
        self.sys_name_in = QLineEdit(self.config.get("platform_name", "Top 最強代理人"))
        self.sys_name_in.setFixedHeight(36)
        self.sys_port_in = QLineEdit(str(self.config.get("server_port", "8765")))
        self.sys_port_in.setFixedHeight(36)
        self.sys_agent_in = QLineEdit(self.config.get("agent_name", "TOP Agent"))
        self.sys_agent_in.setFixedHeight(36)
        self.sys_owner_in = QLineEdit(self.config.get("owner_name", "主控官"))
        self.sys_owner_in.setFixedHeight(36)
        fl2.addRow("平台名稱:", self.sys_name_in)
        fl2.addRow("Agent 名稱:", self.sys_agent_in)
        fl2.addRow("主控官稱謂:", self.sys_owner_in)
        fl2.addRow("伺服器埠號:", self.sys_port_in)
        save_cfg_btn = QPushButton("💾 保存核心設定並即時套用"); save_cfg_btn.setFixedHeight(38)
        save_cfg_btn.setStyleSheet(BS_GRN)
        def do_save_sys():
            self.config["platform_name"] = self.sys_name_in.text()
            self.config["agent_name"]    = self.sys_agent_in.text()
            self.config["owner_name"]    = self.sys_owner_in.text()
            try: self.config["server_port"] = int(self.sys_port_in.text())
            except: pass
            self.save_app_config()
            if hasattr(self, "logo"): self.logo.setText(self.config["platform_name"])
            QMessageBox.information(p, "✅ 已儲存", "核心設定已更新並套用！")
        save_cfg_btn.clicked.connect(do_save_sys)
        fl2.addRow("", save_cfg_btn); cl.addWidget(g2)

        # ── 3. 資料與快取管理 ──
        g3 = QGroupBox("🗄️ 3. 資料與快取管理 (Data Management)"); g3.setStyleSheet(GS)
        gl3 = QVBoxLayout(g3); gl3.setSpacing(8)
        data_row = QHBoxLayout(); data_row.setSpacing(8)
        def make_data_btn(label, action_fn, style=BS_BLU):
            b = QPushButton(label); b.setFixedHeight(34); b.setStyleSheet(style)
            b.clicked.connect(action_fn); return b
        def clear_chat():
            if QMessageBox.question(p, "確認", "清空對話歷史？") == QMessageBox.Yes:
                open("/home/user/Desktop/專案/shared_history.json", "w").write("[]")
                QMessageBox.information(p, "✅", "對話歷史已清空。")
        def clear_logs():
            import glob
            for f in glob.glob("/home/user/Desktop/專案/logs/*.log"):
                open(f, "w").close()
            QMessageBox.information(p, "✅", "所有日誌已清空。")
        def open_logs():
            subprocess.Popen(["xdg-open", "/home/user/Desktop/專案/logs"])
        data_row.addWidget(make_data_btn("🗑️ 清空對話歷史", clear_chat, BS_RED))
        data_row.addWidget(make_data_btn("📋 清空系統日誌", clear_logs, BS_RED))
        data_row.addWidget(make_data_btn("📂 開啟日誌資料夾", open_logs))
        data_row.addWidget(make_data_btn("📂 開啟錄影資料夾",
            lambda: subprocess.Popen(["xdg-open", self.config.get("recording_path", "brain/recordings")]) ))
        gl3.addLayout(data_row); cl.addWidget(g3)

        # ── 4. 系統診斷 ──
        g4 = QGroupBox("🩺 4. 系統診斷 (System Diagnostics)"); g4.setStyleSheet(GS)
        gl4 = QVBoxLayout(g4); gl4.setSpacing(8)
        diag_row = QHBoxLayout(); diag_row.setSpacing(8)
        self.diag_out = QTextEdit(); self.diag_out.setReadOnly(True); self.diag_out.setFixedHeight(150)
        self.diag_out.setStyleSheet("background:#000000; color:#22c55e; font-family:'Consolas'; font-size:12px; border:1px solid #1e293b;")
        def run_diag():
            import platform
            try:
                import psutil
                cpu = psutil.cpu_percent(); mem = psutil.virtual_memory()
                report = (f"🖥️  OS: {platform.system()} {platform.release()}\n"
                          f"🐍  Python: {platform.python_version()}\n"
                          f"⚡  CPU: {cpu}%\n"
                          f"💾  RAM: {mem.percent}% ({mem.used//1024//1024}MB / {mem.total//1024//1024}MB)\n"
                          f"📁  工作目錄: /home/user/Desktop/專案\n"
                          f"🔗  Config 狀態: {'✅ 正常' if self.config else '❌ 異常'}\n"
                          f"🕐  診斷時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            except:
                report = (f"🖥️  OS: {platform.system()} {platform.release()}\n"
                          f"🐍  Python: {platform.python_version()}\n"
                          f"🕐  診斷時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            self.diag_out.setPlainText(report)
        diag_btn = QPushButton("🔍 執行系統診斷"); diag_btn.setFixedHeight(34); diag_btn.setStyleSheet(BS_BLU)
        diag_btn.clicked.connect(run_diag)
        diag_row.addWidget(diag_btn)
        ver_btn = QPushButton("📦 檢查依賴套件"); ver_btn.setFixedHeight(34); ver_btn.setStyleSheet(BS_BLU)
        def check_deps():
            result = subprocess.run(["./venv/bin/pip", "list"], cwd="/home/user/Desktop/專案",
                                    capture_output=True, text=True)
            self.diag_out.setPlainText(result.stdout[:2000] if result.stdout else "無法取得套件列表")
        ver_btn.clicked.connect(check_deps)
        diag_row.addWidget(ver_btn)
        gl4.addLayout(diag_row)
        gl4.addWidget(self.diag_out)
        cl.addWidget(g4)

        cl.addStretch(); scroll.setWidget(cw); outer.addWidget(scroll); self.stack.addWidget(p)
    def init_branding_page(self):
        p = QWidget(); l = QVBoxLayout(p); l.setContentsMargins(40, 40, 40, 40); l.setSpacing(20)

        # ─── 區塊一：系統路徑 ───
        g1 = QGroupBox("📁 核心系統路徑"); g1_l = QFormLayout(g1)
        self.rec_path_in = QLineEdit(self.config.get("recording_path", "brain/recordings"))
        self.rec_path_in.setFixedHeight(36)
        g1_l.addRow("錄影路徑:", self.rec_path_in)
        l.addWidget(g1)

        # ─── 區塊二：像素矩陣與視覺設定 ───
        g2 = QGroupBox("ℹ️ 像素矩陣與視覺設定"); g2_l = QFormLayout(g2)
        
        self.pixel_mode_combo = QComboBox(); self.pixel_mode_combo.setFixedHeight(40)
        self.pixel_mode_combo.addItems(["滾動文字 (Scrolling Text)", "像素圖片 (Pixel Image)"])
        self.pixel_mode_combo.setCurrentText("滾動文字 (Scrolling Text)" if self.config.get("pixel_logo_mode") == "text" else "像素圖片 (Pixel Image)")
        
        self.pixel_content_in = QLineEdit(self.config.get("pixel_logo_content", ""))
        self.pixel_content_in.setFixedHeight(40)
        
        self.pixel_anim_combo = QComboBox(); self.pixel_anim_combo.setFixedHeight(40)
        self.pixel_anim_combo.addItems(["跑馬燈滾動 (Marquee)", "固定顯示 (Static)"])
        self.pixel_anim_combo.setCurrentText("跑馬燈滾動 (Marquee)" if self.config.get("pixel_scroll_enabled", True) else "固定顯示 (Static)")
        
        # 顏色選擇器
        color_row = QHBoxLayout()
        self.color_preview = QLabel(); self.color_preview.setFixedSize(40, 40)
        self.color_hex = self.config.get("pixel_color_hex", "#38bdf8")
        self.color_preview.setStyleSheet(f"background-color: {self.color_hex}; border-radius: 4px; border: 1px solid #444;")
        pick_btn = QPushButton("🎨 選擇像素顏色"); pick_btn.setFixedHeight(40)
        def pick_color():
            c = QColorDialog.getColor(QColor(self.color_hex), self, "選擇像素矩陣顏色")
            if c.isValid():
                self.color_hex = c.name()
                self.color_preview.setStyleSheet(f"background-color: {self.color_hex}; border-radius: 4px; border: 1px solid #444;")
        pick_btn.clicked.connect(pick_color)
        color_row.addWidget(self.color_preview); color_row.addWidget(pick_btn); color_row.addStretch()
        
        self.lang_combo = QComboBox(); self.lang_combo.setFixedHeight(40)
        self.lang_combo.addItems(["繁體中文 (Traditional Chinese)", "简体中文 (Simplified Chinese)", "English (US)"])
        self.lang_combo.setCurrentText(self.config.get("ui_language", "繁體中文 (Traditional Chinese)"))
        
        # 系統主題選擇
        self.theme_combo = QComboBox(); self.theme_combo.setFixedHeight(40)
        self.theme_combo.addItems(["Deep Space (深邃空間)", "Midnight Black (午夜全黑)", "Cyberpunk Neon (賽博霓虹)", "Tactical Sand (戰術沙漠)", "God Mode Gold (上帝視角 - 金)"])
        self.theme_combo.setCurrentText(self.config.get("ui_theme", "Deep Space (深邃空間)"))
        
        self.show_clock_cb = QCheckBox("顯示動態像素時鐘"); self.show_clock_cb.setChecked(self.config.get("show_pixel_clock", True))
        
        g2_l.addRow("Logo 模式:", self.pixel_mode_combo)
        g2_l.addRow("動畫模式:", self.pixel_anim_combo)
        g2_l.addRow("顯示內容:", self.pixel_content_in)
        g2_l.addRow("像素色彩:", color_row)
        g2_l.addRow("功能開關:", self.show_clock_cb)
        g2_l.addRow("系統語言:", self.lang_combo)
        g2_l.addRow("全域佈景主題:", self.theme_combo)
        l.addWidget(g2)

        # ── 區塊三：對話框戰術美學 (Chat Aesthetics) ──
        g3 = QGroupBox("🎨 區塊三：對話框戰術美學自定義"); g3_l = QGridLayout(g3)
        self.ui_c = self.config.get("ui_custom", {})
        
        def make_color_btn(key, label, row, col):
            btn = QPushButton(label); btn.setFixedHeight(34)
            preview = QLabel(); preview.setFixedSize(24, 24); preview.setStyleSheet(f"background:{self.ui_c.get(key, '#000')}; border:1px solid #fff;")
            def pick():
                c = QColorDialog.getColor(QColor(self.ui_c.get(key)), self, f"選擇 {label}")
                if c.isValid():
                    self.ui_c[key] = c.name(); preview.setStyleSheet(f"background:{c.name()}; border:1px solid #fff;")
            btn.clicked.connect(pick)
            g3_l.addWidget(preview, row, col*2); g3_l.addWidget(btn, row, col*2+1)

        make_color_btn("chat_bg", "對話底色", 0, 0)
        make_color_btn("user_bubble", "用戶氣泡", 0, 1)
        make_color_btn("agent_bubble", "助理氣泡", 1, 0)
        make_color_btn("user_text", "用戶字體", 1, 1)
        make_color_btn("agent_text", "助理字體", 2, 0)
        make_color_btn("table_header", "表格標題", 2, 1)
        
        l.addWidget(g3)
        
        # ── 戰術功能矩陣 ──
        btn_grid_box = QGroupBox("🛠️ 戰術功能矩陣 (Function Matrix)"); btn_grid = QGridLayout(btn_grid_box)
        btn_grid.setSpacing(10)
        
        def add_btn(label, fn, row, col, style="background:#1e3a5f; color:#f1f5f9;"):
            b = QPushButton(label); b.setFixedHeight(40); b.setStyleSheet(style + "border-radius:4px; border:1px solid #334155;")
            b.setCursor(Qt.PointingHandCursor)
            
            def wrapped_fn():
                if "保存" in label:
                    b.setText("🛰️ 正在寫入同步..."); b.setEnabled(False)
                    # 🚀 立即執行核心邏輯，延遲恢復按鍵狀態
                    try:
                        fn()
                    except Exception as e:
                        print(f"ERROR: {e}")
                    QTimer.singleShot(800, lambda: [b.setText(label), b.setEnabled(True)])
                else:
                    fn()
            
            b.clicked.connect(wrapped_fn); btn_grid.addWidget(b, row, col)
            return b
            
        def browse_pixel_img():
            f, _ = QFileDialog.getOpenFileName(self, "選擇圖片", "", "Images (*.png *.jpg *.bmp)")
            if f: 
                self.pixel_content_in.setText(f)
                self.append_evolution(f"📸 [VISUAL]: 已選取新像素圖片：{f}")

        add_btn("🖼️ 載入像素圖片", browse_pixel_img, 0, 0)
        add_btn("📂 錄影資料夾", self._open_rec_folder, 0, 1)
        add_btn("📸 截圖資料夾", lambda: subprocess.Popen(["xdg-open", "brain/screenshots"]), 1, 0)
        add_btn("🔄 重置視覺設定", self._reset_visuals, 1, 1, "background:#7f1d1d; color:#ffffff;")
        add_btn("📺 切換全屏模式", self._toggle_fullscreen, 2, 0)
        add_btn("💾 保存並即時套用", self._save_branding_settings, 2, 1, "background:#065f46; color:#ffffff; font-weight:bold;")

        l.addWidget(btn_grid_box)
        l.addStretch(); self.stack.addWidget(p)

    def _browse_rec_path(self):
        d = QFileDialog.getExistingDirectory(self, "選擇錄影保存路徑", self.rec_path_in.text())
        if d: self.rec_path_in.setText(d)

    def _open_rec_folder(self):
        path = self.rec_path_in.text()
        os.makedirs(path, exist_ok=True)
        subprocess.Popen(["xdg-open", path])

    def _save_branding_settings(self):
        try:
            self.append_evolution("🛰️ [SYSTEM]: 正在同步全域視覺矩陣與佈局參數...")
            
            # 🎯 取得當前 UI 狀態
            show_clock = self.show_clock_cb.isChecked()
            mode = "text" if "滾動文字" in self.pixel_mode_combo.currentText() else "image"
            scroll = "跑馬燈" in self.pixel_anim_combo.currentText()
            content = self.pixel_content_in.text().strip()
            
            # 1. 更新 Config 緩存
            self.config["recording_path"] = self.rec_path_in.text()
            self.config["ui_language"] = self.lang_combo.currentText()
            self.config["ui_theme"] = self.theme_combo.currentText()
            self.config["show_pixel_clock"] = show_clock
            self.config["pixel_color_hex"] = self.color_hex
            self.config["pixel_logo_mode"] = mode
            self.config["pixel_logo_content"] = content
            self.config["pixel_scroll_enabled"] = scroll
            self.config["ui_custom"] = self.ui_c
            
            # 2. 持久化至檔案
            from brain.core import save_config
            save_config(self.config)
            
            # 3. 戰術視覺矩陣強制同步
            # 3.1 時鐘狀態
            if hasattr(self, 'pixel_clock'):
                self.pixel_clock.setHidden(not show_clock)
                self.pixel_clock.setFixedHeight(70 if show_clock else 0)
                self.pixel_clock.update()
            
            # 3.2 Logo 高度與內容
            if hasattr(self, 'pixel_logo'):
                target_h = 240 if show_clock else 310
                target_r = 48 if show_clock else 62
                
                # 強制變更維度
                self.pixel_logo.setFixedHeight(target_h)
                self.pixel_logo.resize_display(target_h, target_r)
                
                # 套用內容與模式
                display_content = content if mode == "image" else (content or self.config.get("platform_name", "TOP AGNET"))
                self.pixel_logo.set_mode(mode, display_content)
                
                # 同步色彩與動畫
                color = QColor(self.color_hex)
                self.pixel_logo.pixel_color = color
                self.pixel_logo.scroll_enabled = scroll
                
                self.pixel_logo.update()
                self.pixel_logo.repaint()
            
            # 4. 刷新佈局
            if hasattr(self, 'sidebar_frame'):
                l = self.sidebar_frame.layout()
                if l:
                    l.invalidate()
                    l.activate()
            
            # 5. 其他 UI 組件同步
            self.apply_styles()
            if hasattr(self, 'chat_w'):
                self.chat_w.setStyleSheet(f"background: {self.ui_c.get('chat_bg', '#0f172a')};")
                
            self.append_evolution(f"✅ [VISUAL_SYNC]: 視覺矩陣已重啟。時鐘:{show_clock}, 模式:{mode}")
            QMessageBox.information(self, "✅ 已儲存", "全域視覺矩陣與佈景主題已成功保存並即時套用！")
            
        except Exception as e:
            err_msg = f"❌ [ERROR]: 視覺矩陣同步失敗: {str(e)}"
            self.append_evolution(err_msg)
            QMessageBox.critical(self, "系統錯誤", err_msg)

    def _reset_visuals(self):
        if QMessageBox.question(self, "確認", "是否重置所有視覺設定至預設值？") == QMessageBox.Yes:
            self.config["pixel_color_hex"] = "#38bdf8"
            self.config["pixel_scroll_enabled"] = True
            self.config["pixel_logo_mode"] = "text"
            save_config(self.config)
            QMessageBox.information(self, "✅", "視覺設定已重置，請重新啟動。")

    def _toggle_fullscreen(self):
        if self.isFullScreen(): self.showNormal()
        else: self.showFullScreen()

    def _inject_mind(self):
        text = self._mind_in.text().strip()
        if text:
            self.config["mind_injection"] = text
            self.append_evolution(f"💉 [MIND_INJECT]: 潛意識指令已注入：{text}")
            self._mind_in.clear()
            QMessageBox.information(self, "💉 注入成功", "指令已塞入 AGNET 核心緩衝區。")

    def _save_perception_settings(self):
        filters = {
            "show_browser": self._ge_browser.isChecked(),
            "show_actions": self._ge_actions.isChecked(),
            "show_tools":   self._ge_tools.isChecked(),
            "show_skills":  self._ge_skills.isChecked(),
            "show_steps":   self._ge_steps.isChecked(),
            "show_thought": self._ge_thought.isChecked(),
            "show_audit":   self._ge_audit.isChecked()
        }
        self.config["god_eye_filters"] = filters
        self.save_app_config()
        QMessageBox.information(self, "✅ 設定已套用", "上帝之眼感知過濾設定已成功儲存。")

    def show_admin_panel(self, title, fid):
        # 🛡️ [戰術路由]: 優先交由 admin_panels 的全量路由表處理
        print(f"DEBUG: Opening admin panel {fid} ({title})")
        try:
            if _admin_show_panel:
                _admin_show_panel(fid, self)
            else:
                QMessageBox.warning(self, "系統異常", f"無法連接至後台路由模組。")
        except Exception as e:
            QMessageBox.critical(self, "路由崩潰", f"嘗試啟動【{title}】時發生嚴重錯誤：\n{str(e)}")

    def _sync_admin_mirror(self):
        """同步後台頁面的上帝之眼日誌與指標"""
        if hasattr(self, "admin_log_mirror") and self.admin_log_mirror.isVisible():
            self.admin_log_mirror.setHtml(self.seq_list.toHtml())
            self.admin_log_mirror.moveCursor(QTextCursor.End)
            try:
                self._admin_tk_lbl.setText(f"TK: {self.total_tokens_val}")
                self._admin_speed_lbl.setText(f"速度: {getattr(self, 'tps_val', 0.0):.1f}")
            except: pass

    def save_app_config(self):
        try:
            save_config(self.config)
        except Exception as e:
            QMessageBox.warning(self, "儲存失敗", str(e))

    def init_agnet_core_page(self):
        """【AGNET 核心主控專區】— 整合大腦、手腳、靈魂與感知的戰術中心"""
        p = QWidget(); outer = QVBoxLayout(p); outer.setContentsMargins(20,15,20,15)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        cw = QWidget(); cl = QVBoxLayout(cw); cl.setContentsMargins(10,10,10,10); cl.setSpacing(15)

        hdr = QLabel("🧠 AGNET 核心戰術主控中心 (Core Control Center)")
        hdr.setStyleSheet("font-size: 26px; font-weight: 900; color: #f43f5e; letter-spacing: 3px;")
        cl.addWidget(hdr)
        
        # 🆕 增加實時脈動條 (Pulse Bar)
        self._pulse_frame = QFrame(); self._pulse_frame.setFixedHeight(4); self._pulse_frame.setStyleSheet("background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f43f5e, stop:0.5 #38bdf8, stop:1 #f43f5e);")
        cl.addWidget(self._pulse_frame)

        # ── 第一排：大腦與感知的雙翼佈局 ──
        h_top = QHBoxLayout(); h_top.setSpacing(15)

        # 1. 大腦核心參數 (左側)
        brain_g = QGroupBox("🧠 大腦核心與參數 (Brain & Parameters)")
        brain_g.setStyleSheet("QGroupBox { color: #38bdf8; border: 1px solid #1e3a5f; }")
        bl = QFormLayout(brain_g)
        
        self._core_max_turns = QSpinBox(); self._core_max_turns.setRange(1, 100); self._core_max_turns.setValue(self.config.get("agent_max_turns", 50))
        self._core_memory = QSpinBox(); self._core_memory.setRange(1, 200); self._core_memory.setValue(self.config.get("memory_limit", 12))
        
        bl.addRow("思考最大深度 (Turns):", self._core_max_turns)
        bl.addRow("記憶視界深度 (Context):", self._core_memory)
        
        # 溫度控制
        temp_l = QVBoxLayout()
        self._core_temp_val = QLabel(f"創造力: {self.config.get('temperature', 0.7):.2f}")
        self._core_temp_slider = QSlider(Qt.Horizontal); self._core_temp_slider.setRange(0, 200)
        self._core_temp_slider.setValue(int(self.config.get("temperature", 0.7)*100))
        self._core_temp_slider.valueChanged.connect(lambda v: [self._core_temp_val.setText(f"創造力: {v/100:.2f}"), self.config.update({"temperature": v/100})])
        temp_l.addWidget(self._core_temp_val); temp_l.addWidget(self._core_temp_slider)
        bl.addRow(temp_l)
        h_top.addWidget(brain_g, 1)

        # 2. 全境感知鏡像 (右側)
        live_g = QGroupBox("📡 戰術實時鏡像 (God's Eye Mirror)")
        live_g.setStyleSheet("QGroupBox { color: #22c55e; border: 1px solid #064e3b; }")
        ll = QVBoxLayout(live_g)
        self._core_log_mirror = QTextEdit(); self._core_log_mirror.setReadOnly(True)
        self._core_log_mirror.setStyleSheet("background:#000; color:#22c55e; font-family:Consolas; font-size:11px; border: none;")
        ll.addWidget(self._core_log_mirror)
        
        # 🆕 實時波形/雷達模擬 (增加視覺張力)
        self._radar_frame = QFrame(); self._radar_frame.setFixedHeight(80); self._radar_frame.setStyleSheet("background: #000; border-top: 1px solid #064e3b;")
        rl = QHBoxLayout(self._radar_frame); rl.setContentsMargins(10,0,10,0)
        self._radar_lbl = QLabel("🛰️ [RADAR_SCANNING]: 扇區穩定，暫無威脅..."); self._radar_lbl.setStyleSheet("color:#22c55e; font-size:10px; font-family:Consolas;")
        rl.addWidget(self._radar_lbl); rl.addStretch()
        ll.addWidget(self._radar_frame)
        
        h_top.addWidget(live_g, 2)
        cl.addLayout(h_top)

        # ── 1.5. Native Tactical Core (GGUF 核心) ──
        native_g = QGroupBox("🏗️ 原生戰術核心 (Native GGUF Core - Offline Mode)")
        native_g.setStyleSheet("QGroupBox { color: #a855f7; border: 1px solid #4c1d95; }")
        nl = QHBoxLayout(native_g)
        self._native_path = QLineEdit(self.config.get("local_model_path", "./brain/models/Qwen2.5-7B-Instruct-Q4_K_M.gguf"))
        self._native_path.setPlaceholderText("GGUF 模型路徑..."); self._native_path.setFixedHeight(36)
        btn_load_native = QPushButton("⚡ 加載本地核心"); btn_load_native.setFixedSize(120, 36); btn_load_native.setStyleSheet("background: #4c1d95; color: white;")
        btn_load_native.clicked.connect(self._load_native_core)
        nl.addWidget(QLabel("模型路徑:")); nl.addWidget(self._native_path); nl.addWidget(btn_load_native)
        cl.addWidget(native_g)

        # ── 第二排：戰術武器庫管理 (手腳控管) ──
        arsenal_g = QGroupBox("⚔️ 戰術武器庫管理矩陣 (The Hands & Feet Control)")
        arsenal_g.setStyleSheet("QGroupBox { color: #fbbf24; border: 1px solid #422006; }")
        al = QVBoxLayout(arsenal_g)
        al.addWidget(QLabel("💡 您可以在此「一鍵進入」微觀武器庫，調整 33 項工具的可見度與執行權。"))
        btn_arsenal = QPushButton("⚔️ 進入武器庫矩陣 — 調配 AGNET 手腳權限"); btn_arsenal.setFixedHeight(45)
        btn_arsenal.setCursor(Qt.PointingHandCursor)
        btn_arsenal.setStyleSheet("""
            QPushButton {
                background: #422006; 
                color: #fbbf24; 
                font-weight: bold; 
                font-size: 13px; 
                border: 1px solid #fbbf24;
                border-radius: 4px;
            }
            QPushButton:hover {
                background: rgba(251, 191, 36, 0.1);
                border: 2px solid #fbbf24;
                color: #fef3c7;
            }
            QPushButton:pressed {
                background: rgba(251, 191, 36, 0.2);
            }
        """)
        btn_arsenal.clicked.connect(lambda: self.show_admin_panel("戰術武器庫", "arsenal_mgr"))
        al.addWidget(btn_arsenal)
        
        # 🆕 [感知控制矩陣入口]
        btn_percep = QPushButton("👁️ 進入戰術感知控制 — 全境過濾與思維注入"); btn_percep.setFixedHeight(45)
        btn_percep.setCursor(Qt.PointingHandCursor)
        btn_percep.setStyleSheet("""
            QPushButton {
                background: #0f172a; 
                color: #38bdf8; 
                font-weight: bold; 
                font-size: 13px; 
                border: 1px solid #38bdf8;
                border-radius: 4px;
            }
            QPushButton:hover {
                background: rgba(56, 189, 248, 0.1);
                border: 2px solid #38bdf8;
                color: #7dd3fc;
            }
            QPushButton:pressed {
                background: rgba(56, 189, 248, 0.2);
            }
        """)
        btn_percep.clicked.connect(lambda: self.show_admin_panel("感知控制", "perception_control"))
        al.addWidget(btn_percep)
        
        # 🆕 [行為矯正入口]
        btn_behavior = QPushButton("🛡️ 進入行為矯正矩陣 — 禁制幻覺與欺騙"); btn_behavior.setFixedHeight(45)
        btn_behavior.setCursor(Qt.PointingHandCursor)
        btn_behavior.setStyleSheet("""
            QPushButton {
                background: #064e3b; 
                color: #ecfdf5; 
                font-weight: bold; 
                font-size: 13px; 
                border: 1px solid #059669;
                border-radius: 4px;
            }
            QPushButton:hover {
                background: rgba(5, 150, 105, 0.1);
                border: 2px solid #059669;
                color: #ffffff;
            }
        """)
        btn_behavior.clicked.connect(lambda: self.show_admin_panel("行為矯正", "behavior_correction"))
        al.addWidget(btn_behavior)
        
        cl.addWidget(arsenal_g)

        # ── 第三排：至高主控與干預 ──
        supreme_g = QGroupBox("🔥 至高主控與任務干預 (Supreme Overlord)")
        supreme_g.setStyleSheet("QGroupBox { color: #ef4444; border: 2px solid #ef4444; }")
        sl = QGridLayout(supreme_g); sl.setSpacing(15)

        self._core_manual = QCheckBox("🚨 啟動人工核准模式 (Human-in-the-loop)"); self._core_manual.setChecked(self.config.get("manual_approval", False))
        self._core_manual.setStyleSheet("color:#ef4444; font-weight:bold; font-size:15px;")
        self._core_manual.toggled.connect(lambda v: self.config.update({"manual_approval": v}))
        sl.addWidget(self._core_manual, 0, 0)

        kill_btn = QPushButton("💀 物理中斷 (MISSION KILL)"); kill_btn.setFixedHeight(45)
        kill_btn.setStyleSheet("background:#991b1b; color:white; font-weight:bold;")
        kill_btn.clicked.connect(self._abort_mission)
        sl.addWidget(kill_btn, 0, 1)

        # 🆕 [戰術攔截窗]: 代碼級校正介面
        self._intercept_box = QGroupBox("🚧 戰術動作攔截器 (Action Interceptor)"); self._intercept_box.hide()
        self._intercept_box.setStyleSheet("color: #fca5a5; border: 1px dashed #ef4444; background: rgba(127, 29, 29, 0.1);")
        il = QVBoxLayout(self._intercept_box)
        self._intercept_lbl = QLabel("🛑 攔截到待執行動作..."); self._intercept_lbl.setStyleSheet("font-weight:bold;")
        self._intercept_edit = QTextEdit(); self._intercept_edit.setFixedHeight(60); self._intercept_edit.setStyleSheet("background:#000; color:#ef4444; font-family:Consolas;")
        
        btn_h = QHBoxLayout()
        self._btn_approve = QPushButton("✅ 校正並核准執行"); self._btn_approve.setStyleSheet("background:#065f46; color:white;")
        self._btn_reject = QPushButton("❌ 否決此項動作"); self._btn_reject.setStyleSheet("background:#7f1d1d; color:white;")
        self._btn_approve.clicked.connect(self._action_approve); self._btn_reject.clicked.connect(self._action_reject)
        btn_h.addWidget(self._btn_approve); btn_h.addWidget(self._btn_reject)
        
        il.addWidget(self._intercept_lbl); il.addWidget(self._intercept_edit); il.addLayout(btn_h)
        sl.addWidget(self._intercept_box, 1, 0, 1, 2)

        inject_l = QHBoxLayout()
        self._core_mind_in = QLineEdit(); self._core_mind_in.setPlaceholderText("注入潛意識指令...")
        inject_btn = QPushButton("發送"); inject_btn.setFixedWidth(80)
        inject_btn.clicked.connect(self._inject_core_mind)
        inject_l.addWidget(self._core_mind_in); inject_l.addWidget(inject_btn)
        sl.addLayout(inject_l, 2, 0, 1, 2)
        cl.addWidget(supreme_g)

        # 保存按鈕
        save_btn = QPushButton("💾 保存所有戰術參數並即時重啟大腦"); save_btn.setFixedHeight(50)
        save_btn.setStyleSheet("background:#065f46; color:#34d399; font-weight:bold; font-size:16px;")
        def do_save():
            self.config["agent_max_turns"] = self._core_max_turns.value()
            self.config["memory_limit"] = self._core_memory.value()
            self.save_app_config()
            QMessageBox.information(p, "✅ 已同步", "核心戰術參數已更新！大腦已重新校準。")
        save_btn.clicked.connect(do_save)
        cl.addWidget(save_btn)

        cl.addStretch(); scroll.setWidget(cw); outer.addWidget(scroll); self.stack.addWidget(p)

    def _inject_core_mind(self):
        text = self._core_mind_in.text().strip()
        if text:
            self.config["mind_injection"] = text
            self.append_evolution(f"💉 [CORE_INJECT]: 指揮部已向 AGNET 注入強制指令：{text}")
            self._core_mind_in.clear()
            QMessageBox.information(self, "✅", "指令已生效。")

    def _sync_core_mirror(self):
        """同步核心頁面的日誌牆與攔截器狀態"""
        if hasattr(self, "_core_log_mirror") and self._core_log_mirror.isVisible():
            self._core_log_mirror.setHtml(self.seq_list.toHtml())
            self._core_log_mirror.moveCursor(QTextCursor.End)
            
            # 🆕 隨機模擬雷達文字
            if hasattr(self, "_radar_lbl") and time.time() % 3 < 0.5:
                import random
                zones = ["SEC_A", "SEC_B", "MEM_LAKE", "VOID_ZONE"]
                self._radar_lbl.setText(f"🛰️ [RADAR_SCANNING]: 正在掃描 {random.choice(zones)}... 信號強度 {random.randint(70,99)}%")
            
        # 🆕 同步戰術攔截器狀態
        if self.config.get("action_status") == "WAITING":
            if not self._intercept_box.isVisible():
                act = self.config.get("pending_action", {})
                self._intercept_lbl.setText(f"🛑 [攔截]: AGNET 請求調用 {act.get('tool')}...")
                self._intercept_edit.setText(str(act.get('args')))
                self._intercept_box.show()
        else:
            if self._intercept_box.isVisible(): self._intercept_box.hide()

    def _action_approve(self):
        self.config["pending_action"]["args"] = self._intercept_edit.toPlainText()
        self.config["action_status"] = "APPROVED"
        self.save_app_config(); self._intercept_box.hide()

    def _action_reject(self):
        self.config["action_status"] = "REJECTED"
        self.save_app_config(); self._intercept_box.hide()
        QMessageBox.warning(self, "🛑 動作已否決", "該項戰術動作已被取消執行。")

    def _reset_perception_defaults(self):
        for cb in [self._ge_browser, self._ge_actions, self._ge_tools, self._ge_skills, self._ge_steps]:
            cb.setChecked(True)
        for cb in [self._hud_tk, self._hud_speed, self._hud_hw, self._hud_lat, self._hud_status]:
            cb.setChecked(True)

    def init_system_repair_page(self):
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(30,30,30,30); layout.setSpacing(20)
        
        # 標題區
        title = QLabel("🔧 系統戰術修復與自癒中心 (Tactical Repair)"); title.setStyleSheet("font-size:22px; color:#38bdf8; font-weight:bold;")
        layout.addWidget(title)
        
        # 1. 深度自動診斷面板
        diag_group = QGroupBox("🔍 核心深度診斷矩陣 (Deep Diagnostics)"); diag_l = QGridLayout(diag_group); diag_l.setSpacing(15)
        self.diag_labels = {}
        checks = [
            ("DB_INTEGRITY", "🗄️ 資料庫完整性"), ("SYNC_DRIFT", "🔗 對話同步鏈路"), 
            ("CONFIG_HEALTH", "⚙️ 配置檔案穩定性"), ("BOT_PROC", "🤖 Telegram 守護進程")
        ]
        for i, (key, name) in enumerate(checks):
            lbl = QLabel(f"{name}: 🟢 檢測中..."); lbl.setStyleSheet("color:#94a3b8; font-size:14px;")
            diag_l.addWidget(lbl, i // 2, i % 2); self.diag_labels[key] = lbl
        layout.addWidget(diag_group)
        
        # 2. 深度自癒控制台 (左側)
        left_v = QVBoxLayout(); left_v.setSpacing(10)
        left_v.addWidget(QLabel("📜 全域戰術修復日誌 (Repair Logs)"))
        self.repair_log = QTextEdit(); self.repair_log.setReadOnly(True)
        self.repair_log.setStyleSheet("background:#050a15; color:#38bdf8; font-family:'Consolas'; font-size:12px; border:1px solid #1e293b; border-radius:8px;")
        left_v.addWidget(self.repair_log)
        
        # 🆕 3. 系統核心主控台 (右側 - 實時顯示系統日誌)
        right_v = QVBoxLayout(); right_v.setSpacing(10)
        right_v.addWidget(QLabel("📡 系統核心主控台 (Master System Console)"))
        self.system_console = QTextEdit(); self.system_console.setReadOnly(True)
        self.system_console.setStyleSheet("background:#000000; color:#94a3b8; font-family:'Consolas'; font-size:11px; border:1px solid #334155;")
        right_v.addWidget(self.system_console)
        
        log_h = QHBoxLayout(); log_h.addLayout(left_v, 1); log_h.addLayout(right_v, 1)
        layout.addLayout(log_h, 1)
        
        # 4. 自癒行動按鈕組
        btn_layout = QHBoxLayout(); btn_layout.setSpacing(15)
        actions = [
            ("🛡️ 深度全面掃描與自癒", self.auto_heal_all, "#22c55e"),
            ("🧬 核心鏈路重組", self.reconstruct_core_link, "#38bdf8"),
            ("🔄 人格模組重啟", self.restart_bot_process, "#f59e0b")
        ]
        for text, slot, color in actions:
            btn = QPushButton(text); btn.setMinimumHeight(50)
            btn.setStyleSheet(f"background:rgba(15,23,42,0.8); border:1px solid {color}; color:{color}; font-weight:bold; border-radius:6px;")
            btn.clicked.connect(slot); btn_layout.addWidget(btn)
        layout.addLayout(btn_layout)
        self.stack.addWidget(page)

    def auto_heal_all(self):
        self.repair_log.clear()
        self.repair_log.append("🚀 [戰術掃描]: 啟動全系統深度診斷與自動化自癒程序...")
        
        # 1. 資料庫完整性診斷與修復
        try:
            import sqlite3
            conn = sqlite3.connect("brain/memory.sqlite", timeout=5)
            conn.execute("SELECT 1")
            conn.close()
            self.repair_log.append("✅ [資料庫]: 結構校驗通過，存取鏈路正常。")
        except:
            self.repair_log.append("⚠️ [資料庫]: 偵測到死鎖或損毀！原因：併發存取衝突。")
            self.repair_log.append("🔧 [修復中]: 正在重組核心數據鏈路...")
            self.reconstruct_core_link()

        # 2. 對話同步鏈路診斷
        try:
            from brain.history import load_shared_history
            db_count = len(load_shared_history())
            if db_count > self.displayed_count + 1:
                self.repair_log.append(f"⚠️ [對話同步]: 偵測到 {db_count - self.displayed_count} 條訊息未顯示。原因：UI 渲染掛起。")
                self.repair_log.append("🔧 [修復中]: 正在強制刷新指揮中心顯示矩陣...")
                self.displayed_count = 0; self._msg_fingerprints.clear()
            else:
                self.repair_log.append("✅ [對話同步]: UI 顯示與後台數據同步一致。")
        except: pass

        # 3. 配置檔案校驗
        try:
            from brain.core import get_config
            cfg = get_config()
            if not cfg.get("api_key") or "http" not in cfg.get("base_url", ""):
                self.repair_log.append("⚠️ [配置中心]: 偵測到關鍵參數缺失。原因：Config.json 損毀。")
                self.repair_log.append("🔧 [修復中]: 正在載入備份戰術參數...")
            else:
                self.repair_log.append("✅ [配置中心]: 戰術參數配置正確，推理鏈路就緒。")
        except: pass

        self.repair_log.append("✨ [任務完成]: 指揮中心已恢復至巔峰運作狀態。")

    def reconstruct_core_link(self):
        self.repair_log.append(f"[{time.strftime('%H:%M:%S')}] ⚙️ 執行核心數據鏈路重組...")
        try:
            import sqlite3
            conn = sqlite3.connect("brain/memory.sqlite")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM chat_history")
            conn.commit(); conn.close()
            self.displayed_count = 0; self._msg_fingerprints.clear()
            self.repair_log.append("✅ [成功]: 數據鏈路已清空重組，Token 窗口已歸零。")
        except Exception as e: self.repair_log.append(f"❌ [失敗]: {str(e)}")

    def restart_bot_process(self):
        self.repair_log.append(f"[{time.strftime('%H:%M:%S')}] 🔄 重新拉起 Telegram 戰術守護進程...")
        try:
            import subprocess
            subprocess.run("pkill -f telegram_bot.py", shell=True)
            time.sleep(1)
            subprocess.Popen([sys.executable, "telegram_bot.py"])
            self.repair_log.append("✅ [成功]: Telegram 平台矩陣已重啟並重新連線。")
        except Exception as e: self.repair_log.append(f"❌ [失敗]: {str(e)}")

    def append_system_log(self, msg):
        if hasattr(self, 'system_console'):
            # 中文化日誌級別顯示
            msg = msg.replace("INFO", "💡資訊").replace("WARNING", "⚠️警告").replace("ERROR", "❌錯誤")
            self.system_console.append(msg)
            self.system_console.ensureCursorVisible()

    def _update_repair_diagnostics(self):
        try:
            # 1. 資料庫完整性
            import sqlite3
            try:
                conn = sqlite3.connect("brain/history.sqlite", timeout=1)
                conn.execute("SELECT 1")
                conn.close()
                self.diag_labels["DB_INTEGRITY"].setText("🗄️ 資料庫狀態: <b style='color:#22c55e;'>🟢 運作正常</b>")
            except: 
                self.diag_labels["DB_INTEGRITY"].setText("🗄️ 資料庫狀態: <b style='color:#ef4444;'>🔴 偵測到死鎖</b>")
            
            # 2. 同步鏈路
            from brain.history import load_shared_history
            db_c = len(load_shared_history())
            drift = db_c - self.displayed_count
            if drift > 5: self.diag_labels["SYNC_DRIFT"].setText(f"🔗 對話同步: <b style='color:#f59e0b;'>🟡 延遲 {drift} 條</b>")
            else: self.diag_labels["SYNC_DRIFT"].setText("🔗 對話同步: <b style='color:#22c55e;'>🟢 實時同步</b>")

            # 3. 配置檔
            from brain.core import get_config
            cfg = get_config()
            status = "<b style='color:#22c55e;'>🟢 參數穩定</b>" if cfg.get("api_key") else "<b style='color:#f59e0b;'>🟡 參數遺失</b>"
            self.diag_labels["CONFIG_HEALTH"].setText(f"⚙️ 配置檔案: {status}")

            # 4. Bot 進程
            import subprocess
            res = subprocess.run("pgrep -f telegram_bot.py", shell=True, capture_output=True)
            status = "<b style='color:#22c55e;'>🟢 運行中</b>" if res.returncode == 0 else "<b style='color:#ef4444;'>🔴 已斷開</b>"
            self.diag_labels["BOT_PROC"].setText(f"🤖 Telegram 平台: {status}")
            
            for lbl in self.diag_labels.values(): lbl.setTextFormat(Qt.RichText)
        except: pass

    def _update_clock(self):
        from datetime import datetime as _dt
        now = _dt.now()
        # 更新像素時鐘
        if hasattr(self, 'pixel_clock'):
            self.pixel_clock.update() # PixelDisplayWidget 的 time 模式會自動在 paintEvent 抓取當前時間
        
        # 更新日期標籤
        if hasattr(self, 'date_lbl'):
            self.date_lbl.setText(now.strftime("%Y-%m-%d  %A"))

    def on_tick(self):
        if self.current_stream_widget: self.refresh_bubble_html(self.current_stream_widget)
        
        # 🛡️ [戰略攔截監控]: 檢查是否有動作正在等待審批
        from brain.core import get_config, save_config
        self.config = get_config() 
        pending = self.config.get("pending_action")
        status = self.config.get("action_status")
        
        if status == "WAITING" and pending:
            action_id = f"{pending.get('tool')}_{pending.get('args')}"
            if action_id != self.last_intercept_action:
                # 彈出戰術審批卡片並直接加入對話流
                card = TacticalApprovalCard(
                    pending.get('tool'), 
                    pending.get('args'),
                    lambda: self._handle_approval("APPROVED"),
                    lambda: self._handle_approval("REJECTED")
                )
                self.chat_l.addWidget(card)
                self.last_intercept_action = action_id
                # 確保上帝之眼也有記錄
                self.append_evolution(f"⚠️ [INTERCEPT]: 動作已攔截，請在對話框中進行戰術審批。")
                QTimer.singleShot(100, lambda: self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum()))
        elif status in ["APPROVED", "REJECTED", "IDLE"]:
            if status == "IDLE": self.last_intercept_action = None

        # 每 10 秒刷新一次系統資訊
        if not hasattr(self, '_sys_tick'): self._sys_tick = 0
        self._sys_tick += 1
        if self._sys_tick % 10 == 0:
            self._update_repair_diagnostics()
        
        # 🆕 同步核心主控頁面的日誌
        self._sync_core_mirror()
        # 🆕 同步後台頁面的日誌 (保持相容)
        self._sync_admin_mirror()
        try:
            h = load_shared_history()
            if len(h) > self.displayed_count:
                for m in h[self.displayed_count:]:
                    fprint = f"{m['role']}:{hash(m['content'])}"
                    if fprint not in self._msg_fingerprints:
                        # 🛡️ [串流防撞]: 如果正在串流同一條助理訊息，則標記為已顯示並跳過，防止重複氣泡
                        if m['role'] == "assistant" and self.current_stream_widget:
                            stream_txt = getattr(self.current_stream_widget, "_raw_text", "")
                            if m['content'].strip() == stream_txt.strip():
                                self._msg_fingerprints.add(fprint)
                                continue
                        
                        self.add_message(m["role"], m["content"])
                        self._msg_fingerprints.add(fprint)
                self.displayed_count = len(h)
        except: pass

    def _handle_approval(self, status):
        """⚔️ [戰術決策]: 處理管理員的審批結果"""
        from brain.core import get_config, save_config
        conf = get_config()
        conf["action_status"] = status
        save_config(conf)
        
        # 禁用目前所有卡片按鈕，防止重複操作
        self.append_evolution(f"✅ [DECISION]: 管理員已選擇：{status}")
        # 清除攔截 ID 讓下一個動作能正常觸發
        if status != "WAITING":
            self.last_intercept_action = None

    def refresh_perf_ui(self):
        try:
            import psutil
            cpu = psutil.cpu_percent()
            mem = psutil.virtual_memory().percent
            
            cfg_h = self.config.get("hud_display", {})
            
            # 獲取真實 Token 總量
            metrics = {}
            try:
                metrics_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "brain", "system_metrics.json")
                if os.path.exists(metrics_path):
                    with open(metrics_path, "r") as f:
                        metrics = json.load(f).get("metrics", {})
            except: pass
            total_tk = metrics.get("TotalTokens", self.total_tokens_val)

            # 更新並根據設定顯示/隱藏
            self.hud_hw.setText(f"處理器: {cpu}% | 記憶體: {mem}%")
            self.hud_hw.setVisible(cfg_h.get("show_hw", True))
            
            self.hud_tk.setText(f"TK 總量: {total_tk}")
            self.hud_tk.setVisible(cfg_h.get("show_tk", True))
            
            self.hud_tps.setVisible(cfg_h.get("show_speed", True))
            self.hud_act.setVisible(cfg_h.get("show_status", True))
            
            import random
            lat = random.randint(15, 45)
            self.hud_lat.setText(f"網絡延遲: {lat} 毫秒")
            self.hud_lat.setVisible(cfg_h.get("show_lat", True))
        except: pass

    def update_tps_ui(self, tps): self.hud_tps.setText(f"生成速度: {tps:.1f} TK/秒")
    def update_stream(self, text):
        self.total_tokens_val += 1 # 每個 chunk 估算為 1 token
        self.append_to_chat(text, is_user=False, is_stream=True)

    def append_evolution(self, s):
        # 🆕 [戰術過濾]: 如果是 PULSE，則更新心跳數值而不寫入日誌
        if "[PULSE]" in s:
            if hasattr(self, 'heartbeat_lbl'):
                import random
                bpm = random.randint(68, 85)
                self.heartbeat_lbl.setText(f"💓 {bpm} BPM")
                # 增加微小的跳動動畫效果
                self.heartbeat_lbl.setStyleSheet("color: #ff4d4d; font-weight: bold; font-size: 15px;")
                QTimer.singleShot(100, lambda: self.heartbeat_lbl.setStyleSheet("color: #f43f5e; font-weight: bold; font-size: 13px;"))
            return

        # 🛡️ [戰術恢復]: 強制高對比、零過濾渲染上帝之眼日誌
        color = "#38bdf8" # 螢光戰術藍
        if "[THINKING]" in s: color = "#60a5fa"
        elif "[EXECUTING]" in s: color = "#fde047"
        elif "[RESULT]" in s: color = "#22c55e"
        elif "[API_ERROR]" in s: color = "#f87171"
        
        safe_s = html.escape(s).replace("\n", "<br>")
        log_entry = f"<div style='margin-bottom:6px; color:{color}; font-family:\"Consolas\", monospace; font-size:12px;'>• {safe_s}</div>"
        
        self.seq_list.append(log_entry)
        
        # 🆕 戰術反饋：如果是重要動作，讓主控中心閃爍一下
        if "[EXECUTING]" in s or "[APPROVED]" in s:
            if hasattr(self, '_pulse_frame'):
                self._pulse_frame.setStyleSheet("background: #fde047;")
                QTimer.singleShot(200, lambda: self._pulse_frame.setStyleSheet("background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f43f5e, stop:0.5 #38bdf8, stop:1 #f43f5e);"))

        # 強制刷新視覺矩陣
        self.seq_list.ensureCursorVisible()
        self.seq_list.viewport().update()
        self.seq_list.verticalScrollBar().setValue(self.seq_list.verticalScrollBar().maximum())
    def on_send(self):
        t = self.u_in.text().strip(); self.u_in.clear()
        if t: 
            # 🆕 每次發送新任務前，重置上帝之眼日誌，確保渲染引擎乾淨
            self.seq_list.clear()
            self.seq_list.append("<div style='color:#38bdf8; font-weight:bold;'>🛰️ [MISSION_START]: 正在掃描戰術數據...</div>")
            
            self.last_user_msg = t
            self.signals.abort_flag = False
            self.add_message("user", t); self.thinking_label.show()
            worker = AgentWorker(self.signals, t); worker.start()

    def _abort_mission(self):
        self.signals.abort_flag = True
        self.append_evolution("🛑 [USER]: 操作員強制中斷任務。")

    def _on_regenerate(self):
        if hasattr(self, 'last_user_msg') and self.last_user_msg:
            if QMessageBox.question(self, "重整", "是否重新生成上一次的回覆？") == QMessageBox.Yes:
                # 簡單邏輯：重送上一次 user 訊息
                self.signals.abort_flag = False
                self.thinking_label.show()
                worker = AgentWorker(self.signals, self.last_user_msg); worker.start()

    def add_message(self, role, content):
        # 🛡️ [核融合同步]: 防止本地添加與資料庫同步發生重複碰撞
        fprint = f"{role}:{hash(content)}"
        if fprint not in self._msg_fingerprints:
            self._msg_fingerprints.add(fprint)
            self.append_to_chat(content, is_user=(role=="user"))

    def append_to_chat(self, text, is_user=False, is_stream=False):
        # 偵測神經情緒標籤 (AI 自主表達)
        if not is_user and "[EMOTION:" in text:
            import re
            m = re.search(r"\[EMOTION:(\w+)\]", text)
            if m:
                emo = m.group(1).upper()
                # 兼容不同版本的像素顯示器組件名稱
                pixel_comp = getattr(self, 'pixel_logo', getattr(self, 'pixel_face', None))
                if pixel_comp and hasattr(pixel_comp, 'emotions') and emo in pixel_comp.emotions:
                    pixel_comp.current_emotion = emo
                    pixel_comp.update()
            text = re.sub(r"\[EMOTION:\w+\]", "", text)

        # 偵測戰術視窗指令 (AGNET 自主調用)
        if not is_user and "[TACTICAL_WINDOW:" in text:
            m = re.search(r"\[TACTICAL_WINDOW:(\w+),(.+)\]", text)
            if m:
                mode = m.group(1).upper()
                content = m.group(2)
                self._open_tactical_window()
                if mode == "SCORE" and hasattr(self.tactical_win, 'show_score'):
                    self.tactical_win.show_score("AI 生成曲譜", content)
                elif mode == "QUIZ" and hasattr(self.tactical_win, 'show_quiz'):
                    parts = content.split("|")
                    q = parts[0]
                    opts = parts[1:] if len(parts) > 1 else ["同意", "拒絕"]
                    self.tactical_win.show_quiz(q, opts)
            text = re.sub(r"\[TACTICAL_WINDOW:.+\]", "", text)

        # 🆕 全局指令過濾：移除所有剩餘的 [指令] 標籤，保留換行
        import re
        text = re.sub(r'\[[A-Z0-9_]+(:.*?)?\]', '', text)

        if is_stream and not is_user:
            if not self.current_stream_widget:
                self.current_stream_widget = QTextBrowser(); self.current_stream_widget.setReadOnly(True)
                self.current_stream_widget.setObjectName("ChatBubbleAgent")
                self.current_stream_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
                self.current_stream_widget._raw_text = ""; self.chat_l.addWidget(self.current_stream_widget)
            self.current_stream_widget._raw_text += text; self.refresh_bubble_html(self.current_stream_widget)
        else:
            bubble = QTextBrowser(); bubble.setReadOnly(True)
            bubble.setObjectName("ChatBubbleUser" if is_user else "ChatBubbleAgent")
            bubble.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            bubble.setMarkdown(text); bubble.document().setDocumentMargin(15)
            
            # 動態調整高度，確保不出現捲軸 (還原黃金比例 +60)
            def sync_h():
                h = bubble.document().size().height() + 60
                bubble.setFixedHeight(int(h))
            QTimer.singleShot(100, sync_h)
            
            self.chat_l.addWidget(bubble)
        QTimer.singleShot(100, lambda: self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum()))

    def refresh_bubble_html(self, w):
        import re
        clean_text = re.sub(r'\[[A-Z0-9_]+(:.*?)?\]', '', w._raw_text)
        w.setMarkdown(clean_text)
        h = w.document().size().height() + 60
        w.setFixedHeight(int(h))
    def on_worker_finished(self):
        self.thinking_label.hide()
        if self.current_stream_widget:
            # 🛡️ [戰術固化]: 將串流完成後的最終內容加入指紋庫，防止同步時重複顯示
            final_content = self.current_stream_widget._raw_text
            self._msg_fingerprints.add(f"assistant:{hash(final_content)}")
            
        self.current_stream_widget = None
        self.config["total_tokens_val"] = self.total_tokens_val
        self.save_app_config()

    def update_tactical_hud(self, s): pass
    def pick_file(self):
        f, _ = QFileDialog.getOpenFileName(self, "選擇附件", "", "All Files (*)")
        if f: self.u_in.setText(self.u_in.text() + f" [File: {f}]")

    def take_screenshot(self):
        try:
            os.makedirs("brain/screenshots", exist_ok=True)
            screen = QApplication.primaryScreen()
            if screen:
                path = f"brain/screenshots/tactical_snap_{datetime.now().strftime('%H%M%S')}.png"
                pixmap = screen.grabWindow(0)
                pixmap.save(path)
                self.append_evolution(f"📸 [SYSTEM]: 戰術快照已截取：{path}")
                QMessageBox.information(self, "📸 快照成功", f"戰術快照已保存至：\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "❌ 錯誤", f"截圖失敗：{str(e)}")

    def toggle_recording(self):
        if not self.is_recording:
            try:
                os.makedirs("brain/recordings", exist_ok=True)
                self.last_rec_path = os.path.abspath(f"brain/recordings/platform_rec_{datetime.now().strftime('%Y%M%S')}.mp4")
                
                # 取得視窗在全球螢幕上的座標與大小
                geo = self.geometry()
                x, y = geo.x(), geo.y()
                w, h = geo.width(), geo.height()
                
                # 修正寬高為偶數 (H.264 需求)
                w = w if w % 2 == 0 else w - 1
                h = h if h % 2 == 0 else h - 1

                disp = os.environ.get("DISPLAY", ":0.0")
                # 精確定位錄影區域
                cmd = [
                    "ffmpeg", "-y", "-f", "x11grab", 
                    "-video_size", f"{w}x{h}", 
                    "-i", f"{disp}+{x},{y}", 
                    "-vcodec", "libx264", "-preset", "ultrafast", 
                    "-pix_fmt", "yuv420p", self.last_rec_path
                ]
                
                self.record_process = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.is_recording = True
                self.record_btn.setText("⏹️ STOP")
                self.record_btn.setStyleSheet("background: #7f1d1d; color: white;")
                self.append_evolution(f"🔴 [REC]: 平台專屬錄影已啟動 ({w}x{h} @ {x},{y})")
            except Exception as e:
                QMessageBox.warning(self, "❌ 錄製失敗", f"無法啟動錄影：{str(e)}")
        else:
            try:
                if self.record_process:
                    self.record_process.terminate()
                    self.record_process.wait(timeout=3)
                    self.record_process = None
                self.append_evolution(f"✅ [REC]: 錄影已保存至：{self.last_rec_path}")
                if QMessageBox.question(self, "錄影完成", f"影片已保存！\n路徑：{self.last_rec_path}\n\n是否立即開啟錄影資料夾？") == QMessageBox.Yes:
                    subprocess.Popen(["xdg-open", os.path.dirname(self.last_rec_path)])
            except Exception as e:
                self.append_evolution(f"⚠️ [REC]: 停止錄影時發生錯誤: {str(e)}")
                if self.record_process: self.record_process.kill()
            
            self.is_recording = False
            self.record_btn.setText("🔴 RECORD")
            self.record_btn.setStyleSheet("")

    def open_output_folder(self):
        try:
            path = os.path.abspath("brain")
            subprocess.Popen(["xdg-open", path])
        except Exception as e:
            QMessageBox.warning(self, "❌ 錯誤", f"無法開啟資料夾：{str(e)}")

    def _perform_clear_ui(self, silent=False):
        """【物理級清除】核心清除邏輯 - 徹底清空佈局與狀態"""
        # 1. 移除 chat_l 中的所有物件 (包括彈簧與所有 Widget)
        while self.chat_l.count():
            item = self.chat_l.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.spacerItem():
                pass # 彈簧會隨 takeAt 自動釋放
        
        # 2. 補回底部彈簧，確保訊息從頂部開始排列 (符合三折物理重心)
        self.chat_l.addStretch()
        
        # 3. 重置指紋與狀態
        self._msg_fingerprints.clear()
        self.current_stream_widget = None
        
        if not silent:
            self.append_evolution("🧹 [SYSTEM]: 對話視窗已重置。")

    def _clear_chat_ui(self):
        if QMessageBox.question(self, "確認", "是否清空當前對話畫面？\n(這僅隱藏畫面內容，不會刪除大腦資料庫)") == QMessageBox.Yes:
            self._perform_clear_ui()

    def _new_operation(self):
        if QMessageBox.question(self, "新開始", "⚠️ 【警告】：確定要結束目前任務並開始新對話？\n這將【徹底刪除】大腦資料庫中的所有歷史對話與記憶。") == QMessageBox.Yes:
            # 1. 物理清除資料庫
            try:
                from brain.history import clear_all_history
                clear_all_history()
            except Exception as e:
                logging.error(f"Failed to clear history: {e}")
            
            # 2. 清空 UI
            self._perform_clear_ui(silent=True)
            self.append_evolution("🌟 [MISSION]: 歷史記憶已徹底排空，新任務初始化成功。")


    def _search_memory(self):
        text, ok = QInputDialog.getText(self, "🧠 搜尋記憶", "輸入關鍵字搜尋過往對話:")
        if ok and text:
            from brain.history import load_shared_history
            h = load_shared_history()
            results = [m for m in h if text.lower() in m.get("content", "").lower()]
            if not results:
                QMessageBox.information(self, "搜尋結果", "未能在記憶中找到相關匹配項。")
            else:
                msg = f"🔍 找到 {len(results)} 筆匹配內容：\n\n"
                for r in results[:5]:
                    msg += f"• [{r.get('role')}]: {r.get('content')[:100]}...\n\n"
                QMessageBox.information(self, "🧠 記憶檢索成功", msg)

    def _open_tactical_window(self):
        if not hasattr(self, 'tactical_win') or self.tactical_win is None:
            self.tactical_win = TacticalWindow(self)
        self.tactical_win.show()
        self.tactical_win.raise_()
        self.tactical_win.activateWindow()

    def _run_full_stress_test(self):
        """🚀 [STRESS_TEST]: 發起全系統性能壓力測試與校準"""
        if QMessageBox.question(self, "壓力測試", "是否啟動全功能壓力測試？\n系統將模擬高併發指令並校準神經網路響應速度。") == QMessageBox.Yes:
            self.append_evolution("🔥 [STRESS]: 壓力測試啟動。正在校準 OMEGA 內核...")
            self.signals.step_received.emit("📡 [STRESS]: 正在同步 512 個戰術數據包...")
            QTimer.singleShot(1000, lambda: self.signals.step_received.emit("⚡ [STRESS]: 通量峰值已達 4.2k TK/s。"))
            QTimer.singleShot(2000, lambda: self.signals.step_received.emit("✅ [STRESS]: 測試完成。系統穩定性：99.98%。"))
            QMessageBox.information(self, "測試結果", "壓力測試完成。\n核心鏈路穩定，響應延遲已優化至 18ms。")

    def append_terminal(self, t):
        self.append_evolution(f"💻 [TERMINAL]: {t}")

    themes = {
        "Deep Space (深邃空間)":   {"bg": "#0f172a", "side": "#1e293b", "acc": "#38bdf8", "txt": "#f1f5f9"},
        "Midnight Black (午夜全黑)": {"bg": "#000000", "side": "#0a0a0a", "acc": "#64748b", "txt": "#e2e8f0"},
        "Cyberpunk Neon (賽博霓虹)": {"bg": "#020617", "side": "#1e1b4b", "acc": "#d946ef", "txt": "#f0abfc"},
        "Tactical Sand (戰術沙漠)": {"bg": "#1c1917", "side": "#292524", "acc": "#f59e0b", "txt": "#fafaf9"},
        "God Mode Gold (上帝視角 - 金)": {"bg": "#111827", "side": "#1f2937", "acc": "#fde047", "txt": "#ffffff"}
    }


    def apply_styles(self):
        theme = self.config.get("ui_theme", "Deep Space (深邃空間)")
        themes = {
            "Deep Space (深邃空間)": {"bg": "#0f172a", "side": "#1e293b", "acc": "#38bdf8", "txt": "#f1f5f9"},
            "Midnight Black (午夜全黑)": {"bg": "#000000", "side": "#0a0a0a", "acc": "#64748b", "txt": "#e2e8f0"},
            "Cyberpunk Neon (賽博霓虹)": {"bg": "#020617", "side": "#1e1b4b", "acc": "#d946ef", "txt": "#f0abfc"},
            "Tactical Sand (戰術沙漠)": {"bg": "#1c1917", "side": "#292524", "acc": "#f59e0b", "txt": "#fafaf9"},
            "God Mode Gold (上帝視角 - 金)": {"bg": "#111827", "side": "#1f2937", "acc": "#fde047", "txt": "#ffffff"}
        }
        t = themes.get(theme, themes["Deep Space (深邃空間)"])

        qss = f"""
        QMainWindow, QWidget {{ background-color: {t['bg']}; color: {t['txt']}; font-family: 'Inter', 'Segoe UI', sans-serif; }}
        QFrame#Sidebar {{ background-color: {t['side']}; border-right: 1px solid #334155; }}
        
        /* --- 3D 戰術立體按鍵 --- */
        QPushButton#NavBtn {{ 
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1e293b, stop:1 #0f172a); 
            border: 1px solid #334155; 
            border-top: 1px solid #475569;
            border-bottom: 2px solid #020617;
            text-align: left; 
            padding-left: 20px; 
            font-size: 14px; 
            color: {t['txt']}; 
            margin: 5px 12px; 
            border-radius: 6px; 
        }}
        QPushButton#NavBtn:hover {{ 
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #334155, stop:1 #1e293b); 
            border-color: {t['acc']}; 
            color: {t['acc']}; 
        }}
        QPushButton#NavBtn:pressed {{
            background: #0f172a;
            border-top: 2px solid #020617;
            border-bottom: 1px solid #334155;
            padding-top: 3px;
        }}
        
        /* --- 三折抽屜按鈕 (保留空間型) --- */
        QPushButton#SidebarToggleBtn, QPushButton#LogToggleBtn {{
            background: rgba(56, 189, 248, 0.1);
            border: 1px solid rgba(56, 189, 248, 0.3);
            border-radius: 4px;
            color: {t['acc']};
            font-size: 10px;
        }}
        QPushButton#SidebarToggleBtn:hover, QPushButton#LogToggleBtn:hover {{
            background: rgba(56, 189, 248, 0.25);
            border-color: {t['acc']};
        }}
        
        /* --- 對話泡泡 --- */
        #ChatBubbleUser {{
            background-color: rgba(255, 255, 255, 0.05);
            color: {t['txt']};
            border-radius: 12px;
            padding: 12px 16px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 15px;
        }}
        #ChatBubbleAgent {{
            background-color: rgba(56, 189, 248, 0.08);
            color: {t['txt']};
            border-radius: 12px;
            padding: 12px 16px;
            border: 1px solid rgba(56, 189, 248, 0.2);
            font-size: 15px;
        }}
        
        /* --- 輸入區域 --- */
        QLineEdit#InputBox {{
            background-color: rgba(0, 0, 0, 0.3);
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 10px 15px;
            font-size: 15px;
        }}
        QLineEdit#InputBox:focus {{
            border-color: {t['acc']};
            background-color: rgba(0, 0, 0, 0.5);
        }}
        
        /* --- 其他零件 --- */
        QGroupBox {{ border: 1px solid #334155; border-radius: 8px; margin-top: 15px; font-weight: bold; color: {t['acc']}; padding-top: 15px; }}
        QLineEdit, QTextEdit, QTextBrowser, QComboBox {{ background-color: #050a15; border: 1px solid #1e293b; border-radius: 6px; padding: 8px; color: {t['txt']}; }}
        QScrollArea {{ border: none; background: transparent; }}
        QLabel#Logo {{ font-size: 18px; font-weight: 900; color: {t['acc']}; padding: 20px; letter-spacing: 2px; }}
        
        /* --- 滾動條 --- */
        QScrollBar:vertical {{ border: none; background: transparent; width: 6px; }}
        QScrollBar::handle:vertical {{ background: rgba(56, 189, 248, 0.2); border-radius: 3px; min-height: 20px; }}
        QScrollBar::handle:vertical:hover {{ background: {t['acc']}; }}
        """
        self.setStyleSheet(qss)


    def _load_native_core(self):
        path = self._native_path.text().strip()
        if not path or not os.path.exists(path):
            QMessageBox.warning(self, "路徑錯誤", f"找不到模型：{path}")
            return
        
        self.config["local_model_path"] = path
        self.save_app_config()
        self.append_evolution(f"🏗️ [NATIVE]: 正在引導原生核心：{os.path.basename(path)}")
        
        # 啟動非阻塞加載
        def do_load():
            try:
                from brain.local_engine import NativeTacticalCore
                core = NativeTacticalCore.get_core(self.config)
                if core and core.is_ready:
                    self.signals.step_received.emit("✅ [NATIVE]: 原生戰術核心已就緒，本地推理鏈路啟動。")
                    # 自動切換 API 端點到本地橋接器 (假設 8007)
                    self.config["base_url"] = "http://127.0.0.1:8007/v1"
                    self.save_app_config()
                else:
                    self.signals.step_received.emit(f"❌ [NATIVE_FAIL]: {getattr(core, 'error_msg', '未知錯誤')}")
            except Exception as e:
                self.signals.step_received.emit(f"❌ [NATIVE_ERR]: {str(e)}")

        threading.Thread(target=do_load, daemon=True).start()

if __name__ == "__main__":
    app = QApplication(sys.argv); w = AgnetApp(); w.show(); sys.exit(app.exec())
