import os
import re
import subprocess
from typing import List, Dict, Any, Optional

def ls_project(directory: str = ".") -> str:
    """
    列出專案目錄結構，並提供文件摘要（模擬 Claude Code 的 ls 技能）。
    """
    try:
        result = []
        for root, dirs, files in os.walk(directory):
            # 排除隱藏目錄
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            level = root.replace(directory, '').count(os.sep)
            indent = ' ' * 4 * level
            result.append(f"{indent}📂 {os.path.basename(root)}/")
            
            sub_indent = ' ' * 4 * (level + 1)
            for f in files:
                if f.startswith('.'): continue
                # 簡單的摘要邏輯：如果是程式碼，讀取前兩行註解
                summary = ""
                file_path = os.path.join(root, f)
                try:
                    if f.endswith(('.py', '.js', '.ts', '.html', '.css', '.txt', '.json')):
                        with open(file_path, 'r', encoding='utf-8') as content:
                            lines = content.readlines()[:3]
                            summary = " - " + " ".join([l.strip() for l in lines if l.strip()])
                except: pass
                result.append(f"{sub_indent}📄 {f}{summary[:100]}")
            
            # 限制深度避免過長
            if level > 2: break
            
        return "\n".join(result)
    except Exception as e:
        return f"Error listing directory: {str(e)}"

def grep_search(pattern: str, include: str = "*", path: str = ".") -> str:
    """
    使用正則表達式在專案中搜索特定內容（模擬 Claude Code 的 grep 技能）。
    """
    try:
        # 如果系統有 ripgrep (rg)，優先使用
        try:
            cmd = ["rg", "--line-number", "--column", "--context", "1", pattern, path, "-g", include]
            output = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True)
            return output
        except (subprocess.CalledProcessError, FileNotFoundError):
            # 退而求其次使用內建邏輯 (簡單版)
            matches = []
            regex = re.compile(pattern)
            for root, _, files in os.walk(path):
                for f in files:
                    # 簡單過濾
                    if not (include == "*" or any(ext in f for ext in include.replace('*', '').split(','))):
                        continue
                    file_path = os.path.join(root, f)
                    try:
                        with open(file_path, 'r', encoding='utf-8') as content:
                            for i, line in enumerate(content):
                                if regex.search(line):
                                    matches.append(f"{file_path}:{i+1}: {line.strip()}")
                    except: pass
            return "\n".join(matches) if matches else "No matches found."
    except Exception as e:
        return f"Error searching: {str(e)}"

def replace_content(file_path: str, old_str: str, new_str: str) -> str:
    """
    在指定文件中替換內容（模擬 Claude Code 的 edit 技能，支援引號規範化）。
    """
    try:
        if not os.path.exists(file_path):
            return f"Error: File {file_path} does not exist."
            
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # 簡單的引號規範化處理
        if old_str not in content:
            # 嘗試替換引號再找一次
            alt_old = old_str.replace("'", '"')
            if alt_old in content:
                old_str = alt_old
            else:
                alt_old = old_str.replace('"', "'")
                if alt_old in content:
                    old_str = alt_old
                    
        if old_str not in content:
            return f"Error: Could not find the exact text block to replace in {file_path}. Please ensure the 'old_str' matches the file content EXACTLY, including indentation."
            
        new_content = content.replace(old_str, new_str)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
            
        return f"Successfully updated {file_path}."
    except Exception as e:
        return f"Error editing file: {str(e)}"
