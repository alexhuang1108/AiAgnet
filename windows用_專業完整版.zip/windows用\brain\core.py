import os
import json
import urllib.request
import re

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")

def get_config():
    """防崩潰配置讀取：確保 config.json 永遠有效"""
    default_conf = {
        "api_key": "0000",
        "base_url": "http://127.0.0.1:8005/v1",
        "model": "qwen/qwen3.5-35b-a3b",
        "tg_token": ""
    }
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                conf = json.load(f)
                # 強制修正 0005 錯誤
                if "0005" in conf.get("base_url", ""):
                    conf["base_url"] = conf["base_url"].replace("0005", "8005")
                return conf
    except Exception as e:
        print(f"Warning: Config load error: {e}")
    return default_conf

def save_config(conf):
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(conf, f, indent=4)
    except Exception as e:
        print(f"Error saving config: {e}")

def detect_models_sync(url, key):
    """強力偵測：確保埠位正確且連線安全"""
    if not url: return []
    # 智慧清理埠位格式
    clean_url = re.sub(r':0+(\d+)', r':\1', url).strip().rstrip('/')
    
    endpoints = [f"{clean_url}/models", f"{clean_url}/v1/models"]
    for ep in endpoints:
        try:
            req = urllib.request.Request(ep)
            req.add_header("Authorization", f"Bearer {key}")
            with urllib.request.urlopen(req, timeout=3) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode())
                    if 'data' in data:
                        return [m['id'] for m in data['data']]
        except:
            continue
    return []
def push_micro_step(message):
    """📡 [戰術中繼]: 將思考微步推送到日誌，供 GUI 實時讀取"""
    import datetime
    from datetime import datetime
    log_path = os.path.join(BASE_DIR, "brain", "recordings", "thinking.log")
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    ts = datetime.now().strftime("%H:%M:%S")
    with open(log_path, "a") as f:
        f.write(f"[{ts}] {message}\n")
    # 同時打印到標準輸出，方便調試
    print(f"🧠 {message}")

def update_tokens(count):
    """🧠 [代幣計費]: 實時更新並累加 Token 消耗量"""
    metrics_path = os.path.join(BASE_DIR, "brain", "system_metrics.json")
    try:
        data = {"metrics": {"TotalTokens": 0}}
        if os.path.exists(metrics_path):
            with open(metrics_path, "r") as f:
                data = json.load(f)
        
        metrics = data.get("metrics", {})
        current = metrics.get("TotalTokens", 0)
        metrics["TotalTokens"] = current + count
        data["metrics"] = metrics
        
        with open(metrics_path, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"Error updating metrics: {e}")
