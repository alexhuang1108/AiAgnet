
import os
import json
import time
import subprocess
import requests

class NativeTacticalCore:
    _instance = None
    _bridge_process = None
    _port = 8007 # 改用 8007 避開可能的殘留佔用
    _log_handle = None
    
    def __init__(self, model_path, n_gpu_layers=35, n_ctx=4096, n_threads=8, flash_attn=True, use_kv_quant=False):
        self.model_path = model_path
        self.n_gpu_layers = n_gpu_layers
        self.n_ctx = n_ctx
        self.n_threads = n_threads
        self.flash_attn = flash_attn
        self.use_kv_quant = use_kv_quant
        self.is_ready = False
        self.error_msg = "初始化中..."
        
    @classmethod
    def get_core(cls, config):
        path = config.get("local_model_path")
        if not path: 
            print("❌ [NATIVE_CORE]: 無路徑輸入")
            return None
        abs_path = os.path.abspath(path)
        
        # 強制清理殘留
        if cls._bridge_process is None or cls._bridge_process.poll() is not None:
            cls._start_bridge()
            
        if cls._instance is None or cls._instance.model_path != abs_path:
            cls._instance = cls(
                model_path=abs_path,
                n_gpu_layers=config.get("gpu_layers", 35),
                n_ctx=config.get("ctx_size", 4096),
                n_threads=config.get("thread_count", 8),
                flash_attn=config.get("use_flash_attn", True),
                use_kv_quant=config.get("use_kv_quant", False)
            )
            cls._instance.load()
        return cls._instance

    @classmethod
    def _start_bridge(cls):
        print(f"🏗️ [NATIVE_CORE]: Starting bridge on {cls._port}...")
        # 嘗試先清理該端口
        try:
            subprocess.run(["fuser", "-k", f"{cls._port}/tcp"], capture_output=True)
        except: pass
        
        venv_py = "/home/user/Desktop/專案/inference_env/bin/python3"
        bridge_script = "/home/user/Desktop/專案/brain/inference_bridge.py"
        log_file = "/home/user/Desktop/專案/bridge.log"
        
        if cls._log_handle: cls._log_handle.close()
        cls._log_handle = open(log_file, "a") # 用 a 模式避免覆蓋日誌
        
        cls._bridge_process = subprocess.Popen(
            [venv_py, bridge_script, str(cls._port)],
            stdout=cls._log_handle,
            stderr=cls._log_handle,
            text=True
        )
        
        for i in range(15): # 增加等待時間到 15 秒
            try:
                res = requests.get(f"http://127.0.0.1:{cls._port}/health", timeout=1)
                if res.status_code == 200:
                    print(f"✅ [NATIVE_CORE]: Bridge online at {cls._port}")
                    return
            except:
                time.sleep(1)
        print("❌ [NATIVE_CORE]: Bridge timed out.")

    def load(self):
        try:
            print(f"📡 [NATIVE_CORE]: Loading {self.model_path}...")
            res = requests.post(f"http://127.0.0.1:{self._port}/load", json={
                "path": self.model_path,
                "gpu_layers": self.n_gpu_layers,
                "ctx_size": self.n_ctx,
                "thread_count": self.n_threads,
                "use_kv_quant": self.use_kv_quant,
                "use_flash_attn": self.flash_attn
            }, timeout=300)
            
            if res.status_code == 200:
                self.is_ready = True
                self.error_msg = ""
            else:
                try:
                    data = res.json()
                    self.error_msg = data.get("message", "載入失敗")
                except:
                    self.error_msg = f"HTTP {res.status_code}: {res.text}"
                self.is_ready = False
        except Exception as e:
            self.error_msg = f"通訊異常: {str(e)}"
            self.is_ready = False

    def generate(self, messages, stream_callback=None):
        if not self.is_ready:
            return f"❌ [NATIVE_CORE]: {self.error_msg}"
            
        try:
            res = requests.post(f"http://127.0.0.1:{self._port}/generate", json={
                "messages": messages
            }, stream=True, timeout=300)
            
            full_response = ""
            for chunk in res.iter_content(chunk_size=None, decode_unicode=True):
                if chunk:
                    full_response += chunk
                    if stream_callback: stream_callback(chunk)
            
            return full_response
        except Exception as e:
            return f"❌ [NATIVE_CORE]: 通訊失敗 - {str(e)}"
