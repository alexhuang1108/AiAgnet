import os
import json
import time
from datetime import datetime

# 🛡️ [記憶路徑配置]
MEMORY_BASE = "/home/user/.hermes/memory"
EXPERIENCE_LOG = os.path.join(MEMORY_BASE, "tactical_experience.jsonl")

class MemoryEngine:
    @staticmethod
    def initialize():
        """初始化永恆記憶矩陣"""
        os.makedirs(MEMORY_BASE, exist_ok=True)
        if not os.path.exists(EXPERIENCE_LOG):
            with open(EXPERIENCE_LOG, 'w') as f: pass

    @staticmethod
    def commit_experience(query, actions, success, insight):
        """將一次戰術行動固化為長效經驗"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "query": query,
            "actions": actions,
            "success": success,
            "insight": insight
        }
        with open(EXPERIENCE_LOG, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        print(f"🧠 [MEMORY_COMMIT]: 戰術經驗已固化至矩陣。")

    @staticmethod
    def retrieve_experience(keyword, limit=3):
        """從矩陣中檢索相關戰術經驗，並自動標註時效性"""
        if not os.path.exists(EXPERIENCE_LOG): return []
        matches = []
        now = datetime.now()
        with open(EXPERIENCE_LOG, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    entry = json.loads(line)
                    if keyword.lower() in entry['query'].lower() or keyword.lower() in entry['insight'].lower():
                        # 🕰️ [RECENCY_CHECK]: 計算記憶距離
                        memo_date = datetime.fromisoformat(entry['timestamp'])
                        diff_days = (now - memo_date).days
                        recency_marker = f"[RECENCY: {diff_days} days ago]"
                        if diff_days > 30:
                            entry['insight'] = f"⚠️ [STALE_DATA]: {entry['insight']} (此情報已過期，建議重新偵察)"
                        else:
                            entry['insight'] = f"✅ [FRESH_DATA]: {entry['insight']}"
                        
                        entry['insight'] = f"{recency_marker} {entry['insight']}"
                        matches.append(entry)
                except: continue
        return matches[-limit:]

def push_to_long_term_memory(query, actions, success, insight):
    MemoryEngine.initialize()
    MemoryEngine.commit_experience(query, actions, success, insight)
