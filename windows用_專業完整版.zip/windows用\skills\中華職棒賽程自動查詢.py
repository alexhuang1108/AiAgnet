#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中華職棒 (CPBL) 賽程戰況自動查詢工具
作者：神之腦 AI Agent
"""

import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import re

class CPBLQuerier:
    """中華職棒賽程查詢工具"""
    
    def __init__(self):
        self.base_url = "https://www.cpbl.com.tw"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.venv_path = "/home/user/Desktop/專案/venv/bin/python"
    
    def get_match_date(self, date_str=None):
        """取得查詢日期，預設為昨天"""
        if date_str:
            return date_str
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        return yesterday
    
    def fetch_schedule(self, date):
        """抓取指定日期的賽程"""
        url = f"{self.base_url}/schedule/{date}"
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            response.encoding = 'utf-8'
            return response.text
        except Exception as e:
            return f"錯誤：無法取得資料 - {str(e)}"
    
    def parse_games(self, html_content):
        """解析賽程資料"""
        soup = BeautifulSoup(html_content, 'html.parser')
        games = []
        
        # 嘗試尋找賽程項目 (根據實際網站結構調整選擇器)
        game_items = soup.select('.game-item, .match, .game-row, .schedule-item')
        
        if not game_items:
            # 備用選擇器
            game_items = soup.find_all('div', class_=re.compile(r'game|match|schedule', re.I))
        
        if not game_items:
            # 最後備用：尋找所有可能包含比分的區塊
            game_items = soup.find_all(lambda tag: 
                tag.get('class') and 
                any('game' in str(c) or 'match' in str(c) or 'score' in str(c) 
                    for c in tag.get('class', []))
            )
        
        for game in game_items:
            try:
                # 抓取隊伍名稱和比分
                home_team = game.select_one('.home-team, .home, .team-home')
                away_team = game.select_one('.away-team, .away, .team-away')
                score = game.select_one('.score, .比分, .result')
                
                if home_team and away_team:
                    home_name = home_team.get_text(strip=True)
                    away_name = away_team.get_text(strip=True)
                    score_text = score.get_text(strip=True) if score else "賽程中"
                    
                    games.append({
                        'home': home_name,
                        'away': away_name,
                        'score': score_text,
                        'status': '已完賽' if '勝' in score_text or '負' in score_text else '進行中/未開始'
                    })
            except:
                continue
        
        return games
    
    def query_date(self, date=None):
        """查詢指定日期的賽程"""
        if not date:
            date = self.get_match_date()
        
        print(f"🔍 查詢日期：{date}")
        
        html = self.fetch_schedule(date)
        
        if "錯誤" in html:
            return {"error": html}
        
        games = self.parse_games(html)
        
        if not games:
            return {
                "date": date,
                "message": f"當天 ({date}) 可能沒有賽程，或網站結構有變動",
                "suggestion": "請嘗試使用其他日期或檢查網站"
            }
        
        # 統計資訊
        total_games = len(games)
        completed = sum(1 for g in games if g['status'] == '已完賽')
        
        result = {
            "date": date,
            "total_games": total_games,
            "completed": completed,
            "games": games
        }
        
        return result
    
    def display_results(self, result):
        """格式化顯示結果"""
        if "error" in result:
            print(f"❌ {result['error']}")
            return
        
        print(f"\n📅 {result['date']} 賽程總覽")
        print(f"📊 總場數：{result['total_games']} (已完賽：{result['completed']})\n")
        
        for i, game in enumerate(result['games'], 1):
            print(f"【比賽{i}】")
            print(f"  {game['away']} : {game['home']} ({game['score']})")
            print(f"  狀態：{game['status']}")
            print()
    
    def quick_query(self, date=None):
        """快速查詢並顯示"""
        result = self.query_date(date)
        self.display_results(result)
        return result

# 使用範例
if __name__ == "__main__":
    querier = CPBLQuerier()
    querier.quick_query()