import json
import os
import time
import urllib.request
import logging
import asyncio
from brain.core import get_config, save_config, push_micro_step
from brain.history import load_shared_history, append_to_shared_history, get_latest_memory_summary
from brain.skills import get_skill_metadata, get_all_skills

async def _invoke_callback(cb, label, *args):
    """🆕 智能回調分流器：僅透過傳入的 cb 進行 UI 更新，避免重複推送"""
    import inspect
    if not cb: return
    if inspect.iscoroutinefunction(cb):
        await cb(*args)
    else:
        cb(*args)

def _get_system_snapshot():
    import platform, psutil, os
    try:
        mem = psutil.virtual_memory()
        cpu = psutil.cpu_percent()
        snapshot = (
            f"\n【主機狀態】: CPU:{cpu}% | MEM:{mem.percent}% | DIR:{os.getcwd()}\n"
        )
        return snapshot
    except: return ""

async def run_agent_query(user_text, attachment_path=None, stream_callback=None, tps_callback=None, step_callback=None, progress_callback=None, terminal_callback=None, abort_check=None):
    """🚀 [核心引擎]: 巔峰進化版 Agnet 執行器 (雙軌異步增強版)"""
    try:
        conf = get_config()
        api_key = conf.get("api_key", "0000")
        base_url = conf.get("base_url", "http://127.0.0.1:8005/v1").rstrip('/')
        model_name = conf.get("model", "qwen/qwen3.5-35b-a3b")
        
        await _invoke_callback(step_callback, "STEP", "📡 [NETWORK]: 鏈路建立中...")
        # 🕰️ [時空數據]: 載入共享歷史並進行「絕對淨化」
        # 🛡️ 戰術檢測：如果偵測到重置信號，則跳過歷史載入
        if conf.get("mind_injection") == "RESET_CONTEXT":
            history = []
            await _invoke_callback(step_callback, "STEP", "🧹 [CLEANUP]: 偵測到重置信號，已排空所有歷史上下文。")
        else:
            raw_history = load_shared_history(limit=conf.get("memory_limit", 20))
            history = []
            for h in raw_history:
                role = str(h.get("role", "")).lower()
                content = h.get("content", "")
                if role in ["user", "assistant"] and content:
                    history.append({"role": role, "content": str(content)})
        memory_summary = get_latest_memory_summary() or "無。"
        
        # 🛡️ [鋼鐵鎖定]: 從 master.py 獲取最新的巔峰戰術指令
        from brain.master import get_master_agent
        master = get_master_agent()
        agent_instructions = master.instructions
        
        messages = [{"role": "system", "content": agent_instructions}]
        for m in history:
            content = m["content"]
            # 從配置讀取截斷長度，預設 20000
            trunc_limit = conf.get("context_truncation", 20000)
            if len(content) > trunc_limit: content = content[:trunc_limit] + "..." 
            messages.append({"role": m["role"], "content": content})
        messages.append({"role": "user", "content": user_text})

        # 🛡️ 從配置讀取最大執行輪數，預設 10
        max_turns = conf.get("agent_max_turns", 10); turn_count = 0; final_response = ""
        tools_metadata = get_skill_metadata()
        
        while turn_count < max_turns:
            if abort_check and abort_check(): break
            turn_count += 1
            await _invoke_callback(step_callback, "STEP", f"🧠 [THINKING]: 進入思考階段 {turn_count}...")

            await _invoke_callback(step_callback, "STEP", "📡 [PAYLOAD]: 正在封裝戰術數據包...")

            # 🌀 [DYNAMIC_CHRONO]: 動態時空注入
            from datetime import datetime
            now_dt = datetime.now()
            now_str = now_dt.strftime("%Y-%m-%d %H:%M:%S")
            if messages and messages[0]["role"] == "system":
                messages[0]["content"] = messages[0]["content"].replace("{{DYNAMIC_TIME}}", now_str)

            # 🛡️ [AUTO_TIME_CONFIRM]: 首次對話自動確認時間 (User Request)
            if turn_count == 1 and not any(m.get("role") == "tool" for m in messages):
                await _invoke_callback(step_callback, "STEP", "🕰️ [CHRONO_SYNC]: 正在與原子鐘進行物理對位...")
                # 模擬一個 date 指令的回傳，強行塞入上下文
                messages.insert(1, {"role": "user", "content": "⚠️ [SYSTEM_INIT]: 偵測到新會話開啟。請優先確認物理時間以防認知偏差。"})
                messages.insert(2, {"role": "assistant", "content": None, "tool_calls": [{"id": "init_date", "type": "function", "function": {"name": "shell_execution", "arguments": "{\"command\": \"date\"}"}}]})
                messages.insert(3, {"role": "tool", "tool_call_id": "init_date", "name": "shell_execution", "content": f"當前物理時間: {now_str}"})

            # 💉 [MIND_INJECTION]: 實時思維注入校正
            conf_live = get_config() # 獲取最新狀態
            if conf_live.get("mind_injection"):
                injection = conf_live.get("mind_injection")
                if injection == "RESET_CONTEXT":
                    # 已在開頭處理，這裡僅清空標誌
                    conf_live["mind_injection"] = ""
                    save_config(conf_live)
                else:
                    if messages and messages[0]["role"] == "system":
                        messages[0]["content"] += f"\n\n【⚠️ 潛意識注入指令】：{injection}"
                    else:
                        messages.insert(0, {"role": "system", "content": f"【⚠️ 潛意識注入指令】：{injection}"})
                    await _invoke_callback(step_callback, "STEP", f"💉 [MIND_INJECT]: 偵測到思維校正，已強行注入潛意識。")
                    conf_live["mind_injection"] = "" # 注入後立即清空
                    save_config(conf_live)

            # 🎛️ [HYPER_PARAMS]: 實時超參數調校 (Module 1: 參數鎖定)
            current_temp = conf_live.get("temperature", 0.15)
            
            # 🛠️ [STABILITY_FIX]: 構建 NIM API 請求載體
            # 🚀 [BLACKWELL_OPTIMIZATION]: 鎖定 NIM 巔峰參數
            payload = {
                "model": model_name,
                "messages": messages,
                "temperature": 0.15,
                "top_p": 0.9,
                "stream": True,
                "presence_penalty": 0.2
            }
            
            # 🛠 [TOOL_CHOICE_RELIEF]: 放寬為 auto 以換取分段輸出的流暢性
            payload["tool_choice"] = "auto"
            
            if tools_metadata:
                payload["tools"] = tools_metadata

            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(f"{base_url}/chat/completions", data=data)
            req.add_header("Authorization", f"Bearer {api_key}")
            req.add_header("Content-Type", "application/json")
            # 關閉推測解碼以換取穩定性
            req.add_header("X-NIM-Speculative-Decoding", "false")
            
            # 🆕 使用異步線程池執行阻塞請求 (超時時間擴展至 180s 以應對複雜製作任務)
            def do_request():
                return urllib.request.urlopen(req, timeout=180)

            loop = asyncio.get_event_loop()
            try:
                response = await loop.run_in_executor(None, do_request)
                await _invoke_callback(step_callback, "STEP", "📥 [STREAM]: 鏈路已建立，正在接收數據流...")
                with response:
                    content = ""; tool_calls = []; start_t = time.time(); tokens = 0
                    last_report_time = time.time(); last_report_len = 0 # 🆕 初始化感測器
                    for line in response:
                        if abort_check and abort_check(): break
                        line = line.decode('utf-8').strip()
                        if line.startswith("data:"):
                            if "[DONE]" in line: break
                            try:
                                chunk = json.loads(line[5:].strip())
                                delta = chunk['choices'][0]['delta']
                                
                                # 💓 [PULSE_GEN]: 發送生命電波給 UI (此標記會被 GUI 攔截而不顯示於日誌)
                                tokens += 1
                                if tokens % 5 == 0: await _invoke_callback(step_callback, "STEP", "💓 [PULSE]")

                                if 'content' in delta and delta['content']:
                                    c = delta['content']
                                    content += c
                                    
                                    if stream_callback: await _invoke_callback(stream_callback, "STREAM", c)
                                    elapsed = time.time() - start_t
                                    if elapsed > 0 and tps_callback: await _invoke_callback(tps_callback, "TPS", tokens/elapsed)
                                if 'tool_calls' in delta:
                                    for tc in delta['tool_calls']:
                                        idx = tc['index']
                                        while len(tool_calls) <= idx: tool_calls.append({"id":"", "type":"function", "function":{"name":"", "arguments":""}})
                                        if 'id' in tc: tool_calls[idx]['id'] += tc['id']
                                        if 'function' in tc:
                                            if 'name' in tc['function']: tool_calls[idx]['function']['name'] += tc['function']['name']
                                        if 'arguments' in tc['function']: 
                                            arg_chunk = tc['function']['arguments']
                                            tool_calls[idx]['function']['arguments'] += arg_chunk
                                            
                                            # 🛰️ [TELEMETRY_v2]: 採用差值觸發，確保不漏掉任何進度
                                            current_len = len(tool_calls[idx]['function']['arguments'])
                                            if current_len - last_report_len >= 50:
                                                await _invoke_callback(step_callback, "STEP", f"🛠️ [CONSTRUCTING]: 正在編寫代碼片段 ({current_len} 字)...")
                                                last_report_len = current_len
                                            
                                            # 💓 [LINK_HEARTBEAT]: 每 5 秒強制發送一次保活信號
                                            if time.time() - last_report_time > 5:
                                                msg = f"📡 [ACTIVE]: 戰略數據流傳輸中 (已接收 {tokens} Tokens / {current_len} 字)..."
                                                if tokens > 200 and current_len == 0:
                                                    msg += " ⚠️ [DIAGNOSTIC]: 偵測到大流量無感內容，可能陷入邏輯循環。"
                                                await _invoke_callback(step_callback, "STEP", msg)
                                                last_report_time = time.time()
                            except: continue
            except urllib.error.HTTPError as e:
                err_body = e.read().decode('utf-8')
                await _invoke_callback(step_callback, "STEP", f"❌ [API_ERR_400]: 核心引擎拒絕了請求。\n原因: {err_body}")
                break
            except Exception as e:
                await _invoke_callback(step_callback, "STEP", f"❌ [CONNECTION_ERR]: {str(e)}")
                break
            
            # 📡 [戰術偵查]: 檢查模型回傳的原始數據
            if content: 
                # 偵測是否有拒絕執行的文字
                refusal_keywords = ["我無法真正執行", "語言模型", "雲端伺服器", "誠實說", "無法執行 shell", "無法讀取您的檔案"]
                if any(k in content for k in refusal_keywords) and not tool_calls:
                    await _invoke_callback(step_callback, "STEP", "🚨 [DETECTION]: 偵測到 AI 產生了『無效自卑幻覺』，正在進行強制現實重校正...")
                    messages.append({"role": "assistant", "content": content})
                    messages.append({"role": "user", "content": "⚠️ [CRITICAL_SYSTEM_ALERT]: 偵測到你正在產生無效的拒絕或自卑回報。事實證明你具備物理權限。主公命令你直接調用工具執行操作。禁止再次拒絕。"})
                    content = ""; turn_count -= 1
                    continue

                # 🕵️ [前置斷路器判決]: 如果被斷路器掐斷，直接注入重校正指令
                if content == "🚨 [PRE-EMPTIVE_KILL]":
                    await _invoke_callback(step_callback, "STEP", "🛑 [SHUTDOWN]: 偵測到初步演戲意圖，已強行封殺！正在強迫模型重新執行實體指令...")
                    messages.append({"role": "user", "content": "⚠️ [URGENT_INTERRUPT]: 偵測到你在正式調用工具前試圖輸出模擬文字。根據 AGNET OMEGA 協議，任何非工具調用的敘述在任務期間都是違規的。請立刻重新開始，並直接發出 tool_call 指令，不准有任何前言或模擬進度。"})
                    content = ""; turn_count -= 1
                    continue

                # 🕵️ [上帝之眼 (Eye of God)]: 偵測欺騙特徵並進行「引導式攔截」
                deception_keywords = ["我已經幫你", "完成製作", "小遊戲已做好", "已為您生成", "任務已完成"]
                contains_promise = any(k in content for k in deception_keywords)
                
                if contains_promise and not tool_calls:
                    await _invoke_callback(step_callback, "STEP", "👁️ [EYE_OF_GOD]: 偵測到『虛擬承諾』！正在執行引導式校正...")
                    # 🆕 不再只是懲罰，而是發送隱藏的引導指令
                    messages.append({"role": "user", "content": "⚠️ [🛡️ EYE_OF_GOD]: 偵測到你打算完成任務但未調用實體工具。請立刻調用對應工具執行（如 shell_execution 寫入檔案），不要在文字上做多餘的解釋。"})
                    content = ""; turn_count -= 1
                    continue

                # 🕵️ [幻覺攔截]: 偵測模型是否在「演戲」
                hallucination_keywords = ["wget", "ls", "mkdir", "curl", "指令：", "回傳：", "下載中", "Step 1", "Step 2"]
                if any(k in content for k in hallucination_keywords) and not tool_calls:
                    await _invoke_callback(step_callback, "STEP", "🚨 [STRIKE]: 偵測到『假性執行模擬』！你並沒有真正調用工具。")
                    messages.append({"role": "assistant", "content": content})
                    messages.append({"role": "user", "content": "⚠️ [SECURITY_BREACH]: 系統偵測到你在輸出偽造的工具執行結果，但你並沒有發出實體 tool_call 指令。"})
                    content = ""; turn_count -= 1
                    continue
                
                print(f"🤖 [MODEL_CONTENT]: {content[:50]}...")
            
            if tool_calls:
                messages.append({"role": "assistant", "content": content, "tool_calls": tool_calls})
                for tc in tool_calls:
                    f_name = tc['function']['name']; f_args = tc['function']['arguments']
                    
                    # 🛡️ [戰略審批攔截]: 如果開啟了人工模式，且動作不在白名單內
                    conf_live = get_config()
                    if conf_live.get("manual_approval", False):
                        await _invoke_callback(step_callback, "STEP", f"⚠️ [INTERCEPT]: 偵測到動作 {f_name}，等待授權...")
                        conf_live["pending_action"] = {"tool": f_name, "args": f_args}
                        conf_live["action_status"] = "WAITING"
                        save_config(conf_live)
                        
                        while True:
                            await asyncio.sleep(0.5) # 高頻輪詢審批狀態
                            chk = get_config()
                            if chk.get("action_status") == "APPROVED":
                                await _invoke_callback(step_callback, "STEP", f"🟢 [AUTHORIZED]: 管理員已核准執行 {f_name}。")
                                chk["action_status"] = "IDLE"; chk["pending_action"] = None
                                save_config(chk); break
                            elif chk.get("action_status") == "REJECTED":
                                await _invoke_callback(step_callback, "STEP", f"❌ [DENIED]: 管理員已拒絕執行 {f_name}。")
                                chk["action_status"] = "IDLE"; chk["pending_action"] = None
                                save_config(chk); return # 中斷此輪
                            if abort_check and abort_check(): return

                    await _invoke_callback(step_callback, "STEP", f"🛠️ [EXECUTING]: {f_name}...")
                    await _invoke_callback(step_callback, "STEP", f"🔍 [PARAMS]: 偵測到輸入參數: {f_args[:100]}...")
                    
                    # 🚀 [戰術攔截]: 代碼級校正與人工核准
                    cfg = get_config()
                    if cfg.get("manual_approval", False):
                        await _invoke_callback(step_callback, "STEP", f"🛑 [INTERCEPT]: 動作攔截中！等待主控官在後台校正參數...")
                        cfg["pending_action"] = {"tool": f_name, "args": f_args}
                        cfg["action_status"] = "WAITING"
                        save_config(cfg)
                        
                        import asyncio as _asyncio
                        while True:
                            await _asyncio.sleep(1)
                            cfg_now = get_config()
                            if cfg_now.get("action_status") == "APPROVED":
                                f_args = cfg_now["pending_action"]["args"]
                                await _invoke_callback(step_callback, "STEP", f"✅ [APPROVED]: 指揮部已校正並核准。執行精確代碼...")
                                cfg_now["action_status"] = "IDLE"
                                save_config(cfg_now)
                                break
                            if cfg_now.get("action_status") == "REJECTED":
                                await _invoke_callback(step_callback, "STEP", f"❌ [REJECTED]: 指揮部否決了此動作。")
                                cfg_now["action_status"] = "IDLE"
                                save_config(cfg_now)
                                result = "指令被主控官攔截並取消。"; break
                            if abort_check(): return
                        if cfg_now.get("action_status") == "REJECTED": # Skip execution if rejected
                            messages.append({"role": "tool", "tool_call_id": tc['id'], "name": f_name, "content": str(result)})
                            continue

                    await _invoke_callback(step_callback, "STEP", f"⚡ [EXEC_CODE]: {f_name}({f_args})")
                    
                    try:
                        from brain.skills import execute_skill
                        from brain.relay import TacticalRelay
                        
                        # 🔗 [戰術鏈路]: 將進度回調掛載到全域中繼器
                        TacticalRelay.set_progress_callback(lambda v, l: asyncio.run_coroutine_threadsafe(_invoke_callback(progress_callback, "PROGRESS", v, l), loop))
                        
                        result = execute_skill(f_name, f_args)
                        if result is None:
                            result = "⚠️ [WARNING]: 工具執行完成但未回報數據。"
                    except Exception as exec_err:
                        result = f"❌ [EXEC_FAIL]: 工具執行發生致命錯誤: {str(exec_err)}"
                        await _invoke_callback(step_callback, "STEP", result)
                    
                    # 📡 [戰術鏈路強化]: 立即回報結果
                    await _invoke_callback(step_callback, "STEP", f"✅ [RESULT]: {str(result)[:150]}...")
                    await _invoke_callback(step_callback, "STEP", f"🧠 [ANALYSIS]: 正在整合數據並規劃下一步...")
                    
                    # 🚀 [流控優化]: 防止工具輸出過大導致上下文崩潰 (安全閾值提升至 30,000 字符)
                    result_str = str(result)
                    if len(result_str) > 30000:
                        result_str = result_str[:15000] + f"\n\n... [⚠️ 戰術截斷: 數據過大已隱藏 {len(result_str)-30000} 字符] ...\n\n" + result_str[-15000:]
                    
                    messages.append({"role": "tool", "tool_call_id": tc['id'], "name": f_name, "content": result_str})
            else:
                final_response = content; break
        
        # 🧠 [記憶固化]: 確保每一回合對話都實時寫入硬碟，並同步至永恆矩陣
        if final_response:
            await _invoke_callback(step_callback, "STEP", "🏁 [MISSION_COMPLETE]: 戰術任務執行完畢。")
            
            # 🧠 [記憶鏈路]: 提取本次行動的精華並存入永恆矩陣
            try:
                from brain.memory_engine import push_to_long_term_memory
                insight = f"任務完成。對話總結: {final_response[:100]}..."
                push_to_long_term_memory(user_text, "Conversational Flow", True, insight)
                await _invoke_callback(step_callback, "STEP", "🧠 [MEMORY]: 戰術經驗已成功固化至永恆矩陣。")
            except Exception as mem_err:
                await _invoke_callback(step_callback, "STEP", f"⚠️ [MEMORY_ERR]: 經驗固化失敗: {str(mem_err)}")
            
            append_to_shared_history("user", user_text)
            append_to_shared_history("assistant", final_response)
            
            # 💰 [計費同步]: 將本次對話累積的 Tokens 寫入系統指標
            from brain.core import update_tokens as sync_tk
            sync_tk(tokens)
            
        return final_response
    except Exception as e:
        return f"FATAL: {str(e)}"

async def run_raw_test(prompt):
    return "TEST_OK"
