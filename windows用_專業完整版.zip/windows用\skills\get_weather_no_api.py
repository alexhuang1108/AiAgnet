import urllib.request
import urllib.parse
import json
import re
from datetime import datetime

def get_weather_no_api(city="新北市"):
    """
    爬取中央氣象局公開天氣資料（不需要 API Key）
    使用內建 urllib 模組
    """
    
    try:
        # 中央氣象局公開天氣預報頁面
        url = "https://weather.cwa.gov.tw/cities"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8')
        
        # 簡單解析天氣資訊
        weather_data = {
            'city': city,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'success',
            'note': '網頁爬蟲資料，建議以官方發布為準'
        }
        
        # 搜尋溫度資訊
        temp_match = re.search(r'(\d+\.?\d*)\s*°?C', html)
        if temp_match:
            weather_data['temperature'] = f"{temp_match.group(1)}°C"
        
        # 搜尋天氣狀況
        condition_match = re.search(r'(晴朗|多雲|陰天|雨天|陣雨|雷陣雨|霧天)', html)
        if condition_match:
            weather_data['condition'] = condition_match.group(1)
        
        # 搜尋降水機率
        precip_match = re.search(r'降水機率 (\d+)%', html)
        if precip_match:
            weather_data['precipitation_chance'] = f"{precip_match.group(1)}%"
        
        # 搜尋風速
        wind_match = re.search(r'風速 (\d+) 公里', html)
        if wind_match:
            weather_data['wind_speed'] = f"{wind_match.group(1)} km/h"
        
        return weather_data
        
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e),
            'city': city,
            'message': '爬蟲失敗，建議使用官方 API'
        }

# 測試執行
result = get_weather_no_api("新北市")
print(json.dumps(result, indent=2, ensure_ascii=False))