import sqlite3
import time
import asyncio
import os
import sys
from datetime import datetime, timedelta

# 加入專案路徑以進行模組載入
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from brain.history import DB_PATH
from brain.executor import run_agent_query
from brain.core import get_config

async def run_proactive_task(task_id, task_name, query):
    print(f"🚀 [SCHEDULER]: 啟動定時任務 - {task_name}")
    try:
        # 執行任務並獲取結果
        res = await run_agent_query(f"【定時任務: {task_name}】{query}")
        
        # 這裡可以擴充將結果推送至 Telegram 的邏輯
        # 目前先記錄在日誌中
        log_msg = f"✅ [TASK_COMPLETED]: {task_name} | 結果: {res[:100]}..."
        print(log_msg)
        
    except Exception as e:
        print(f"❌ [TASK_ERROR]: {task_name} - {str(e)}")

async def scheduler_loop():
    print("📡 [SCHEDULER]: 戰術調度中心已啟動，監聽定時任務中...")
    while True:
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            
            # 獲取到達執行時間的任務
            now = datetime.now().isoformat()
            cursor.execute("SELECT id, task_name, query, interval_minutes FROM scheduled_tasks WHERE next_run <= ? AND status = 'ACTIVE'", (now,))
            tasks = cursor.fetchall()
            
            for tid, name, query, interval in tasks:
                await run_proactive_task(tid, name, query)
                
                # 更新下次執行時間
                next_run = (datetime.now() + timedelta(minutes=interval)).isoformat()
                cursor.execute("UPDATE scheduled_tasks SET last_run = ?, next_run = ? WHERE id = ?", (datetime.now().isoformat(), next_run, tid))
            
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"⚠️ [SCHEDULER_LOOP_ERROR]: {e}")
            
        await asyncio.sleep(60) # 每分鐘檢查一次

if __name__ == "__main__":
    try:
        asyncio.run(scheduler_loop())
    except KeyboardInterrupt:
        print("⏹ [SCHEDULER]: 調度中心已手動關閉。")
