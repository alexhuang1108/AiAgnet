@echo off
setlocal
title TOP Agnet - Autonomous Tactical Command Center
color 0b

echo ============================================================
echo   💠 TOP Agnet - OMEGA KERNEL v4.2.0 (Windows Build)
echo ============================================================
echo.
echo [1/5] Checking System Environment...

:: 1. Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found! Please install Python 3.10+ and add it to PATH.
    echo Website: https://www.python.org/downloads/
    pause
    exit /b
)

:: 2. Check FFmpeg (Optional but recommended)
ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] FFmpeg not found. Screen recording features will be limited.
)

:: 3. Setup Virtual Environment
if not exist venv (
    echo [2/5] Creating Virtual Environment (venv)...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b
    )
)

:: 4. Activate and Install Dependencies
echo [3/5] Syncing Tactical Dependencies (pip)...
call venv\Scripts\activate
python -m pip install --upgrade pip >nul 2>&1
pip install -r requirements.txt

:: 5. Setup Playwright
if not exist venv\Lib\site-packages\playwright\driver (
    echo [4/5] Deploying Tactical Reconnaissance Engine (Playwright)...
    playwright install chromium
)

:: 6. Launch Application
echo [5/5] Initializing Command Center...
echo.
echo [SUCCESS] TOP Agnet is ready. Launching GUI...
echo [NOTICE] Please keep this window open while the program is running.
echo.
python gui_app.py

if %errorlevel% neq 0 (
    echo.
    echo [CRITICAL] Program terminated unexpectedly (Exit Code: %errorlevel%)
    pause
)

deactivate
endlocal
