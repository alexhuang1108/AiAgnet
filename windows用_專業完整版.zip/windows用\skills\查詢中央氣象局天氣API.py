import requests
import json

def query_cwa_weather(station_code="565800", api_key="YOUR_API_KEY"):
    """
    查詢中央氣象局預報站天氣資料
    :param station_code: 觀測站代碼 (新北市默認為 565800)
    :param api_key: 氣象局開放資料 API Key (需自行申請 https://opendata.cwa.gov.tw )
    :return: 天氣資料 JSON 或錯誤訊息
    """
    url = "https://opendata.cwa.gov.tw/api/v1/rest/datastore/F_C0032_001"
    
    params = {
        "OCDID": station_code
    }
    
    headers = {
        "Authorization": api_key
    }
    
    try:
        response = requests.get(url, params=params, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        if data.get("status") == "Success" and "result" in data:
            return data["result"]
        else:
            return {"error": "API 回應狀態非成功", "data": data}
            
    except requests.exceptions.RequestException as e:
        return {"error": f"請求失敗: {str(e)}"}
    except json.JSONDecodeError:
        return {"error": "回應非有效 JSON 格式"}

# 新北市常用站點代碼
taipei_station_codes = {
    "新北市": "565800",
    "板橋": "565700",
    "三重": "565600",
    "新莊": "565500",
    "淡水": "565200",
    "基隆": "571000"
}