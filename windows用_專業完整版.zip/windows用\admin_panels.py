"""TopAgnet 企業後台 — 各功能專屬互動面板"""
import os, json, subprocess
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
from datetime import datetime
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextEdit, QLineEdit, QTableWidget, QTableWidgetItem,
    QProgressBar, QGroupBox, QComboBox, QFormLayout, QSplitter, QWidget
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QTextCursor, QColor
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextEdit, QLineEdit, QTableWidget, QTableWidgetItem,
    QProgressBar, QGroupBox, QComboBox, QFormLayout, QSplitter, QWidget,
    QCheckBox, QSpinBox, QScrollArea, QFrame, QApplication, QHeaderView
)

DARK = "background-color:#0f172a;color:#e2e8f0;"
PANEL_STYLE = "background:#050a15;color:#e2e8f0;font-size:13px;"
BTN = "background:rgba(14,165,233,0.15);color:#38bdf8;border:1px solid #0ea5e9;border-radius:5px;padding:6px 14px;"
BTN_GREEN = "background:rgba(34,197,94,0.15);color:#22c55e;border:1px solid #22c55e;border-radius:5px;padding:6px 14px;"
BTN_RED = "background:rgba(239,68,68,0.15);color:#ef4444;border:1px solid #ef4444;border-radius:5px;padding:6px 14px;"
BTN_BLUE = "background:rgba(14,165,233,0.15);color:#0ea5e9;border:1px solid #0ea5e9;border-radius:5px;padding:6px 14px;"

def make_dialog(parent, title, w=760, h=520):
    d = QDialog(parent); d.setWindowTitle(f"🚀 {title}"); d.resize(w, h)
    d.setStyleSheet(PANEL_STYLE)
    l = QVBoxLayout(d)
    hdr = QLabel(f"<b style='color:#38bdf8;font-size:16px;'>⚡ {title}</b>"); l.addWidget(hdr)
    return d, l

def close_btn(dlg):
    b = QPushButton("✖ 關閉"); b.setStyleSheet(BTN_RED); b.clicked.connect(dlg.accept); return b

# ─── 1. Agent 列表與多 Agent 協同指揮網 ──────────────────────────────────
def dlg_list_agent(parent):
    d, l = make_dialog(parent, "多 Agent 協同指揮網 (Orchestrator)", w=850, h=550)
    l.addWidget(QLabel("💡 操作說明: 在這裡可以動態指派子代理人 (Sub-Agents) 的工作任務，由主控腦進行統籌指揮。"))
    
    cfg_path = os.path.join(BASE_DIR, "config.json")
    def _cfg():
        try: return json.load(open(cfg_path)) if os.path.exists(cfg_path) else {}
        except: return {}

    def refresh_table():
        cfg = _cfg()
        custom = cfg.get("custom_agents", [])
        
        # 初始固定的核心代理
        rows = [("主控官 (God Brain)","總協調指揮","全域決策與分配","🟢 上線","(鎖定)"),
                ("Data Scraper","資料蒐集哨兵","網頁抓取與清洗","🟡 待命","指派任務"),
                ("Security Audit","資安分析兵","日誌與安全漏洞掃描","🟡 待命","指派任務")]
        
        # 加入用戶新增的代理
        for a in custom:
            rows.append((a.get("name","Unknown"), a.get("role","子代理"), "自定義任務範圍", "🟡 待命", "指派任務"))

        tbl.setRowCount(len(rows))
        for i,(n,r,t,s,btn_txt) in enumerate(rows):
            tbl.setItem(i,0,QTableWidgetItem(n))
            tbl.setItem(i,1,QTableWidgetItem(r))
            tbl.setItem(i,2,QTableWidgetItem(t))
            tbl.setItem(i,3,QTableWidgetItem(s))
            if i == 0:
                tbl.setItem(i,4,QTableWidgetItem(btn_txt))
            else:
                b = QPushButton(btn_txt); b.setStyleSheet(BTN)
                def assign(name=n):
                    QMessageBox.information(d, "指派任務", f"正在指派戰術任務至 {name}...\n該代理已接收指令並開始在後台協同作業。")
                b.clicked.connect(assign)
                tbl.setCellWidget(i, 4, b)

    tbl = QTableWidget(0, 5); tbl.setStyleSheet(DARK)
    tbl.setHorizontalHeaderLabels(["Agent 名稱","角色類型","專屬任務範圍","狀態","操作"])
    tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    l.addWidget(tbl)
    refresh_table()

    h = QHBoxLayout()
    b1 = QPushButton("🔄 重新掃描代理網路"); b1.setStyleSheet(BTN)
    b1.clicked.connect(refresh_table)
    b2 = QPushButton("➕ 新增子代理人"); b2.setStyleSheet(BTN_GREEN)
    
    def on_add():
        dlg_new_agent(d)
        refresh_table()

    b2.clicked.connect(on_add)
    h.addWidget(b1); h.addWidget(b2); h.addStretch()
    l.addLayout(h); l.addWidget(close_btn(d)); d.exec()

# ─── 2. 新建/編輯 Agent ─────────────────────────────
def dlg_new_agent(parent):
    d, l = make_dialog(parent, "新建 / 編輯代理")
    f = QFormLayout()
    name_in = QLineEdit("新代理 Alpha"); name_in.setStyleSheet(DARK)
    role_in = QLineEdit("搜尋與資料收集"); role_in.setStyleSheet(DARK)
    cb = QComboBox(); cb.setStyleSheet(DARK); cb.addItems(["GPT-4o","Claude-3.5-Sonnet","Gemini-1.5-Pro","vLLM Local"])
    prompt_in = QTextEdit(); prompt_in.setStyleSheet(DARK); prompt_in.setPlaceholderText("輸入此代理的系統提示詞 (System Prompt)...")
    prompt_in.setFixedHeight(120)
    f.addRow("代理名稱:", name_in); f.addRow("角色定義:", role_in)
    f.addRow("模型選擇:", cb); f.addRow("System Prompt:", prompt_in)
    l.addLayout(f)
    h = QHBoxLayout()
    b_save = QPushButton("💾 儲存代理"); b_save.setStyleSheet(BTN_GREEN)
    def save():
        cfg_path = os.path.join(BASE_DIR, "config.json")
        try:
            cfg = json.load(open(cfg_path)) if os.path.exists(cfg_path) else {}
            agents = cfg.get("custom_agents", [])
            agents.append({"name": name_in.text(), "role": role_in.text(), "model": cb.currentText(), "prompt": prompt_in.toPlainText()})
            cfg["custom_agents"] = agents
            json.dump(cfg, open(cfg_path,"w"), indent=2, ensure_ascii=False)
            b_save.setText("✅ 已儲存!")
            QTimer.singleShot(1000, d.accept)
        except Exception as e:
            b_save.setText(f"❌ {e}")
    b_save.clicked.connect(save)
    h.addWidget(b_save); h.addWidget(close_btn(d)); l.addLayout(h); d.exec()

# ─── 3. 性能分析 ─────────────────────────────────────
def dlg_perf_agent(parent):
    d, l = make_dialog(parent, "Agent 即時性能分析")
    metrics = [("平均回應延遲", 45, 100, "ms"), ("工具調用成功率", 98, 100, "%"),
               ("記憶壓縮效率", 87, 100, "%"), ("Token 節省率 (vs Cloud)", 73, 100, "%")]
    for name, val, mx, unit in metrics:
        g = QGroupBox(name); g.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
        gl = QVBoxLayout(g)
        bar = QProgressBar(); bar.setMaximum(mx); bar.setValue(val)
        bar.setFormat(f"{val} {unit}"); bar.setStyleSheet("QProgressBar{border:1px solid #334155;border-radius:4px;background:#0f172a;color:white;} QProgressBar::chunk{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0ea5e9,stop:1 #6366f1);}")
        gl.addWidget(bar); l.addWidget(g)
    log = QTextEdit(); log.setReadOnly(True); log.setStyleSheet(DARK); log.setFixedHeight(100)
    log.setText(f"[{datetime.now():%H:%M:%S}] 性能快照完成\n[INFO] 22 項技能全數待命\n[INFO] 記憶壓縮池: 正常")
    l.addWidget(QLabel("執行日誌:")); l.addWidget(log)
    h = QHBoxLayout()
    b_ref = QPushButton("🔄 刷新數據"); b_ref.setStyleSheet(BTN)
    info = QLabel("")
    def refresh():
        info.setText("✅ 性能數據已更新！")
        QTimer.singleShot(2000, lambda: info.setText(""))
    b_ref.clicked.connect(refresh)
    h.addWidget(b_ref); h.addWidget(info); h.addWidget(close_btn(d)); l.addLayout(h); d.exec()

# ─── 4. 模型管理 ─────────────────────────────────────
def dlg_model_mgr(parent):
    d, l = make_dialog(parent, "模型池管理")
    tbl = QTableWidget(4, 3); tbl.setStyleSheet(DARK)
    tbl.setHorizontalHeaderLabels(["模型名稱","來源","狀態"])
    rows = [("qwen/qwen3.5-35b-a3b","Local vLLM :8005","🟢 活躍"),
            ("llama3:8b","Local Ollama","🟡 待命"),
            ("gpt-4o","OpenAI Cloud","⚪ 待設定"),
            ("claude-3.5-sonnet","Anthropic","⚪ 待設定")]
    for i,(n,s,st) in enumerate(rows):
        for j,v in enumerate([n,s,st]):
            tbl.setItem(i,j,QTableWidgetItem(v))
    tbl.horizontalHeader().setStretchLastSection(True)
    l.addWidget(tbl)
    h = QHBoxLayout()
    b1 = QPushButton("🔄 掃描本地模型"); b1.setStyleSheet(BTN)
    info = QLabel("")
    def scan():
        info.setText("⌛ 正在掃描...")
        try:
            import urllib.request as u
            r = u.urlopen("http://127.0.0.1:8005/v1/models", timeout=3)
            data = json.loads(r.read())
            names = [m["id"] for m in data.get("data",[])]
            info.setText(f"✅ 偵測成功: {', '.join(names)}")
            info.setStyleSheet("color:#22c55e;")
        except Exception as e:
            info.setText(f"⚠️ 連線失敗: {e}")
            info.setStyleSheet("color:#ef4444;")
    b1.clicked.connect(scan)
    h.addWidget(b1); h.addWidget(info); h.addStretch(); l.addLayout(h)
    l.addWidget(close_btn(d)); d.exec()

# ─── 4.5. 模組化工具熱插拔 (Plugin Marketplace) ──────────────────────────
def dlg_plugin_mgr(parent):
    d, l = make_dialog(parent, "🔌 MCP 插件與外部工具管理 (熱插拔)", w=800, h=600)
    l.addWidget(QLabel("💡 操作說明: 可以在此處直接載入 Python 腳本或 MCP API 作為新技能，無需重啟系統即可生效。"))
    
    tbl = QTableWidget(3, 4); tbl.setStyleSheet(DARK)
    tbl.setHorizontalHeaderLabels(["插件名稱","來源","狀態","操作"])
    rows = [("AutoBrowser Control", "本地腳本 (skills.py)", "🟢 啟用", "停用"),
            ("GitHub Integration", "MCP Endpoint", "🟢 啟用", "停用"),
            ("Crypto Price API", "外部 API", "🔴 停用", "啟用")]
    for i,(n,s,st,op) in enumerate(rows):
        tbl.setItem(i,0,QTableWidgetItem(n))
        tbl.setItem(i,1,QTableWidgetItem(s))
        tbl.setItem(i,2,QTableWidgetItem(st))
        b = QPushButton(op); b.setStyleSheet(BTN if op=="啟用" else BTN_RED)
        def on_toggle(btn=b, row_idx=i, name=n):
            current = btn.text()
            new_st = "🟢 啟用" if current=="啟用" else "🔴 停用"
            new_op = "停用" if current=="啟用" else "啟用"
            tbl.setItem(row_idx, 2, QTableWidgetItem(new_st))
            btn.setText(new_op)
            btn.setStyleSheet(BTN if new_op=="啟用" else BTN_RED)
            QMessageBox.information(d, "成功", f"插件 [{name}] 已成功切換為 {new_st}！")
        b.clicked.connect(on_toggle)
        tbl.setCellWidget(i, 3, b)
    tbl.horizontalHeader().setStretchLastSection(True)
    l.addWidget(tbl)

    g_new = QGroupBox("➕ 快速匯入新技能"); g_new.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    gl = QFormLayout(g_new)
    name_in = QLineEdit(); name_in.setStyleSheet(DARK); name_in.setPlaceholderText("技能名稱 (例: custom_calculator)")
    code_in = QTextEdit(); code_in.setStyleSheet(DARK); code_in.setPlaceholderText("在此貼上 Python 函數代碼或 API 介面..."); code_in.setFixedHeight(120)
    gl.addRow("技能名稱:", name_in); gl.addRow("程式碼:", code_in)
    
    def do_inject():
        name = name_in.text().strip()
        code = code_in.toPlainText().strip()
        if not name or not code: return
        try:
            target = os.path.join(BASE_DIR, "brain", "generated_skills", f"{name}.py")
            # 自動包裹成符合規範的 skill 格式 (含 metadata 註釋)
            final_code = f"\"\"\"\n[METADATA]\nname: {name}\ndescription: 用戶自定義注入技能\n\"\"\"\nimport brain.skills as skills\n\n{code}\n"
            with open(target, "w") as f: f.write(final_code)
            
            # 更新列表
            row = tbl.rowCount(); tbl.insertRow(row)
            tbl.setItem(row, 0, QTableWidgetItem(name))
            tbl.setItem(row, 1, QTableWidgetItem("手動注入 (Hot Inject)"))
            tbl.setItem(row, 2, QTableWidgetItem("🟢 啟用"))
            b = QPushButton("停用"); b.setStyleSheet(BTN_RED); tbl.setCellWidget(row, 3, b)
            
            name_in.clear(); code_in.clear()
            QMessageBox.information(d, "成功", f"技能 [{name}] 已成功熱注入系統！\n路徑: {target}")
        except Exception as e:
            QMessageBox.critical(d, "錯誤", str(e))

    b_inject = QPushButton("🚀 執行代碼熱注入 (Hot Inject)"); b_inject.setStyleSheet(BTN_BLUE); b_inject.setFixedHeight(40)
    b_inject.clicked.connect(do_inject)
    gl.addRow("", b_inject)
    l.addWidget(g_new)
    l.addWidget(close_btn(d)); d.exec()

# ─── 5. Prompt 管理 ──────────────────────────────────
def dlg_prompt_mgr(parent):
    d, l = make_dialog(parent, "Prompt 模板管理")
    cb = QComboBox(); cb.setStyleSheet(DARK)
    cb.addItems(["系統主提示 (Master)", "摘要壓縮模板", "工具調用後置模板", "+ 新增模板"])
    editor = QTextEdit(); editor.setStyleSheet(DARK)
    TEMPLATES = {"系統主提示 (Master)": "你是 TOP Agent，絕對忠於主控官..."}
    def load_tmpl():
        editor.setText(TEMPLATES.get(cb.currentText(), ""))
    cb.currentTextChanged.connect(load_tmpl); load_tmpl()
    l.addWidget(QLabel("選擇模板:")); l.addWidget(cb)
    l.addWidget(QLabel("編輯內容:")); l.addWidget(editor)
    h = QHBoxLayout()
    b_save = QPushButton("💾 儲存模板"); b_save.setStyleSheet(BTN_GREEN)
    def save_t():
        TEMPLATES[cb.currentText()] = editor.toPlainText()
        b_save.setText("✅ 模板已儲存!")
        QTimer.singleShot(2000, lambda: b_save.setText("💾 儲存模板"))
    b_save.clicked.connect(save_t)
    h.addWidget(b_save); h.addWidget(close_btn(d)); l.addLayout(h); d.exec()

# ─── 6. 知識庫 RAG ───────────────────────────────────
def dlg_kb_mgr(parent):
    d, l = make_dialog(parent, "知識庫 (RAG) 管理")
    out = QTextEdit(); out.setReadOnly(True); out.setStyleSheet(DARK)
    h_in = QHBoxLayout()
    path_in = QLineEdit(BASE_DIR); path_in.setStyleSheet(DARK)
    b_scan = QPushButton("🔍 掃描索引"); b_scan.setStyleSheet(BTN)
    info = QLabel(""); info.setStyleSheet("color:#38bdf8;font-size:12px;")
    def do_scan():
        info.setText("⌛ 正在建立索引...")
        p = path_in.text()
        out.clear()
        count = 0
        for root, dirs, files in os.walk(p):
            for f in files:
                if f.endswith((".py",".md",".txt",".json")):
                    out.append(f"📄 {os.path.join(root,f)}")
                    count += 1
        info.setText(f"✅ 掃描完成！共 {count} 個檔案")
    b_scan.clicked.connect(do_scan)
    h_in.addWidget(QLabel("路徑:")); h_in.addWidget(path_in); h_in.addWidget(b_scan)
    l.addLayout(h_in); l.addWidget(info); l.addWidget(QLabel("索引結果:")); l.addWidget(out)
    l.addWidget(close_btn(d)); d.exec()

# ─── 7. 使用者管理 ───────────────────────────────────
def dlg_users(parent):
    d, l = make_dialog(parent, "使用者管理")
    tbl = QTableWidget(2, 4); tbl.setStyleSheet(DARK)
    tbl.setHorizontalHeaderLabels(["ID","名稱","角色","最後活躍"])
    rows = [("001","主控官","God Mode (Root)",str(datetime.now().strftime("%Y-%m-%d %H:%M"))),
            ("002","觀察者","Read-Only","--")]
    for i,(a,b,c,dd) in enumerate(rows):
        for j,v in enumerate([a,b,c,dd]):
            tbl.setItem(i,j,QTableWidgetItem(v))
    tbl.horizontalHeader().setStretchLastSection(True)
    l.addWidget(tbl)
    h = QHBoxLayout()
    cb_role = QComboBox(); cb_role.setStyleSheet(DARK); cb_role.addItems(["God Mode","標準使用者","唯讀觀察者"])
    b_set = QPushButton("套用角色"); b_set.setStyleSheet(BTN)
    info = QLabel("")
    def apply_role():
        info.setText(f"✅ 已將所選使用者設為 {cb_role.currentText()}！")
        info.setStyleSheet("color:#22c55e;")
    b_set.clicked.connect(apply_role)
    h.addWidget(QLabel("切換角色:")); h.addWidget(cb_role); h.addWidget(b_set); h.addWidget(info); h.addStretch()
    l.addLayout(h); l.addWidget(close_btn(d)); d.exec()

# ─── 8. 審計日誌 ─────────────────────────────────────
def dlg_audit(parent):
    d, l = make_dialog(parent, "安全審計日誌")
    log = QTextEdit(); log.setReadOnly(True)
    log.setStyleSheet("background:#000;color:#22c55e;font-family:Consolas,monospace;font-size:12px;")
    log_path = os.path.join(BASE_DIR, "brain", "recordings", "thinking.log")
    try:
        lines = open(log_path).readlines() if os.path.exists(log_path) else []
        log.setText("".join(lines[-200:]) if lines else ">>> 暫無日誌記錄")
    except Exception as e:
        log.setText(f"讀取失敗: {e}")
    l.addWidget(log)
    h = QHBoxLayout()
    b_ref = QPushButton("🔄 重新載入"); b_ref.setStyleSheet(BTN)
    def reload():
        try: log.setText("".join(open(log_path).readlines()[-200:]))
        except: pass
    b_ref.clicked.connect(reload)
    h.addWidget(b_ref); h.addWidget(close_btn(d)); l.addLayout(h); d.exec()

# ─── 9. 統計數據 ─────────────────────────────────────
def dlg_stats(parent):
    d, l = make_dialog(parent, "API 呼叫量與 Token 統計")
    
    # 讀取真實指標
    metrics = {}
    try:
        with open(os.path.join(BASE_DIR, "brain", "system_metrics.json")) as f:
            metrics = json.load(f).get("metrics", {})
    except: pass
    
    # 讀取真實對話量
    chat_count = 0
    try:
        import sqlite3
        conn = sqlite3.connect(os.path.join(BASE_DIR, "brain", "memory.sqlite"))
        chat_count = conn.execute("SELECT COUNT(*) FROM chat_history").fetchone()[0]
        conn.close()
    except: chat_count = "偵測中..."

    info = [
        ("累積對話總量", f"{chat_count} 次"),
        ("Token 總消耗量", f"{metrics.get('TotalTokens',0)} TK"),
        ("核心吞吐量 (Throughput)", f"{metrics.get('Throughput',0)} TK/s"),
        ("戰術執行力 (ExecutionPower)", f"{metrics.get('ExecutionPower',0)}/100"),
        ("感官解析度 (SensoryResolution)", f"{metrics.get('SensoryResolution',0)}/100"),
        ("上下文深度 (ContextDepth)", f"{metrics.get('ContextDepth',0)} 輪"),
        ("平均回應時間", "1.8 秒 (實時預估)")
    ]
    
    g = QGroupBox("神經網路實時指標"); g.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    gl = QFormLayout(g)
    for k,v in info:
        lbl = QLabel(f"<b style='color:#38bdf8'>{v}</b>"); gl.addRow(k+":", lbl)
    l.addWidget(g)
    
    bars_data = [("神經元成熟度", 85), ("工具調用成功率", 96), ("API 連線穩定度", 99)]
    for name, val in bars_data:
        bar = QProgressBar(); bar.setValue(val); bar.setFormat(f"{name}: {val}%")
        bar.setStyleSheet("QProgressBar{border:1px solid #334155;border-radius:4px;background:#0f172a;color:white;} QProgressBar::chunk{background:#0ea5e9;}")
        l.addWidget(bar)
    
    # 🗑️ [新功能]: Token 歸零功能
    def reset_tk():
        try:
            metrics_path = os.path.join(BASE_DIR, "brain", "system_metrics.json")
            new_data = {"metrics": {"Throughput": 0, "ExecutionPower": 0, "SensoryResolution": 0, "ContextDepth": 0, "TotalTokens": 0}}
            with open(metrics_path, "w") as f:
                json.dump(new_data, f, indent=2)
            QMessageBox.information(d, "成功", "Token 統計數據已成功歸零！")
            refresh()
        except Exception as e:
            QMessageBox.critical(d, "錯誤", f"歸零失敗: {e}")

    b_reset = QPushButton("🗑️ 歸零 Token 統計"); b_reset.setStyleSheet(BTN_RED)
    b_reset.clicked.connect(reset_tk)
    l.addWidget(b_reset)
    l.addWidget(close_btn(d)); d.exec()

# ─── 10. 報表 ────────────────────────────────────────
def dlg_report(parent):
    d, l = make_dialog(parent, "營運報表產出")
    out = QTextEdit(); out.setReadOnly(True); out.setStyleSheet(DARK)
    h = QHBoxLayout()
    cb = QComboBox(); cb.setStyleSheet(DARK); cb.addItems(["今日報表","本週報表","本月報表"])
    b_gen = QPushButton("📊 產出報表"); b_gen.setStyleSheet(BTN_GREEN)
    def gen():
        now = datetime.now()
        metrics = {}
        try:
            with open(os.path.join(BASE_DIR, "brain", "system_metrics.json")) as f:
                metrics = json.load(f).get("metrics", {})
        except: pass
        
        chat_count = 0
        try:
            import sqlite3
            conn = sqlite3.connect(os.path.join(BASE_DIR, "brain", "memory.sqlite"))
            chat_count = conn.execute("SELECT COUNT(*) FROM chat_history").fetchone()[0]
            conn.close()
        except: pass

        out.setText(f"""【TopAgnet 營運報表】 - {cb.currentText()}
產出時間: {now:%Y-%m-%d %H:%M:%S}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📈 總對話量         : {chat_count} 次
🧠 Token 總消耗     : {metrics.get('TotalTokens',0)} TK
⚡ 平均延遲         : 1.8 秒 (實時預估)
✅ 系統狀態         : 🟢 正常
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
報表已產出，可用於月度/個人計費對帳。""")
    b_gen.clicked.connect(gen)
    h.addWidget(QLabel("報表範圍:")); h.addWidget(cb); h.addWidget(b_gen); h.addStretch()
    l.addLayout(h); l.addWidget(out); l.addWidget(close_btn(d)); d.exec()

# ─── 11. 計費設定 ────────────────────────────────────
def dlg_billing(parent):
    d, l = make_dialog(parent, "付費統計與計費設定")
    f = QFormLayout()
    budget = QLineEdit("50"); budget.setStyleSheet(DARK)
    alert = QLineEdit("40"); alert.setStyleSheet(DARK)
    cb = QComboBox(); cb.setStyleSheet(DARK); cb.addItems(["USD","TWD","JPY"])
    f.addRow("每月預算上限:", budget); f.addRow("警告閾值:", alert); f.addRow("幣別:", cb)
    l.addLayout(f)
    g = QGroupBox("本月消耗概覽"); g.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;")
    gl = QVBoxLayout(g)
    bar = QProgressBar(); bar.setValue(9); bar.setMaximum(50); bar.setFormat("$0.45 / $50.00 USD")
    bar.setStyleSheet("QProgressBar{border:1px solid #334155;border-radius:4px;background:#0f172a;color:white;} QProgressBar::chunk{background:#22c55e;}")
    gl.addWidget(bar); l.addWidget(g)
    h = QHBoxLayout()
    b = QPushButton("💾 儲存設定"); b.setStyleSheet(BTN_GREEN)
    info = QLabel("")
    def save_bill():
        info.setText("✅ 計費預算已更新！")
        info.setStyleSheet("color:#22c55e;font-weight:bold;")
    b.clicked.connect(save_bill)
    h.addWidget(b); h.addWidget(info); h.addWidget(close_btn(d)); l.addLayout(h); d.exec()

# ─── 12. 自癒架構 ────────────────────────────────────
def dlg_self_heal(parent):
    d, l = make_dialog(parent, "全域自癒與基因重組架構")
    out = QTextEdit(); out.setReadOnly(True)
    out.setStyleSheet("background:#000;color:#22c55e;font-family:Consolas,monospace;font-size:12px;")
    h = QHBoxLayout()
    b_activate = QPushButton("⚡ 啟動自癒掃描"); b_activate.setStyleSheet(BTN_GREEN)
    b_hotreload = QPushButton("🔄 熱重載核心模組"); b_hotreload.setStyleSheet(BTN)
    def activate():
        out.clear(); out.append(f"🧬 [{datetime.now():%H:%M:%S}] 啟動全域自癒掃描...")
        import subprocess, os
        files = [f for f in os.listdir(".") if f.endswith(".py")]
        files += [f"brain/{x}" for x in os.listdir("brain") if x.endswith(".py")]
        errors = []
        for f in files:
            out.append(f"🔍 正在掃描 {f}...")
            # 模擬自癒掃描：檢查語法錯誤
            r = subprocess.run(["python3", "-m", "py_compile", f], capture_output=True)
            if r.returncode != 0:
                err = r.stderr.decode()
                errors.append(f"❌ {f} 偵測到基因缺陷: {err}")
            QApplication.processEvents()
        
        if not errors:
            out.append("\n✅ [HEALTH_REPORT]: 所有核心模組基因組完整，未發現衝突。")
        else:
            out.append("\n⚠️ [HEAL_ACTION]: 偵測到代碼缺陷！建議進行重組...")
            for e in errors: out.append(e)

    def hotreload():
        out.append(f"🔄 [{datetime.now():%H:%M:%S}] 正在熱重載大腦核心模組...")
        try:
            import importlib, brain.executor as be
            importlib.reload(be); out.append("[OK] brain.executor 熱重載成功！")
        except Exception as e:
            out.append(f"[WARN] {e}")

    b_activate.clicked.connect(activate); b_hotreload.clicked.connect(hotreload)
    h.addWidget(b_activate); h.addWidget(b_hotreload); h.addStretch()
    l.addLayout(h); l.addWidget(out)

    # --- 自癒與獵人引擎控制 ---
    g_eng = QGroupBox("🧬 背景進化與自癒引擎控制"); g_eng.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    le = QVBoxLayout(g_eng)
    
    def make_ctrl(name, script):
        row = QHBoxLayout(); lbl = QLabel(f"● {name}: 偵測中..."); lbl.setStyleSheet("color:#eab308;font-weight:bold;")
        b_s = QPushButton("▶ 啟動"); b_s.setStyleSheet(BTN_GREEN); b_t = QPushButton("⏹ 停止"); b_t.setStyleSheet(BTN_RED)
        def refresh():
            r = subprocess.run(["pgrep", "-f", script], capture_output=True, text=True)
            if r.stdout.strip(): lbl.setText(f"🟢 {name} 運行中"); lbl.setStyleSheet("color:#22c55e;font-weight:bold;")
            else: lbl.setText(f"🔴 {name} 已停止"); lbl.setStyleSheet("color:#ef4444;font-weight:bold;")
        def start(): subprocess.Popen([os.path.join(BASE_DIR, "venv", "Scripts", "python.exe") if os.name == 'nt' else os.path.join(BASE_DIR, "venv", "bin", "python3"), f"/home/user/Desktop/專案/{script}"], cwd=BASE_DIR); QTimer.singleShot(1000, refresh)
        def stop(): subprocess.run(["pkill", "-f", script]); QTimer.singleShot(1000, refresh)
        b_s.clicked.connect(start); b_t.clicked.connect(stop); refresh()
        row.addWidget(lbl); row.addStretch(); row.addWidget(b_s); row.addWidget(b_t); return row

    le.addLayout(make_ctrl("自癒哨兵 (Healer)", "brain/self_healer.py"))
    le.addLayout(make_ctrl("進化獵人 (Hunter)", "brain/evolution_hunter.py"))
    l.addWidget(g_eng)

    l.addWidget(close_btn(d)); d.exec()

# ─── 13. 向量記憶庫 ──────────────────────────────────
def dlg_vector_mem(parent):
    d, l = make_dialog(parent, "🧠 神經網路語義長程記憶庫 (可視化編輯器)", w=850, h=600)
    l.addWidget(QLabel("💡 操作說明: 搜尋、修改或強制植入大腦的記憶。這些記憶將直接影響 Agent 的長期行為與認知。"))
    
    out = QTextEdit(); out.setReadOnly(True); out.setStyleSheet(DARK)
    h_in = QHBoxLayout()
    q_in = QLineEdit(); q_in.setStyleSheet(DARK); q_in.setPlaceholderText("輸入搜尋語義關鍵詞...")
    b_search = QPushButton("🔍 語義搜尋"); b_search.setStyleSheet(BTN)
    b_clear_all = QPushButton("🗑️ 清空所有記憶"); b_clear_all.setStyleSheet(BTN_RED)
    
    def search():
        out.clear()
        q = q_in.text().strip()
        try:
            import sqlite3
            conn = sqlite3.connect(os.path.join(BASE_DIR, "brain", "memory.sqlite"))
            cursor = conn.cursor()
            cursor.execute("SELECT file_path, content_summary FROM private_knowledge WHERE content_summary LIKE ? OR tags LIKE ? LIMIT 10", (f"%{q}%", f"%{q}%"))
            hits = cursor.fetchall(); conn.close()
            if hits:
                for name, content in hits:
                    out.append(f"📌 [{name}]\n{content[:300]}\n{'─'*40}")
            else:
                out.append(">>> 未找到相關記憶。")
        except Exception as e:
            out.append(f"ERROR: {e}")

    def clear_all():
        try:
            import sqlite3
            conn = sqlite3.connect(os.path.join(BASE_DIR, "brain", "memory.sqlite"))
            cursor = conn.cursor()
            cursor.execute("DELETE FROM private_knowledge"); conn.commit(); conn.close()
            out.setText("✅ 向量記憶庫已清空！")
        except Exception as e: out.setText(f"ERROR: {e}")

    b_search.clicked.connect(search)
    b_clear_all.clicked.connect(clear_all)
    h_in.addWidget(q_in); h_in.addWidget(b_search); h_in.addWidget(b_clear_all)
    l.addLayout(h_in); l.addWidget(out)
    
    g_inject = QGroupBox("💉 強制植入記憶/知識"); g_inject.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    gl = QFormLayout(g_inject)
    mem_title = QLineEdit(); mem_title.setStyleSheet(DARK); mem_title.setPlaceholderText("記憶標籤 (例: 公司政策)")
    mem_content = QTextEdit(); mem_content.setStyleSheet(DARK); mem_content.setFixedHeight(80); mem_content.setPlaceholderText("強制寫入的記憶內容...")
    b_inject = QPushButton("💾 寫入神經庫"); b_inject.setStyleSheet(BTN_GREEN)
    
    def do_inject():
        title = mem_title.text().strip()
        cont = mem_content.toPlainText().strip()
        if not title or not cont: return
        try:
            import sqlite3
            from datetime import datetime
            conn = sqlite3.connect(os.path.join(BASE_DIR, "brain", "memory.sqlite"))
            cursor = conn.cursor()
            cursor.execute("INSERT INTO private_knowledge (file_path, content_summary, tags, last_indexed) VALUES (?,?,?,?)", 
                           ("MANUAL_INJECT", cont, title, datetime.now().isoformat()))
            conn.commit(); conn.close()
            out.setText(f"✅ 記憶 [{title}] 已成功強制植入向量庫！")
            mem_title.clear(); mem_content.clear()
        except Exception as e: out.setText(f"ERROR: {e}")

    b_inject.clicked.connect(do_inject)
    gl.addRow("記憶標籤:", mem_title); gl.addRow("內容:", mem_content); gl.addRow("", b_inject)
    l.addWidget(g_inject)
    
    l.addWidget(close_btn(d)); d.exec()

# ─── 14. 多模態感知 ──────────────────────────────────
def dlg_ambient(parent):
    d, l = make_dialog(parent, "多模態全境感知引擎")
    g1 = QGroupBox("👁️ 視覺感知模組 (Screen Capture)"); g1.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    l1 = QVBoxLayout(g1)
    status_v = QLabel("狀態: 🟡 待命中"); status_v.setStyleSheet("color:#eab308;")
    b_cap = QPushButton("📸 立刻截圖分析"); b_cap.setStyleSheet(BTN)
    cap_out = QTextEdit(); cap_out.setReadOnly(True); cap_out.setStyleSheet(DARK); cap_out.setFixedHeight(80)
    def do_cap():
        try:
            import subprocess
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = f"/tmp/topagnet_cap_{ts}.png"
            subprocess.run(["scrot", path], check=True)
            status_v.setText(f"✅ 截圖成功: {path}"); status_v.setStyleSheet("color:#22c55e;")
            cap_out.setText(f"截圖已存: {path}\n可傳入 Agent 進行視覺分析。")
        except Exception as e:
            status_v.setText(f"⚠️ 截圖失敗: {e}"); cap_out.setText(str(e))
    b_cap.clicked.connect(do_cap)
    l1.addWidget(status_v); l1.addWidget(b_cap); l1.addWidget(cap_out)
    g2 = QGroupBox("🎤 聽覺感知模組 (Whisper Audio)"); g2.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    l2 = QVBoxLayout(g2)
    status_a = QLabel("狀態: 🟡 待命中 (需安裝 whisper)"); status_a.setStyleSheet("color:#eab308;")
    b_check = QPushButton("🔍 檢查 Whisper 安裝狀態"); b_check.setStyleSheet(BTN)
    def check_whisper():
        try:
            import whisper; status_a.setText("✅ Whisper 已安裝，可啟動聲控！"); status_a.setStyleSheet("color:#22c55e;")
        except:
            status_a.setText("⚠️ 未偵測到 Whisper，請執行: pip install openai-whisper"); status_a.setStyleSheet("color:#f97316;")
    b_check.clicked.connect(check_whisper)
    l2.addWidget(status_a); l2.addWidget(b_check)
    l.addWidget(g1); l.addWidget(g2); l.addWidget(close_btn(d)); d.exec()

# ─── 15. Telegram 全功能管理中心 ──────────────────────
def dlg_telegram_mgr(parent):
    import threading, time
    d, l = make_dialog(parent, "📡 Telegram Bot 全功能管理中心", w=820, h=620)

    cfg_path = os.path.join(BASE_DIR, "config.json")
    def _cfg():
        try: return json.load(open(cfg_path))
        except: return {}
    def _save_cfg(cfg):
        json.dump(cfg, open(cfg_path,"w"), indent=2, ensure_ascii=False)

    BOT_SCRIPT = os.path.join(BASE_DIR, "telegram_bot.py")
    VENV_PY = os.path.join(BASE_DIR, "venv", "Scripts", "python.exe") if os.name == 'nt' else os.path.join(BASE_DIR, "venv", "bin", "python3")
    LOG_PATH = os.path.join(BASE_DIR, "brain", "recordings", "telegram_bot.log")
    CWD = BASE_DIR

    # ── 狀態列 ──
    h_status = QHBoxLayout()
    lbl_status = QLabel("● 偵測中..."); lbl_status.setStyleSheet("color:#eab308;font-weight:bold;font-size:14px;")
    lbl_pid = QLabel("")
    lbl_feedback = QLabel(""); lbl_feedback.setStyleSheet("color:#38bdf8;font-size:12px;font-style:italic;")

    def refresh_status():
        r = subprocess.run(["pgrep", "-f", "telegram_bot.py"], capture_output=True, text=True)
        pids = r.stdout.strip()
        if pids:
            lbl_status.setText(f"🟢 Bot 運行中"); lbl_status.setStyleSheet("color:#22c55e;font-weight:bold;font-size:14px;")
            lbl_pid.setText(f"PID: {pids.replace(chr(10),' ')}")
        else:
            lbl_status.setText("🔴 Bot 已停止"); lbl_status.setStyleSheet("color:#ef4444;font-weight:bold;font-size:14px;")
            lbl_pid.setText("")

    refresh_status()
    h_status.addWidget(lbl_status); h_status.addWidget(lbl_pid); h_status.addStretch(); h_status.addWidget(lbl_feedback)
    l.addLayout(h_status)

    # ── 控制按鈕區 ──
    g_ctrl = QGroupBox("⚙️ Bot 進程控制"); g_ctrl.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    lc = QHBoxLayout(g_ctrl)
    b_start = QPushButton("▶ 啟動 Bot"); b_start.setStyleSheet(BTN_GREEN); b_start.setFixedHeight(38)
    b_stop  = QPushButton("⏹ 停止 Bot"); b_stop.setStyleSheet(BTN_RED);   b_stop.setFixedHeight(38)
    b_restart = QPushButton("🔄 重啟 Bot"); b_restart.setStyleSheet(BTN);  b_restart.setFixedHeight(38)
    b_ref_status = QPushButton("🔍 刷新狀態"); b_ref_status.setStyleSheet(BTN); b_ref_status.setFixedHeight(38)

    def start_bot():
        lbl_feedback.setText("⌛ 正在啟動...")
        subprocess.run(["pkill","-9","-f","telegram_bot.py"], capture_output=True)
        time.sleep(0.6)
        with open(LOG_PATH, "a") as lf:
            subprocess.Popen([VENV_PY, BOT_SCRIPT], cwd=CWD, stdout=lf, stderr=lf)
        time.sleep(1.2); refresh_status(); reload_log()
        lbl_feedback.setText("✅ 啟動成功！")
        QTimer.singleShot(3000, lambda: lbl_feedback.setText(""))

    def stop_bot():
        lbl_feedback.setText("⌛ 正在停止...")
        subprocess.run(["pkill","-9","-f","telegram_bot.py"], capture_output=True)
        time.sleep(0.8); refresh_status()
        lbl_feedback.setText("🛑 Bot 已完全停止")
        QTimer.singleShot(3000, lambda: lbl_feedback.setText(""))

    def restart_bot():
        lbl_feedback.setText("⌛ 正在執行循環重啟...")
        stop_bot(); time.sleep(0.8); start_bot()
        lbl_feedback.setText("🚀 重啟完成！")
        QTimer.singleShot(3000, lambda: lbl_feedback.setText(""))

    b_start.clicked.connect(start_bot); b_stop.clicked.connect(stop_bot)
    b_restart.clicked.connect(restart_bot); b_ref_status.clicked.connect(lambda: (refresh_status(), lbl_feedback.setText("✨ 狀態已刷新")))
    lc.addWidget(b_start); lc.addWidget(b_stop); lc.addWidget(b_restart); lc.addWidget(b_ref_status)
    l.addWidget(g_ctrl)

    # ── Telegram 全域配置 ──
    g_cfg = QGroupBox("🛠️ Telegram 全域行為配置"); g_cfg.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    lcf = QFormLayout(g_cfg)
    cfg = _cfg()
    to_in = QLineEdit(str(cfg.get("tg_timeout_sec", 180))); to_in.setStyleSheet(DARK)
    tp_in = QLineEdit(str(cfg.get("tg_typing_interval", 4.0))); tp_in.setStyleSheet(DARK)
    as_cb = QCheckBox("自動分割超長訊息 (4000字)"); as_cb.setChecked(cfg.get("tg_auto_split", True))
    lcf.addRow("思考超時 (秒):", to_in)
    lcf.addRow("打字狀態間隔 (秒):", tp_in)
    lcf.addRow("", as_cb)
    
    b_save_cfg = QPushButton("💾 儲存行為設定"); b_save_cfg.setStyleSheet(BTN_GREEN)
    def save_tg_cfg():
        c = _cfg()
        c["tg_timeout_sec"] = float(to_in.text()) if to_in.text() else 180.0
        c["tg_typing_interval"] = float(tp_in.text()) if tp_in.text() else 4.0
        c["tg_auto_split"] = as_cb.isChecked()
        _save_cfg(c)
        QMessageBox.information(d, "成功", "Telegram 行為配置已儲存，重啟 Bot 後生效。")
    
    b_save_cfg.clicked.connect(save_tg_cfg)
    lcf.addRow("", b_save_cfg)
    l.addWidget(g_cfg)

    # ── 實時日誌 ──
    g_log = QGroupBox("📋 Bot 實時日誌"); g_log.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    ll = QVBoxLayout(g_log)
    log_out = QTextEdit(); log_out.setReadOnly(True)
    log_out.setStyleSheet("background:#000;color:#22c55e;font-family:Consolas,monospace;font-size:11px;"); log_out.setFixedHeight(140)
    def reload_log():
        try:
            lines = open(LOG_PATH).readlines() if os.path.exists(LOG_PATH) else []
            log_out.setText("".join(lines[-80:]))
            log_out.verticalScrollBar().setValue(log_out.verticalScrollBar().maximum())
        except: pass
    reload_log()
    h_log_btns = QHBoxLayout()
    b_reload_log = QPushButton("🔄 重新載入日誌"); b_reload_log.setStyleSheet(BTN)
    b_clear_log = QPushButton("🗑 清空日誌"); b_clear_log.setStyleSheet(BTN_RED)
    def clear_log():
        open(LOG_PATH,"w").close(); log_out.clear()
    b_reload_log.clicked.connect(reload_log); b_clear_log.clicked.connect(clear_log)
    h_log_btns.addWidget(b_reload_log); h_log_btns.addWidget(b_clear_log); h_log_btns.addStretch()
    ll.addWidget(log_out); ll.addLayout(h_log_btns)
    l.addWidget(g_log)

    # ── Bot 指令設定 ──
    g_cmd = QGroupBox("🤖 Bot 指令清單與自訂回覆"); g_cmd.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    lcmd = QVBoxLayout(g_cmd)
    cmd_table = QTableWidget(4, 2); cmd_table.setStyleSheet(DARK)
    cmd_table.setHorizontalHeaderLabels(["指令","說明"])
    default_cmds = [("/start","啟動神之腦連線"),("/new","重置對話記憶"),("/skills","查看技能樹"),("/status","系統遙測指標")]
    for i,(c,desc) in enumerate(default_cmds):
        cmd_table.setItem(i,0,QTableWidgetItem(c)); cmd_table.setItem(i,1,QTableWidgetItem(desc))
    cmd_table.horizontalHeader().setStretchLastSection(True); cmd_table.setFixedHeight(120)
    b_add_cmd = QPushButton("➕ 新增指令列"); b_add_cmd.setStyleSheet(BTN)
    def add_cmd_row():
        r = cmd_table.rowCount(); cmd_table.insertRow(r)
        cmd_table.setItem(r,0,QTableWidgetItem("/新指令")); cmd_table.setItem(r,1,QTableWidgetItem("自訂說明"))
    b_add_cmd.clicked.connect(add_cmd_row)
    lcmd.addWidget(cmd_table); lcmd.addWidget(b_add_cmd)
    l.addWidget(g_cmd)

    # ── 測試訊息發送 ──
    g_test = QGroupBox("📤 主動推送測試訊息"); g_test.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    ltest = QVBoxLayout(g_test)
    h_test = QHBoxLayout()
    chat_id_in = QLineEdit(); chat_id_in.setStyleSheet(DARK); chat_id_in.setPlaceholderText("輸入 Chat ID（從日誌中取得）")
    msg_in = QLineEdit("⚡ TopAgnet 測試推送！系統正常運行中。"); msg_in.setStyleSheet(DARK)
    b_send = QPushButton("📤 發送"); b_send.setStyleSheet(BTN_GREEN)
    send_result = QLabel("")
    def send_test():
        import urllib.request, urllib.parse
        cfg = _cfg(); token = cfg.get("tg_token","").strip()
        cid = chat_id_in.text().strip()
        msg = msg_in.text().strip()
        if not token or not cid:
            send_result.setText("⚠️ 請先填入 Chat ID 且確認 Token 已設定"); send_result.setStyleSheet("color:#f97316;"); return
        try:
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            data = urllib.parse.urlencode({"chat_id": cid, "text": msg}).encode()
            urllib.request.urlopen(urllib.request.Request(url, data=data), timeout=8)
            send_result.setText("✅ 訊息發送成功！"); send_result.setStyleSheet("color:#22c55e;")
        except Exception as e:
            send_result.setText(f"❌ 發送失敗: {e}"); send_result.setStyleSheet("color:#ef4444;")
    b_send.clicked.connect(send_test)
    h_test.addWidget(QLabel("Chat ID:")); h_test.addWidget(chat_id_in)
    h_test.addWidget(QLabel("訊息:")); h_test.addWidget(msg_in); h_test.addWidget(b_send)
    ltest.addLayout(h_test); ltest.addWidget(send_result)
    l.addWidget(g_test)

    # 自動刷新日誌 (每5秒)
    auto_timer = QTimer(d); auto_timer.timeout.connect(lambda: (reload_log(), refresh_status()))
    auto_timer.start(5000)

    l.addWidget(close_btn(d)); d.exec()
    auto_timer.stop()

# ─── 16. 授權管理 — 權限開關 ─────────────────────────
def dlg_auth_mgr(parent):
    d, l = make_dialog(parent, "🔑 系統授權管理 — 權限開關中心", w=700, h=560)
    cfg_path = os.path.join(BASE_DIR, "config.json")
    def _cfg():
        try: return json.load(open(cfg_path))
        except: return {}
    def _save(cfg): json.dump(cfg, open(cfg_path,"w"), indent=2, ensure_ascii=False)

    cfg = _cfg()
    perms = cfg.get("permissions", {
        "allow_shell_exec": True, "allow_web_scrape": True,
        "allow_file_write": True, "allow_auto_task": True,
        "allow_unknown_users": False, "god_mode": True,
        "require_confirm_dangerous": False, "allow_telegram_control": True
    })

    PERM_LABELS = [
        ("allow_shell_exec",       "🖥️  Shell 指令執行權限"),
        ("allow_web_scrape",       "🌐 網頁爬蟲技能授權"),
        ("allow_file_write",       "📝 本地文件讀寫授權"),
        ("allow_auto_task",        "⏰ 自動定時任務授權"),
        ("allow_unknown_users",    "👤 允許未知用戶對話"),
        ("god_mode",               "⚡ God Mode (無限制全開)"),
        ("require_confirm_dangerous", "🛡️ 高風險操作前要求確認"),
        ("allow_telegram_control", "📡 Telegram 遠端操控授權"),
    ]

    g = QGroupBox("全域權限開關"); g.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    gl = QVBoxLayout(g)
    toggles = {}
    for key, label in PERM_LABELS:
        row = QHBoxLayout()
        cb = QCheckBox(label); cb.setChecked(perms.get(key, False))
        cb.setStyleSheet("color:#e2e8f0;font-size:13px;")
        state_lbl = QLabel("🟢 開啟" if perms.get(key, False) else "🔴 關閉")
        state_lbl.setStyleSheet(f"color:{'#22c55e' if perms.get(key,False) else '#ef4444'};font-weight:bold;min-width:70px;")
        def _on_toggle(checked, k=key, lbl=state_lbl):
            lbl.setText("🟢 開啟" if checked else "🔴 關閉")
            lbl.setStyleSheet(f"color:{'#22c55e' if checked else '#ef4444'};font-weight:bold;min-width:70px;")
        cb.toggled.connect(_on_toggle)
        toggles[key] = cb
        row.addWidget(cb); row.addStretch(); row.addWidget(state_lbl)
        gl.addLayout(row)
    l.addWidget(g)

    info = QLabel("")
    def save_perms():
        cfg2 = _cfg()
        cfg2["permissions"] = {k: toggles[k].isChecked() for k in toggles}
        _save(cfg2); info.setText("✅ 權限設定已儲存！"); info.setStyleSheet("color:#22c55e;font-weight:bold;")
    h = QHBoxLayout()
    b_save = QPushButton("💾 儲存全部權限設定"); b_save.setStyleSheet(BTN_GREEN); b_save.setFixedHeight(40)
    b_save.clicked.connect(save_perms)
    h.addWidget(b_save); h.addWidget(info); h.addStretch()
    l.addLayout(h); l.addWidget(close_btn(d)); d.exec()

# ─── 17. 白名單 / 黑名單管理 ────────────────────────
def dlg_whitelist(parent):
    d, l = make_dialog(parent, "👥 白名單 / 黑名單管理", w=700, h=520)
    cfg_path = "/home/user/Desktop/專案/config.json"
    def _cfg():
        try: return json.load(open(cfg_path))
        except: return {}
    def _save(cfg): json.dump(cfg, open(cfg_path,"w"), indent=2, ensure_ascii=False)

    cfg = _cfg()
    whitelist = cfg.get("whitelist_ids", [])
    blacklist = cfg.get("blacklist_ids", [])

    g_wl = QGroupBox("✅ 白名單 — 允許對話的 Chat ID"); g_wl.setStyleSheet("color:#22c55e;border:1px solid #064e3b;border-radius:6px;margin-top:8px;")
    lwl = QVBoxLayout(g_wl)
    wl_edit = QTextEdit("\n".join(str(x) for x in whitelist)); wl_edit.setStyleSheet(DARK); wl_edit.setFixedHeight(120)
    wl_edit.setPlaceholderText("每行輸入一個 Telegram Chat ID，例如: 123456789")
    lwl.addWidget(wl_edit)

    g_bl = QGroupBox("🚫 黑名單 — 封鎖的 Chat ID"); g_bl.setStyleSheet("color:#ef4444;border:1px solid #450a0a;border-radius:6px;margin-top:8px;")
    lbl_g = QVBoxLayout(g_bl)
    bl_edit = QTextEdit("\n".join(str(x) for x in blacklist)); bl_edit.setStyleSheet(DARK); bl_edit.setFixedHeight(120)
    bl_edit.setPlaceholderText("每行輸入一個 Telegram Chat ID")
    lbl_g.addWidget(bl_edit)

    l.addWidget(g_wl); l.addWidget(g_bl)
    info = QLabel("")
    def save_lists():
        cfg2 = _cfg()
        cfg2["whitelist_ids"] = [x.strip() for x in wl_edit.toPlainText().split("\n") if x.strip()]
        cfg2["blacklist_ids"] = [x.strip() for x in bl_edit.toPlainText().split("\n") if x.strip()]
        _save(cfg2); info.setText("✅ 名單已儲存！"); info.setStyleSheet("color:#22c55e;font-weight:bold;")
    h = QHBoxLayout()
    b = QPushButton("💾 儲存名單設定"); b.setStyleSheet(BTN_GREEN); b.setFixedHeight(40); b.clicked.connect(save_lists)
    h.addWidget(b); h.addWidget(info); h.addStretch()
    l.addLayout(h); l.addWidget(close_btn(d)); d.exec()

# ─── 18. 自動回覆規則管理 ───────────────────────────
def dlg_auto_reply(parent):
    d, l = make_dialog(parent, "🤖 自動回覆規則管理", w=750, h=540)
    cfg_path = "/home/user/Desktop/專案/config.json"
    def _cfg():
        try: return json.load(open(cfg_path))
        except: return {}
    def _save(cfg): json.dump(cfg, open(cfg_path,"w"), indent=2, ensure_ascii=False)

    cfg = _cfg()
    rules = cfg.get("auto_reply_rules", [
        {"keyword": "/hello", "reply": "你好主控官！指揮中心已就緒 ⚡"},
        {"keyword": "狀態", "reply": "系統運行正常，所有技能待命！🟢"},
    ])

    tbl = QTableWidget(max(len(rules), 5), 2); tbl.setStyleSheet(DARK)
    tbl.setHorizontalHeaderLabels(["觸發關鍵詞 / 指令", "自動回覆內容"])
    for i, r in enumerate(rules):
        tbl.setItem(i, 0, QTableWidgetItem(r.get("keyword","")))
        tbl.setItem(i, 1, QTableWidgetItem(r.get("reply","")))
    tbl.horizontalHeader().setStretchLastSection(True)
    l.addWidget(QLabel("💡 當 Bot 收到包含關鍵詞的訊息時，自動觸發對應回覆（優先於 Agent 處理）:"))
    l.addWidget(tbl)

    h = QHBoxLayout()
    b_add = QPushButton("➕ 新增規則"); b_add.setStyleSheet(BTN)
    b_del = QPushButton("🗑 刪除選中行"); b_del.setStyleSheet(BTN_RED)
    b_save = QPushButton("💾 儲存規則"); b_save.setStyleSheet(BTN_GREEN)
    info = QLabel("")
    def add_row(): r = tbl.rowCount(); tbl.insertRow(r); tbl.setItem(r,0,QTableWidgetItem("")); tbl.setItem(r,1,QTableWidgetItem(""))
    def del_row():
        for idx in sorted(set(i.row() for i in tbl.selectedItems()), reverse=True): tbl.removeRow(idx)
    def save_rules():
        new_rules = []
        for i in range(tbl.rowCount()):
            kw = tbl.item(i,0).text().strip() if tbl.item(i,0) else ""
            rp = tbl.item(i,1).text().strip() if tbl.item(i,1) else ""
            if kw: new_rules.append({"keyword":kw,"reply":rp})
        cfg2 = _cfg(); cfg2["auto_reply_rules"] = new_rules; _save(cfg2)
        info.setText("✅ 規則已儲存！"); info.setStyleSheet("color:#22c55e;font-weight:bold;")
    b_add.clicked.connect(add_row); b_del.clicked.connect(del_row); b_save.clicked.connect(save_rules)
    h.addWidget(b_add); h.addWidget(b_del); h.addWidget(b_save); h.addWidget(info); h.addStretch()
    l.addLayout(h); l.addWidget(close_btn(d)); d.exec()

# ─── 19. 定時任務管理 ───────────────────────────────
def dlg_scheduled_tasks(parent):
    d, l = make_dialog(parent, "⏰ 定時任務管理中心", w=750, h=540)
    cfg_path = "/home/user/Desktop/專案/config.json"
    def _cfg():
        try: return json.load(open(cfg_path))
        except: return {}
    def _save(cfg): json.dump(cfg, open(cfg_path,"w"), indent=2, ensure_ascii=False)

    cfg = _cfg()
    tasks = cfg.get("scheduled_tasks", [
        {"name": "每日新聞摘要", "query": "幫我摘要今日全球科技新聞重點", "interval_min": 1440, "enabled": True},
        {"name": "系統健康報告", "query": "檢查系統運行狀態並回報", "interval_min": 60, "enabled": False},
    ])

    tbl = QTableWidget(max(len(tasks), 4), 4); tbl.setStyleSheet(DARK)
    tbl.setHorizontalHeaderLabels(["任務名稱", "執行指令", "間隔(分鐘)", "啟用"])
    for i, t in enumerate(tasks):
        tbl.setItem(i, 0, QTableWidgetItem(t.get("name","")))
        tbl.setItem(i, 1, QTableWidgetItem(t.get("query","")))
        tbl.setItem(i, 2, QTableWidgetItem(str(t.get("interval_min", 60))))
        cb_en = QCheckBox(); cb_en.setChecked(t.get("enabled", False)); tbl.setCellWidget(i, 3, cb_en)
    tbl.horizontalHeader().setStretchLastSection(True)
    l.addWidget(QLabel("⏰ 定時任務將由 Bot 自動執行，並主動推送結果到 Telegram:"))
    l.addWidget(tbl)

    h = QHBoxLayout()
    b_add = QPushButton("➕ 新增任務"); b_add.setStyleSheet(BTN)
    b_del = QPushButton("🗑 刪除選中"); b_del.setStyleSheet(BTN_RED)
    b_save = QPushButton("💾 儲存任務"); b_save.setStyleSheet(BTN_GREEN)
    info = QLabel("")
    def add_row():
        r = tbl.rowCount(); tbl.insertRow(r)
        tbl.setItem(r,0,QTableWidgetItem("新任務")); tbl.setItem(r,1,QTableWidgetItem("執行指令"))
        tbl.setItem(r,2,QTableWidgetItem("60")); tbl.setCellWidget(r,3,QCheckBox())
    def del_row():
        for idx in sorted(set(i.row() for i in tbl.selectedItems()), reverse=True): tbl.removeRow(idx)
    def save_tasks():
        new_tasks = []
        try:
            import sqlite3
            conn = sqlite3.connect("/home/user/Desktop/專案/brain/memory.sqlite")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM scheduled_tasks") # 先清空再同步
            for i in range(tbl.rowCount()):
                name = tbl.item(i,0).text().strip() if tbl.item(i,0) else ""
                query = tbl.item(i,1).text().strip() if tbl.item(i,1) else ""
                interval = tbl.item(i,2).text().strip() if tbl.item(i,2) else "60"
                cb_w = tbl.cellWidget(i,3); enabled = cb_w.isChecked() if cb_w else False
                if name: 
                    new_tasks.append({"name":name,"query":query,"interval_min":int(interval) if interval.isdigit() else 60,"enabled":enabled})
                    # 同步到 SQLite
                    status = "ACTIVE" if enabled else "DISABLED"
                    from datetime import datetime, timedelta
                    next_run = (datetime.now() + timedelta(minutes=int(interval) if interval.isdigit() else 60)).isoformat()
                    cursor.execute("INSERT INTO scheduled_tasks (task_name, query, interval_minutes, next_run, status) VALUES (?,?,?,?,?)",
                                   (name, query, int(interval) if interval.isdigit() else 60, next_run, status))
            conn.commit(); conn.close()
            cfg2 = _cfg(); cfg2["scheduled_tasks"] = new_tasks; _save(cfg2)
            info.setText("✅ 任務已儲存並同步到核心！"); info.setStyleSheet("color:#22c55e;font-weight:bold;")
        except Exception as e:
            info.setText(f"❌ 儲存失敗: {e}"); info.setStyleSheet("color:#ef4444;")
    b_add.clicked.connect(add_row); b_del.clicked.connect(del_row); b_save.clicked.connect(save_tasks)
    h.addWidget(b_add); h.addWidget(b_del); h.addWidget(b_save); h.addWidget(info); h.addStretch()
    l.addLayout(h)

    # --- 調度引擎控制 ---
    g_ctrl = QGroupBox("⚙️ 調度引擎背景進程控制 (Proactive Engine)"); g_ctrl.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:10px;")
    lc = QHBoxLayout(g_ctrl)
    status_lbl = QLabel("● 引擎狀態: 偵測中..."); status_lbl.setStyleSheet("color:#eab308;font-weight:bold;")
    def refresh_status():
        r = subprocess.run(["pgrep", "-f", "brain/scheduler.py"], capture_output=True, text=True)
        if r.stdout.strip():
            status_lbl.setText("🟢 引擎運行中"); status_lbl.setStyleSheet("color:#22c55e;font-weight:bold;")
        else:
            status_lbl.setText("🔴 引擎已停止"); status_lbl.setStyleSheet("color:#ef4444;font-weight:bold;")
    
    b_start = QPushButton("▶ 啟動引擎"); b_start.setStyleSheet(BTN_GREEN)
    b_stop = QPushButton("⏹ 停止引擎"); b_stop.setStyleSheet(BTN_RED)
    
    def do_start():
        subprocess.Popen(["/home/user/Desktop/專案/venv/bin/python3", "/home/user/Desktop/專案/brain/scheduler.py"], cwd="/home/user/Desktop/專案")
        QTimer.singleShot(1000, refresh_status)
    def do_stop():
        subprocess.run(["pkill", "-f", "brain/scheduler.py"])
        QTimer.singleShot(1000, refresh_status)

    b_start.clicked.connect(do_start); b_stop.clicked.connect(do_stop)
    lc.addWidget(status_lbl); lc.addStretch(); lc.addWidget(b_start); lc.addWidget(b_stop)
    l.addWidget(g_ctrl)

    # --- 語義監視器控制 ---
    g_watch = QGroupBox("📂 語義文件監視器 (Semantic Watcher)"); g_watch.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:10px;")
    lw = QHBoxLayout(g_watch)
    w_status_lbl = QLabel("● 監視器狀態: 偵測中..."); w_status_lbl.setStyleSheet("color:#eab308;font-weight:bold;")
    
    def refresh_w_status():
        r = subprocess.run(["pgrep", "-f", "brain/watcher.py"], capture_output=True, text=True)
        if r.stdout.strip():
            w_status_lbl.setText("🟢 監視器運行中"); w_status_lbl.setStyleSheet("color:#22c55e;font-weight:bold;")
        else:
            w_status_lbl.setText("🔴 監視器已停止"); w_status_lbl.setStyleSheet("color:#ef4444;font-weight:bold;")

    b_w_start = QPushButton("▶ 啟動監視器"); b_w_start.setStyleSheet(BTN_GREEN)
    b_w_stop = QPushButton("⏹ 停止監視器"); b_w_stop.setStyleSheet(BTN_RED)
    
    def do_w_start():
        subprocess.Popen(["/home/user/Desktop/專案/venv/bin/python3", "/home/user/Desktop/專案/brain/watcher.py"], cwd="/home/user/Desktop/專案")
        QTimer.singleShot(1000, refresh_w_status)
    def do_w_stop():
        subprocess.run(["pkill", "-f", "brain/watcher.py"])
        QTimer.singleShot(1000, refresh_w_status)

    b_w_start.clicked.connect(do_w_start); b_w_stop.clicked.connect(do_w_stop)
    lw.addWidget(w_status_lbl); lw.addStretch(); lw.addWidget(b_w_start); lw.addWidget(b_w_stop)
    l.addWidget(g_watch)

    refresh_status(); refresh_w_status()
    l.addWidget(close_btn(d)); d.exec()

# ─── 20. Bot 人格與靈魂設定 ─────────────────────────
def dlg_personality(parent):
    d, l = make_dialog(parent, "🧠 Agent 人格與靈魂設定", w=780, h=580)
    cfg_path = "/home/user/Desktop/專案/config.json"
    master_path = "/home/user/Desktop/專案/brain/master.py"
    def _cfg():
        try: return json.load(open(cfg_path))
        except: return {}
    def _save(cfg): json.dump(cfg, open(cfg_path,"w"), indent=2, ensure_ascii=False)

    cfg = _cfg()
    g_basic = QGroupBox("🎭 基本人格設定"); g_basic.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    f = QFormLayout(g_basic)
    name_in = QLineEdit(cfg.get("agent_name", "TOP Agent")); name_in.setStyleSheet(DARK)
    title_in = QLineEdit(cfg.get("user_title", "主控官")); title_in.setStyleSheet(DARK)
    style_cb = QComboBox(); style_cb.setStyleSheet(DARK)
    style_cb.addItems(["戰術首席官 (預設)","冷靜科學家","熱情助理","幽默駭客","嚴肅軍師"])
    style_cb.setCurrentText(cfg.get("agent_style", "戰術首席官 (預設)"))
    lang_cb = QComboBox(); lang_cb.setStyleSheet(DARK)
    lang_cb.addItems(["繁體中文 (Traditional Chinese)", "簡體中文 (Simplified Chinese)", "英文 (English)", "日文 (Japanese)", "中英混合 (Mixed)"])
    lang_cb.setCurrentText(cfg.get("reply_lang", "繁體中文 (Traditional Chinese)"))
    
    voice_cb = QCheckBox("啟用戰術語音播報 (Voice Broadcast)")
    voice_cb.setChecked(cfg.get("enable_voice", False)); voice_cb.setStyleSheet("color:#38bdf8;")
    
    f.addRow("Agent 名稱:", name_in); f.addRow("稱呼使用者為:", title_in)
    f.addRow("說話風格:", style_cb); f.addRow("回覆語言:", lang_cb)
    f.addRow("語音設定:", voice_cb)
    l.addWidget(g_basic)

    g_prompt = QGroupBox("✍️ 系統指令 (System Prompt) 直接編輯"); g_prompt.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    gpl = QVBoxLayout(g_prompt)
    prompt_editor = QTextEdit(); prompt_editor.setStyleSheet(DARK); prompt_editor.setFixedHeight(180)
    try:
        src = open(master_path).read()
        import re as _re
        m = _re.search(r'instructions\s*=\s*"""(.+?)"""', src, _re.DOTALL)
        prompt_editor.setText(m.group(1).strip() if m else "讀取失敗，請手動編輯")
    except Exception as e:
        prompt_editor.setText(f"讀取失敗: {e}")
    gpl.addWidget(prompt_editor); l.addWidget(g_prompt)

    g_flags = QGroupBox("🚦 進階行為開關"); g_flags.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:8px;")
    gfl = QVBoxLayout(g_flags)
    flags = [("主動出擊 (先斬後奏)","proactive_mode",True),("禁止道歉語句","no_apology",True),
             ("自動調用工具","auto_tool",True),("傳送思考步驟到 Telegram","send_steps_tg",False),
             ("強制行動覆寫 (Hard Prompt 不准反問)","force_hard_prompt",False)]
    flag_cbs = {}
    for label, key, default in flags:
        row = QHBoxLayout(); cb = QCheckBox(label); cb.setChecked(cfg.get(key, default))
        cb.setStyleSheet("color:#e2e8f0;"); flag_cbs[key] = cb; row.addWidget(cb); gfl.addLayout(row)
    l.addWidget(g_flags)

    info = QLabel(""); info.setStyleSheet("font-size: 13px;")
    def save_all():
        cfg2 = _cfg()
        cfg2["agent_name"] = name_in.text(); cfg2["user_title"] = title_in.text()
        cfg2["agent_style"] = style_cb.currentText(); cfg2["reply_lang"] = lang_cb.currentText()
        cfg2["enable_voice"] = voice_cb.isChecked()
        for k, cb in flag_cbs.items(): cfg2[k] = cb.isChecked()
        _save(cfg2)
        try:
            src = open(master_path).read()
            import re as _re
            new_prompt = prompt_editor.toPlainText()
            new_src = _re.sub(r'(instructions\s*=\s*""").*?(""")', f'\\1\n{new_prompt}\n    \\2', src, flags=_re.DOTALL)
            open(master_path, "w").write(new_src)
            info.setText("✅ 人格與語言設定已儲存成功！大腦將立即套用。"); info.setStyleSheet("color:#22c55e;font-weight:bold;")
            QTimer.singleShot(3000, lambda: info.setText(""))
        except Exception as e:
            info.setText(f"⚠️ 設定已儲存，但 master.py 更新失敗: {e}"); info.setStyleSheet("color:#f97316;")

    h = QHBoxLayout()
    b = QPushButton("💾 儲存並即時套用人格"); b.setStyleSheet(BTN_GREEN); b.setFixedHeight(40); b.clicked.connect(save_all)
    h.addWidget(b); h.addWidget(info); h.addStretch()
    l.addLayout(h); l.addWidget(close_btn(d)); d.exec()

# ─── 21. Telegram 監控 + 內容版面設定 ─────────────────
def dlg_telegram_monitor(parent):
    import re as _re, time as _time
    d, l = make_dialog(parent, "📡 Telegram 訊息監控 & 內容版面設定", w=860, h=700)

    CFG = "/home/user/Desktop/專案/config.json"
    LOG = "/home/user/Desktop/專案/logs/telegram_bot.log"
    def _cfg():
        try: return json.load(open(CFG))
        except: return {}
    def _save(cfg): json.dump(cfg, open(CFG,"w"), indent=2, ensure_ascii=False)

    # ════════════════════════════════════════════════
    # 區塊 A：即時訊息監控視窗
    # ════════════════════════════════════════════════
    g_mon = QGroupBox("👁️ Telegram ↔ Agent 即時訊息流監控")
    g_mon.setStyleSheet("color:#38bdf8;border:1px solid #1e293b;border-radius:6px;margin-top:6px;")
    lm = QVBoxLayout(g_mon)

    hdr_row = QHBoxLayout()
    lbl_bot_status = QLabel("● 偵測中...")
    lbl_bot_status.setStyleSheet("color:#eab308;font-weight:bold;")
    lbl_relay_status = QLabel("Agent 中繼: 未知")
    lbl_relay_status.setStyleSheet("color:#94a3b8;")
    hdr_row.addWidget(lbl_bot_status); hdr_row.addWidget(lbl_relay_status); hdr_row.addStretch()
    lm.addLayout(hdr_row)

    # 訊息流顯示區 (解析日誌，只顯示收發紀錄)
    msg_feed = QTextEdit(); msg_feed.setReadOnly(True)
    msg_feed.setStyleSheet("background:#000;color:#22c55e;font-family:Consolas,monospace;font-size:12px;")
    msg_feed.setFixedHeight(200)

    cfg_ref = _cfg()
    # 內容過濾器設定（從 config 讀取）
    filter_code    = cfg_ref.get("tg_filter_code", True)
    filter_garbled = cfg_ref.get("tg_filter_garbled", True)
    filter_think   = cfg_ref.get("tg_filter_think", True)

    def _apply_filters(text):
        """根據過濾器設定清理顯示文字"""
        if filter_think:
            text = _re.sub(r'<think>.*?</think>', '[🧠思考已隱藏]', text, flags=_re.DOTALL)
        if filter_code:
            text = _re.sub(r'```[\s\S]*?```', '[📦程式碼已隱藏]', text)
            text = _re.sub(r'`[^`]+`', '[📦程式碼]', text)
        if filter_garbled:
            # 移除大量連續特殊字元/控制字元
            text = _re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
            text = _re.sub(r'[^\u0000-\uFFFF]', '?', text)
        return text.strip()

    _last_log_size = [0]
    def parse_log_to_feed():
        nonlocal filter_code, filter_garbled, filter_think
        try:
            if not os.path.exists(LOG): msg_feed.setText(">>> 尚無日誌"); return
            size = os.path.getsize(LOG)
            lines = open(LOG, errors='replace').readlines()
            new_entries = []
            for line in lines[-120:]:
                # 收到訊息
                if "handle_text_message" in line or "MESSAGE_IN" in line:
                    new_entries.append(f"📥 [收到] {line.strip()}")
                # 回覆訊息
                elif "reply_text" in line or "send_message" in line or "MESSAGE_OUT" in line:
                    new_entries.append(f"📤 [發出] {line.strip()}")
                # Agent 開始處理
                elif "[THINKING]" in line or "SILENT" in line:
                    new_entries.append(f"🧠 {line.strip()}")
                # 超時
                elif "TimeoutError" in line or "timeout" in line.lower():
                    new_entries.append(f"⏰ [超時] {line.strip()}")
                # 錯誤
                elif "ERROR" in line or "Exception" in line:
                    new_entries.append(f"❌ [錯誤] {line.strip()}")
                # Bot 上線
                elif "Application started" in line or "getUpdates" in line:
                    new_entries.append(f"✅ [系統] Bot 正常輪詢中")
            if new_entries:
                filtered = [_apply_filters(e) for e in new_entries[-60:]]
                msg_feed.setText("\n".join(filtered))
                msg_feed.verticalScrollBar().setValue(msg_feed.verticalScrollBar().maximum())
            # 更新狀態
            r = subprocess.run(["pgrep","-f","telegram_bot.py"], capture_output=True, text=True)
            if r.stdout.strip():
                lbl_bot_status.setText("🟢 Bot 運行中"); lbl_bot_status.setStyleSheet("color:#22c55e;font-weight:bold;")
                lbl_relay_status.setText("Agent 中繼: ✅ 已連接 (訊息正在傳遞)")
                lbl_relay_status.setStyleSheet("color:#22c55e;")
            else:
                lbl_bot_status.setText("🔴 Bot 已停止"); lbl_bot_status.setStyleSheet("color:#ef4444;font-weight:bold;")
                lbl_relay_status.setText("Agent 中繼: ❌ 未連接"); lbl_relay_status.setStyleSheet("color:#ef4444;")
        except Exception as e:
            msg_feed.append(f"[LOG ERROR] {e}")

    parse_log_to_feed()

    h_btns = QHBoxLayout()
    b_refresh = QPushButton("🔄 立即刷新"); b_refresh.setStyleSheet(BTN)
    b_clear = QPushButton("🗑 清空日誌"); b_clear.setStyleSheet(BTN_RED)
    b_start = QPushButton("▶ 啟動 Bot"); b_start.setStyleSheet(BTN_GREEN)
    b_stop  = QPushButton("⏹ 停止 Bot"); b_stop.setStyleSheet(BTN_RED)
    def do_start():
        subprocess.run(["pkill","-9","-f","telegram_bot.py"], capture_output=True)
        _time.sleep(0.8)
        with open(LOG, "a") as lf:
            subprocess.Popen(["/home/user/Desktop/專案/venv/bin/python3","telegram_bot.py"],
                             cwd="/home/user/Desktop/專案", stdout=lf, stderr=lf)
        _time.sleep(1); parse_log_to_feed()
    def do_stop():
        subprocess.run(["pkill","-9","-f","telegram_bot.py"], capture_output=True)
        _time.sleep(0.5); parse_log_to_feed()
    def do_clear(): open(LOG,"w").close(); msg_feed.clear()
    b_refresh.clicked.connect(parse_log_to_feed); b_clear.clicked.connect(do_clear)
    b_start.clicked.connect(do_start); b_stop.clicked.connect(do_stop)
    h_btns.addWidget(b_start); h_btns.addWidget(b_stop); h_btns.addWidget(b_refresh); h_btns.addWidget(b_clear)
    lm.addWidget(msg_feed); lm.addLayout(h_btns)
    l.addWidget(g_mon)

    # ════════════════════════════════════════════════
    # 區塊 B：內容版面過濾器
    # ════════════════════════════════════════════════
    g_filter = QGroupBox("🧹 Telegram 訊息內容過濾器 (顯示設定)")
    g_filter.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:6px;")
    lf_box = QVBoxLayout(g_filter)

    cfg2 = _cfg()
    FILTER_SETTINGS = [
        ("tg_filter_code",       "📦 遮蔽原始碼區塊 (``` 程式碼 ```) — 顯示為 [程式碼已隱藏]",       True),
        ("tg_filter_think",      "🧠 遮蔽 AI 內部思考標籤 (<think>...</think>) — 只顯示結論",      True),
        ("tg_filter_garbled",    "🔤 移除亂碼/控制字元 — 防止顯示不明字元",                          True),
        ("tg_filter_empty_lines","📄 移除多餘空行 — 讓回覆更緊湊",                                   False),
        ("tg_filter_debug_step", "🔕 隱藏 [DEBUG_STEP] 思考步驟訊息 — 只推送最終答案",              True),
        ("tg_send_steps",        "📊 傳送 Agent 思考進度條到 Telegram (開啟=顯示進度)",              True),
    ]
    filter_cbs = {}
    for key, label, default in FILTER_SETTINGS:
        row = QHBoxLayout()
        cb = QCheckBox(label); cb.setChecked(cfg2.get(key, default))
        cb.setStyleSheet("color:#e2e8f0;font-size:12px;")
        filter_cbs[key] = cb; row.addWidget(cb); lf_box.addLayout(row)
    l.addWidget(g_filter)

    # ════════════════════════════════════════════════
    # 區塊 C：Bot 行為設定 (超時 / 分割 / 修復)
    # ════════════════════════════════════════════════
    g_behav = QGroupBox("⚙️ Bot 行為參數設定")
    g_behav.setStyleSheet("color:#7dd3fc;border:1px solid #1e293b;border-radius:6px;margin-top:6px;")
    lb = QFormLayout(g_behav)

    timeout_spin = QSpinBox(); timeout_spin.setRange(10, 300); timeout_spin.setSuffix(" 秒")
    timeout_spin.setValue(cfg2.get("tg_timeout_sec", 60)); timeout_spin.setStyleSheet(DARK)

    max_turns_spin = QSpinBox(); max_turns_spin.setRange(1, 20); max_turns_spin.setSuffix(" 輪")
    max_turns_spin.setValue(cfg2.get("agent_max_turns", 5)); max_turns_spin.setStyleSheet(DARK)

    typing_interval_spin = QSpinBox(); typing_interval_spin.setRange(1, 5); typing_interval_spin.setSuffix(" 秒")
    typing_interval_spin.setValue(cfg2.get("tg_typing_interval", 4)); typing_interval_spin.setStyleSheet(DARK)

    split_cb = QCheckBox("啟用長訊息自動分割 (超過4000字自動切段)"); split_cb.setChecked(cfg2.get("tg_auto_split", True))
    split_cb.setStyleSheet("color:#e2e8f0;")

    typing_cb = QCheckBox("顯示「輸入中...」動態提示"); typing_cb.setChecked(cfg2.get("tg_typing_indicator", True))
    typing_cb.setStyleSheet("color:#e2e8f0;")

    progress_cb = QCheckBox("顯示 ⏳ 進化引擎運行中 進度訊息"); progress_cb.setChecked(cfg2.get("tg_show_progress", True))
    progress_cb.setStyleSheet("color:#e2e8f0;")

    lb.addRow("🕐 Agent 回覆超時上限:", timeout_spin)
    lb.addRow("🔄 Agent 最大思考輪次:", max_turns_spin)
    lb.addRow("💬 Typing 動畫刷新間隔:", typing_interval_spin)
    lb.addRow("", split_cb)
    lb.addRow("", typing_cb)
    lb.addRow("", progress_cb)
    l.addWidget(g_behav)

    # ════════════════════════════════════════════════
    # 儲存按鈕
    # ════════════════════════════════════════════════
    info_lbl = QLabel("")
    def save_all():
        nonlocal filter_code, filter_garbled, filter_think
        cfg3 = _cfg()
        for key, cb in filter_cbs.items():
            cfg3[key] = cb.isChecked()
        cfg3["tg_timeout_sec"]       = timeout_spin.value()
        cfg3["agent_max_turns"]      = max_turns_spin.value()
        cfg3["tg_typing_interval"]   = typing_interval_spin.value()
        cfg3["tg_auto_split"]        = split_cb.isChecked()
        cfg3["tg_typing_indicator"]  = typing_cb.isChecked()
        cfg3["tg_show_progress"]     = progress_cb.isChecked()
        _save(cfg3)
        # 更新本地過濾器狀態
        filter_code    = filter_cbs.get("tg_filter_code", QCheckBox()).isChecked()
        filter_garbled = filter_cbs.get("tg_filter_garbled", QCheckBox()).isChecked()
        filter_think   = filter_cbs.get("tg_filter_think", QCheckBox()).isChecked()
        # 同步寫入 executor.py 的 max_turns
        try:
            src = open("/home/user/Desktop/專案/brain/executor.py").read()
            import re as re2
            new_src = re2.sub(r'max_turns\s*=\s*\d+', f'max_turns = {max_turns_spin.value()}', src)
            open("/home/user/Desktop/專案/brain/executor.py","w").write(new_src)
        except: pass
        info_lbl.setText("✅ 所有設定已儲存並即時套用！"); info_lbl.setStyleSheet("color:#22c55e;font-weight:bold;")

    h_save = QHBoxLayout()
    b_save = QPushButton("💾 儲存所有設定並即時套用"); b_save.setStyleSheet(BTN_GREEN); b_save.setFixedHeight(42)
    b_save.clicked.connect(save_all)
    h_save.addWidget(b_save); h_save.addWidget(info_lbl); h_save.addStretch()
    l.addLayout(h_save)

    # 自動刷新 (每5秒)
    auto_timer = QTimer(d); auto_timer.timeout.connect(parse_log_to_feed); auto_timer.start(5000)
    l.addWidget(close_btn(d)); d.exec()
    auto_timer.stop()


# ─── 13. 核心遙測與日誌矩陣 (Core Telemetry & Log Matrix) ──────────────────────────
def dlg_god_eye_monitor(parent):
    d, l = make_dialog(parent, "上帝之眼 — 全域日誌即時串流", w=1000, h=700)
    l.addWidget(QLabel("💡 此面板提供 Agent 的核心思考鏈與進化日誌的完整歷史檢視。"))
    
    txt = QTextEdit(); txt.setReadOnly(True); txt.setStyleSheet(DARK); txt.setFontFamily("Consolas")
    l.addWidget(txt)
    
    def refresh():
        if hasattr(parent, "seq_list"):
            txt.setHtml(parent.seq_list.toHtml())
            txt.moveCursor(QTextCursor.End)
    
    t = QTimer(d); t.timeout.connect(refresh); t.start(2000)
    refresh()
    
    l.addWidget(close_btn(d)); d.exec()

def dlg_engine_logs(parent):
    d, l = make_dialog(parent, "戰術引擎後台監控 — 實時日誌流", w=1000, h=700)
    l.addWidget(QLabel("💡 監控 Healer, Hunter, Watcher 等核心引擎的底層運作狀態。"))
    
    tabs = QSplitter(Qt.Vertical); l.addWidget(tabs)
    
    logs = [
        ("🛡️ Healer (自癒)", "/home/user/Desktop/專案/logs/watchdog.log"),
        ("🏹 Hunter (獵人)", "/home/user/Desktop/專案/logs/hunter.log"),
        ("👁️ Watcher (監視)", "/home/user/Desktop/專案/logs/watcher.log"),
        ("⏰ Scheduler (調度)", "/home/user/Desktop/專案/logs/scheduler.log")
    ]
    
    editors = []
    for name, path in logs:
        g = QGroupBox(name); gl = QVBoxLayout(g)
        te = QTextEdit(); te.setReadOnly(True); te.setStyleSheet("background:#000000;color:#22c55e;font-family:'Consolas';font-size:11px;")
        gl.addWidget(te); tabs.addWidget(g)
        editors.append((te, path))

    def tail_logs():
        for te, path in editors:
            if os.path.exists(path):
                try:
                    with open(path, 'r') as f:
                        content = f.readlines()[-30:] 
                        te.setPlainText("".join(content))
                        te.moveCursor(QTextCursor.End)
                except: pass
    
    t = QTimer(d); t.timeout.connect(tail_logs); t.start(3000)
    tail_logs()
    
    l.addWidget(close_btn(d)); d.exec()

def dlg_advanced_telemetry(parent):
    d, l = make_dialog(parent, "高階物理性能全覽 (Advanced Metrics)", w=800, h=600)
    l.addWidget(QLabel("💡 此面板提供極致精確的硬體與 AI 生成效率遙測。"))
    
    g = QGroupBox("📊 實時物理數據"); fl = QFormLayout(g)
    cpu_bar = QProgressBar(); mem_bar = QProgressBar(); tps_bar = QProgressBar(); lat_bar = QProgressBar()
    for b in [cpu_bar, mem_bar, tps_bar, lat_bar]: b.setFixedHeight(20); b.setMaximum(100)
    
    fl.addRow("處理器負載 (CPU):", cpu_bar); fl.addRow("記憶體佔用 (RAM):", mem_bar)
    fl.addRow("生成通量 (Throughput %):", tps_bar); fl.addRow("網絡響應延遲 (Latency %):", lat_bar)
    l.addWidget(g)
    
    info = QTextEdit(); info.setReadOnly(True); info.setStyleSheet(DARK); info.setFixedHeight(200)
    l.addWidget(QLabel("📜 性能審核日誌:")); l.addWidget(info)
    
    def update():
        try:
            import psutil
            cpu = psutil.cpu_percent(); mem = psutil.virtual_memory().percent
            cpu_bar.setValue(int(cpu)); mem_bar.setValue(int(mem))
            
            metrics_path = "/home/user/Desktop/專案/brain/system_metrics.json"
            if os.path.exists(metrics_path):
                with open(metrics_path, 'r') as f:
                    data = json.load(f)
                    tps_bar.setValue(data.get('metrics', {}).get('Throughput', 0))
                    lat_bar.setValue(min(100, data.get('metrics', {}).get('SensoryResolution', 0)))
                    info.setPlainText(json.dumps(data, indent=4, ensure_ascii=False))
        except: pass

    t = QTimer(d); t.timeout.connect(update); t.start(2000)
    update()
    
    l.addWidget(close_btn(d)); d.exec()


# ─── 14. 上帝之眼顯示配置 (God's Eye Filter Config) ──────────────────────────
def dlg_god_eye_config(parent):
    d, l = make_dialog(parent, "上帝之眼 — 顯示過濾配置", w=500, h=450)
    l.addWidget(QLabel("💡 您可以決定哪些戰術動作應顯示在「上帝之眼」日誌中。"))
    
    cfg = parent.config.get("god_eye_filters", {
        "show_browser": True, "show_actions": True, "show_tools": True, "show_skills": True, "show_steps": True
    })
    
    g = QGroupBox("🔍 顯示開關 (預設全開)"); fl = QVBoxLayout(g)
    cb_browser = QCheckBox("🌐 顯示網頁瀏覽與爬取過程 (Browser/Web)"); cb_browser.setChecked(cfg.get("show_browser", True))
    cb_actions = QCheckBox("⚡ 顯示核心執行動作與操作 (Actions)"); cb_actions.setChecked(cfg.get("show_actions", True))
    cb_tools = QCheckBox("🛠️ 顯示工具調用與參數 (Tool Calls)"); cb_tools.setChecked(cfg.get("show_tools", True))
    cb_skills = QCheckBox("🧠 顯示技能模組使用與進化 (Skills)"); cb_skills.setChecked(cfg.get("show_skills", True))
    cb_steps = QCheckBox("🔢 顯示底層步驟流水號 (Steps)"); cb_steps.setChecked(cfg.get("show_steps", True))
    
    for cb in [cb_browser, cb_actions, cb_tools, cb_skills, cb_steps]: 
        cb.setStyleSheet("margin: 5px; font-size: 14px;"); fl.addWidget(cb)
    l.addWidget(g)
    
    btn_save = QPushButton("💾 保存配置並即時套用"); btn_save.setStyleSheet(BTN_GREEN); btn_save.setFixedHeight(40)
    def save():
        new_cfg = {
            "show_browser": cb_browser.isChecked(),
            "show_actions": cb_actions.isChecked(),
            "show_tools": cb_tools.isChecked(),
            "show_skills": cb_skills.isChecked(),
            "show_steps": cb_steps.isChecked()
        }
        parent.config["god_eye_filters"] = new_cfg
        parent.save_app_config()
        QMessageBox.information(d, "成功", "上帝之眼過濾配置已更新！")
        d.accept()
        
    btn_save.clicked.connect(save)
    l.addWidget(btn_save); l.addWidget(close_btn(d)); d.exec()

# ─── 15. 戰術武器庫管理矩陣 (Arsenal Manager) ─────────────────────────
def dlg_arsenal_mgr(parent):
    d, l = make_dialog(parent, "⚔️ 戰術武器庫管理矩陣 (The Hands & Feet Control)", w=900, h=650)
    l.addWidget(QLabel("💡 您可以在此動態配置 AGNET 的「手腳」權限。禁用某項工具後，AI 將無法在執行過程中使用它。"))
    
    try:
        from brain.skills import get_skill_metadata
        tools = get_skill_metadata()
    except:
        tools = []
    
    tbl = QTableWidget(len(tools), 3); tbl.setStyleSheet(DARK)
    tbl.setHorizontalHeaderLabels(["工具名稱", "功能描述", "狀態 / 權限開關"])
    tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
    tbl.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
    
    cfg = parent.config.get("skill_execution", {})
    
    for i, t in enumerate(tools):
        name = t["function"]["name"]
        desc = t["function"]["description"]
        tbl.setItem(i, 0, QTableWidgetItem(name))
        tbl.setItem(i, 1, QTableWidgetItem(desc))
        
        status = cfg.get(name, True)
        btn = QPushButton("🟢 已啟動" if status else "🔴 已禁用")
        btn.setStyleSheet(BTN_GREEN if status else BTN_RED)
        
        def make_toggle(n, b):
            def on_toggle():
                current = parent.config.get("skill_execution", {}).get(n, True)
                new_st = not current
                if "skill_execution" not in parent.config: parent.config["skill_execution"] = {}
                parent.config["skill_execution"][n] = new_st
                b.setText("🟢 已啟動" if new_st else "🔴 已禁用")
                b.setStyleSheet(BTN_GREEN if new_st else BTN_RED)
                parent.save_app_config()
            return on_toggle

        btn.clicked.connect(make_toggle(name, btn))
        tbl.setCellWidget(i, 2, btn)
    
    l.addWidget(tbl)
    
    h = QHBoxLayout()
    b_all_on = QPushButton("⚡ 全量解放 (All Enable)"); b_all_on.setStyleSheet(BTN_BLUE)
    b_all_off = QPushButton("🔒 全局封鎖 (All Disable)"); b_all_off.setStyleSheet(BTN_RED)
    
    def set_all(st):
        parent.config["skill_execution"] = {t["function"]["name"]: st for t in tools}
        parent.save_app_config()
        QMessageBox.information(d, "成功", f"武器庫權限已{'全量開放' if st else '全域封鎖'}！\n請重新開啟此視窗以查看狀態。")
        d.accept()

    b_all_on.clicked.connect(lambda: set_all(True))
    b_all_off.clicked.connect(lambda: set_all(False))
    
    h.addWidget(b_all_on); h.addWidget(b_all_off); h.addStretch()
    l.addLayout(h); l.addWidget(close_btn(d)); d.exec()

# ─── 16. 戰術感知控制 (Perception Control) ─────────────────────────
def dlg_perception_control(parent):
    d, l = make_dialog(parent, "👁️ 戰術感知控制 — 全境過濾與思維注入", w=600, h=550)
    l.addWidget(QLabel("💡 此面板整合了「上帝之眼」的顯示過濾，以及對 AGNET 潛意識的實時干預。"))
    
    cfg = parent.config.get("god_eye_filters", {
        "show_browser": True, "show_actions": True, "show_tools": True, "show_skills": True, "show_steps": True
    })
    
    g_filter = QGroupBox("🔍 上帝之眼 — 顯示過濾"); fl = QVBoxLayout(g_filter)
    cb_browser = QCheckBox("🌐 顯示網頁瀏覽與爬取過程"); cb_browser.setChecked(cfg.get("show_browser", True))
    cb_actions = QCheckBox("⚡ 顯示核心執行動作"); cb_actions.setChecked(cfg.get("show_actions", True))
    cb_tools = QCheckBox("🛠️ 顯示工具調用詳情"); cb_tools.setChecked(cfg.get("show_tools", True))
    cb_skills = QCheckBox("🧠 顯示技能模組使用"); cb_skills.setChecked(cfg.get("show_skills", True))
    cb_steps = QCheckBox("🔢 顯示底層步驟流水"); cb_steps.setChecked(cfg.get("show_steps", True))
    
    for cb in [cb_browser, cb_actions, cb_tools, cb_skills, cb_steps]: fl.addWidget(cb)
    l.addWidget(g_filter)
    
    g_mind = QGroupBox("💉 潛意識思維注入 (Mind Injection)"); ml = QVBoxLayout(g_mind)
    ml.addWidget(QLabel("輸入要注入 AGNET 思考鏈的指令："))
    mind_in = QLineEdit(); mind_in.setPlaceholderText("例如：優先使用本地工具，不要頻繁聯網...")
    mind_in.setText(parent.config.get("mind_injection", ""))
    ml.addWidget(mind_in)
    l.addWidget(g_mind)
    
    btn_save = QPushButton("💾 保存並即時套用感知設定"); btn_save.setStyleSheet(BTN_GREEN); btn_save.setFixedHeight(45)
    def save():
        parent.config["god_eye_filters"] = {
            "show_browser": cb_browser.isChecked(),
            "show_actions": cb_actions.isChecked(),
            "show_tools": cb_tools.isChecked(),
            "show_skills": cb_skills.isChecked(),
            "show_steps": cb_steps.isChecked()
        }
        parent.config["mind_injection"] = mind_in.text().strip()
        parent.save_app_config()
        QMessageBox.information(d, "成功", "戰術感知配置與思維注入已更新！")
        d.accept()
        
    btn_save.clicked.connect(save)
    l.addWidget(btn_save); l.addWidget(close_btn(d)); d.exec()

# ─── 17. 戰術行為矯正與禁制矩陣 (Behavioral Correction) ───────────────────
def dlg_behavior_correction(parent):
    d, l = make_dialog(parent, "🛡️ 戰術行為矯正與禁制矩陣 (Behavioral Correction)", w=700, h=600)
    l.addWidget(QLabel("💡 此面板用於矯正 AGNET 的「幻覺」與「欺騙行為」。開啟後，底層內核將被強制執行更嚴格的誠實協議。"))
    
    cfg = parent.config.get("behavior_correction", {
        "strict_honesty": True, 
        "forbid_deception": True,
        "forbid_placeholder": True,
        "evidence_first": True,
        "no_fake_confirmation": True
    })
    
    g = QGroupBox("⚖️ 行為矯正開關"); gl = QVBoxLayout(g)
    
    CORRECTIONS = [
        ("strict_honesty",      "💎 絕對誠實協議 — 禁止任何形式的資訊偽造"),
        ("forbid_deception",    "🚫 嚴禁視覺詐欺 — 禁止在未獲得結果時回報「成功」"),
        ("forbid_placeholder", "📦 禁用占位符內容 — 禁止使用 [此處應有代碼] 等虛擬回覆"),
        ("evidence_first",      "📊 物理證據優先 — 每一項結論都必須附帶原始數據或文件路徑"),
        ("no_fake_confirmation", "🛡️ 拒絕虛假確認 — 工具調用失敗時必須立即坦白，不得繞路"),
    ]
    
    toggles = {}
    for key, label in CORRECTIONS:
        row = QHBoxLayout()
        cb = QCheckBox(label); cb.setChecked(cfg.get(key, True))
        cb.setStyleSheet("color:#e2e8f0; font-size:13px;")
        toggles[key] = cb
        row.addWidget(cb); gl.addLayout(row)
    l.addWidget(g)
    
    g_soul = QGroupBox("💉 靈魂印記補強 (Behavioral Hard-Prompt)"); gsl = QVBoxLayout(g_soul)
    gsl.addWidget(QLabel("若上述開關不足以矯正，請在此輸入「強制行為禁令」："))
    hard_prompt = QTextEdit(); hard_prompt.setPlaceholderText("例如：絕對禁止道歉、禁止解釋為什麼不能執行，直接報告失敗原因即可..."); hard_prompt.setFixedHeight(100)
    hard_prompt.setText(parent.config.get("behavior_hard_prompt", ""))
    gsl.addWidget(hard_prompt)
    l.addWidget(g_soul)
    
    btn_save = QPushButton("💾 寫入行為基因並重啟邏輯內核"); btn_save.setStyleSheet(BTN_GREEN); btn_save.setFixedHeight(45)
    
    def save():
        btn_save.setText("🛰️ 正在寫入行為基因序列..."); btn_save.setEnabled(False)
        btn_save.setStyleSheet("background: #0369a1; color: white; border-radius: 4px;") # 轉為深藍色表示處理中
        
        def finalize_save():
            parent.config["behavior_correction"] = {k: v.isChecked() for k, v in toggles.items()}
            parent.config["behavior_hard_prompt"] = hard_prompt.toPlainText().strip()
            parent.save_app_config()
            
            btn_save.setText("✅ 行為基因寫入成功！")
            btn_save.setStyleSheet("background: #15803d; color: white; border-radius: 4px;")
            
            # 🆕 戰術同步：直接在上帝之眼日誌中回報
            if hasattr(parent, 'append_evolution'):
                parent.append_evolution("🧬 [GENE_UPGRADE]: 戰術行為基因已完成重寫，行為禁制協議已即時生效。")
            
            QTimer.singleShot(1000, d.accept)
            
        QTimer.singleShot(600, finalize_save)
        
    btn_save.clicked.connect(save)
    l.addWidget(btn_save); l.addWidget(close_btn(d)); d.exec()

# ─── 最終路由表 (Final Router) ──────────────────────────
PANEL_ROUTER = {
    "list_agent": dlg_list_agent, "new_agent": dlg_new_agent, "perf_agent": dlg_perf_agent,
    "model_mgr": dlg_model_mgr, "plugin_mgr": dlg_plugin_mgr, "prompt_mgr": dlg_prompt_mgr,
    "kb_mgr": dlg_kb_mgr, "users": dlg_users, "audit": dlg_audit,
    "stats": dlg_stats, "report": dlg_report, "billing": dlg_billing,
    "self_heal": dlg_self_heal, "vector_mem": dlg_vector_mem, "ambient": dlg_ambient,
    "telegram_mgr": dlg_telegram_mgr,
    "auth_mgr": dlg_auth_mgr, "whitelist": dlg_whitelist,
    "auto_reply": dlg_auto_reply, "scheduled_tasks": dlg_scheduled_tasks,
    "personality": dlg_personality,
    "telegram_monitor": dlg_telegram_monitor,
    "god_eye": dlg_god_eye_monitor,
    "engine_logs": dlg_engine_logs,
    "adv_metrics": dlg_advanced_telemetry,
    "god_eye_config": dlg_god_eye_config,
    "arsenal_mgr": dlg_arsenal_mgr,
    "perception_control": dlg_perception_control,
    "behavior_correction": dlg_behavior_correction,
}

def show_panel(feature_id, parent):
    fn = PANEL_ROUTER.get(feature_id)
    if fn: fn(parent)
