#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CPBL 中华职棒赛程查询工具 - 神之脑版
"""

import requests
from bs4 import BeautifulSoup
import re
from datetime import datetime

def query_cpbl_schedule(date_str=None):
    """
    查询中华职棒赛程
    
    Args:
        date_str: 日期格式 YYYY-MM-DD，如不传则查询今天
    
    Returns:
        list: 包含比赛信息的列表
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    base_url = "https://www.cpbl.com.tw/schedule"
    url = f"{base_url}/{date_str}"
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = 'utf-8'
        
        if response.status_code != 200:
            return [{"error": f"HTTP {response.status_code}"}]
        
        soup = BeautifulSoup(response.text, 'html.parser')
        games = []
        
        # 尝试不同的选择器
        game_items = soup.select('.game-item') or soup.select('.match')
        
        for item in game_items:
            game_info = {}
            
            # 尝试获取球队信息
            teams = item.select('.team')
            
            # 尝试获取比分
            scores = item.select('.score')
            
            games.append({
                'status': '比赛进行中' if '进行中' in str(item) else '已结束'
            })
        
        return games
        
    except Exception as e:
        return [{"error": str(e)}]

# 使用示例
if __name__ == '__main__':
    result = query_cpbl_schedule('2025-05-03')
    for game in result:
        print(game)