import os
import time
import subprocess
import sys
from datetime import datetime

# 目標日誌
LOGS = {
    "TELEGRAM": "/home/user/Desktop/專案/logs/telegram_bot.log",
    "SCHEDULER": "/home/user/Desktop/專案/logs/scheduler.log"
}

def push_step(msg):
    print(f"🛡️ [WATCHDOG]: {msg}")

def check_api_status():
    import socket
    push_step("正在檢查神經網絡 (API 8005) 狀態...")
    try:
        # 檢查 8005 埠位
        with socket.create_connection(("127.0.0.1", 8005), timeout=2):
            push_step("✅ 神經網絡連線正常。")
            return True
    except:
        push_step("⚠️ 偵測到大腦停滯 (API 8005 斷線)。")
        return False

def check_syntax():
    push_step("正在檢查核心模組語法完整性...")
    files = ["telegram_bot.py", "gui_app.py", "brain/executor.py", "brain/skills.py"]
    for f in files:
        if not os.path.exists(f): continue
        r = subprocess.run([sys.executable, "-m", "py_compile", f], capture_output=True)
        if r.returncode != 0:
            push_step(f"❌ 偵測到基因缺陷 ({f})! 嘗試隔離中...")
            return False
    return True

def monitor_logs():
    for name, path in LOGS.items():
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    # 只讀取最後 1000 字元以節省效能
                    f.seek(0, os.SEEK_END)
                    size = f.tell()
                    f.seek(max(0, size - 1000))
                    content = f.read()
                    
                    if "Conflict" in content or "SyntaxError" in content or "Traceback" in content:
                        push_step(f"⚠️ 偵測到 {name} 發生異常。執行自癒指令...")
                        if name == "TELEGRAM":
                            subprocess.run(["pkill", "-9", "-f", "telegram_bot.py"])
                            subprocess.Popen([sys.executable, "telegram_bot.py"], stdout=open(path, "a"), stderr=subprocess.STDOUT)
                        elif name == "SCHEDULER":
                            subprocess.run(["pkill", "-9", "-f", "brain/scheduler.py"])
                            subprocess.Popen([sys.executable, "brain/scheduler.py"], stdout=open(path, "a"), stderr=subprocess.STDOUT)
                        
                        # 清除日誌以避免重複觸發
                        open(path, "w").write(f"--- 系統自癒重啟於 {datetime.now()} ---\n")
            except:
                pass

def main_loop():
    push_step("上帝模式 - 自癒核心已啟動。")
    while True:
        try:
            check_api_status()
            if check_syntax():
                monitor_logs()
            time.sleep(30) # 每 30 秒巡檢一次
        except Exception as e:
            print(f"Watchdog Error: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main_loop()
