import logging
import os
import json
import asyncio
import threading
import time
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ChatAction
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler
from brain.executor import run_agent_query
from brain.core import get_config
from brain.master import get_skill_tree_data
from brain.history import get_due_tasks, update_task_runtime
from brain.skills import TacticalRelay
import re

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

LAST_CHAT_ID = None # 用於主動推送

async def post_init(application):
    commands = [
        ("start", "⚡ 啟動並初始化連線"),
        ("restart", "🔄 遠端重啟 Bot 核心服務"),
        ("new", "🧹 清除當前對話記憶 (重置)"),
        ("status", "📊 系統實時性能與負載觀測"),
        ("skills", "🌌 查看 Agent 當前技能樹"),
        ("logs", "📜 查看最新戰術日誌 (上帝之眼)"),
        ("sh", "🐚 執行遠端 Shell 指令 (管理員)"),
        ("config", "⚙️ 查看核心推理參數配置"),
        ("broadcast", "📢 向全系統發送廣播訊息"),
        ("help", "❓ 取得指令與操作說明")
    ]
    await application.bot.set_my_commands(commands)
    # 啟動背景進化監控
    asyncio.create_task(background_intelligence_loop(application))

async def background_intelligence_loop(application):
    """【進化引擎】每 60 秒檢查定時任務與系統進化狀態"""
    global LAST_CHAT_ID
    while True:
        try:
            tasks = get_due_tasks()
            for tid, name, query, interval in tasks:
                if LAST_CHAT_ID:
                    print(f"🚀 [AUTO_TASK]: 正在執行定時任務「{name}」...")
                    res = await run_agent_query(f"【定時任務執行: {name}】: {query}")
                    await application.bot.send_message(chat_id=LAST_CHAT_ID, text=f"🔔 **定時任務回報: {name}**\n\n{res}", parse_mode='Markdown')
                    update_task_runtime(tid, interval)
        except Exception as e:
            print(f"❌ [BG_LOOP_ERROR]: {str(e)}")
        await asyncio.sleep(60)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global LAST_CHAT_ID
    LAST_CHAT_ID = update.effective_chat.id
    kbd = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 重新生成", callback_data="regen"), 
         InlineKeyboardButton("🧹 清空記憶", callback_data="new_start")],
        [InlineKeyboardButton("📊 系統狀態", callback_data="status"),
         InlineKeyboardButton("🌌 技能樹", callback_data="skills")]
    ])
    await update.effective_message.reply_text(
        "⚡️ **神之腦連線已建立。**\n\n主控官，我是您的頂級戰術助理 **TopAgnet**。\n人格：【Hermes Elite】已激活。\n請下達戰略指令或使用下方菜單：",
        reply_markup=kbd,
        parse_mode='Markdown'
    )

async def cmd_new(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from brain.history import append_to_shared_history
    # 這裡清空歷史邏輯可以更細緻
    await update.effective_message.reply_text("🔄 **戰略記憶已重置。**")

async def cmd_skills(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tree_data = get_skill_tree_data()
    skill_text = "🌌 **TOP Agnet 進化技能樹**\n"
    skill_text += "----------------------------\n"
    for cat, ss in tree_data.items():
        skill_text += f"\n**{cat}**\n"
        for s in ss: skill_text += f"  ├─ {s}\n"
    await update.effective_message.reply_text(skill_text, parse_mode='Markdown')

async def cmd_restart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """【遠端管理】重啟 Bot 進程"""
    import sys
    user_id = update.effective_user.id
    master_id = get_config().get("master_user_id")
    if str(user_id) != str(master_id):
        await update.effective_message.reply_text("🚫 **權限不足**：僅限主控官可執行此核心重啟指令。")
        return
    await update.effective_message.reply_text("🔄 **系統正在進行戰術重啟...**\n核心引擎將在 3 秒內重新上線，請稍候。")
    
    # 使用更穩健的 Subprocess 方式重啟
    import subprocess
    script_path = os.path.abspath(__file__)
    python_path = sys.executable
    base_dir = os.path.dirname(script_path)
    
    # 啟動新進程，並脫離目前終端 (nohup 效果)
    subprocess.Popen([python_path, script_path], cwd=base_dir, start_new_session=True)
    
    # 立即退出目前進程
    os._exit(0)

async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = (
        "🛠️ **TOP Agnet 戰術指令集**\n\n"
        "/start - 初始化連線並顯示問候\n"
        "/new - 清空歷史對話，開始全新對話\n"
        "/restart - 重啟 Bot 核心 (僅限管理員)\n"
        "/status - 顯示當前系統負載與 API 狀態\n"
        "/skills - 列出 Agent 目前具備的所有工具\n"
        "/logs - 獲取最後 20 行上帝之眼日誌\n"
        "/config - 查看當前 AI 核心配置參數\n"
        "/sh [指令] - 執行遠端系統指令 (限管理員)\n"
        "/broadcast [訊息] - 發送全域廣播通知\n\n"
        "📷 **多模態操作**：直接上傳影片或圖片，Agent 會自動進行視覺分析。"
    )
    await update.effective_message.reply_text(help_text, parse_mode='Markdown')

async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import psutil
    cpu = psutil.cpu_percent()
    mem = psutil.virtual_memory().percent
    status_text = (
        "📊 **系統實時狀態**\n"
        f"🖥️ CPU 佔用: {cpu}%\n"
        f"🧠 記憶體佔用: {mem}%\n"
        "🌐 API 連線: 🟢 正常\n"
        f"🕐 伺服器時間: {datetime.now():%H:%M:%S}"
    )
    await update.effective_message.reply_text(status_text, parse_mode='Markdown')

async def cmd_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """【遠端監控】獲取上帝之眼日誌"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_path = os.path.join(base_dir, "brain", "recordings", "thinking.log") # 使用我剛剛在 core.py 修復的路徑
    if not os.path.exists(log_path):
        await update.effective_message.reply_text("❌ **錯誤**：找不到日誌檔案。")
        return
    with open(log_path, "r") as f:
        lines = f.readlines()[-20:] # 讀取最後 20 行
        log_text = "📜 **上帝之眼 — 戰術日誌 (末 20 行)**\n```\n" + "".join(lines) + "```"
        await update.effective_message.reply_text(log_text, parse_mode='Markdown')

async def cmd_sh(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """【高階管理】執行遠端 Shell 指令"""
    user_id = update.effective_user.id
    master_id = get_config().get("master_user_id")
    if str(user_id) != str(master_id):
        await update.effective_message.reply_text("🚫 **權限不足**")
        return
    cmd = " ".join(context.args)
    if not cmd:
        await update.effective_message.reply_text("❓ **用法**：`/sh [指令]`")
        return
    import subprocess
    try:
        res = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        out = res.stdout if res.stdout else res.stderr
        await update.effective_message.reply_text(f"🐚 **Shell 執行結果**：\n```\n{out[:4000]}```", parse_mode='Markdown')
    except Exception as e:
        await update.effective_message.reply_text(f"❌ **執行失敗**：{str(e)}")

async def cmd_config(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """【配置檢視】查看當前核心參數"""
    conf = get_config()
    cfg_text = (
        "⚙️ **Agnet 核心配置清單**\n"
        f"• 模型: `{conf.get('model')}`\n"
        f"• 溫度: `{conf.get('temperature', 0.7)}`\n"
        f"• 上下文長度: `{conf.get('max_tokens', 4096)}`\n"
        f"• 語系: `{conf.get('reply_lang', '繁體中文')}`"
    )
    await update.effective_message.reply_text(cfg_text, parse_mode='Markdown')

async def cmd_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """【全域廣播】向所有頻道發送通知"""
    msg = " ".join(context.args)
    if not msg:
        await update.effective_message.reply_text("❓ **用法**：`/broadcast [訊息內容]`")
        return
    await update.effective_message.reply_text(f"📢 **廣播已發送至戰術矩陣**：\n{msg}")

async def process_with_typing(update, context, user_text, attachment_path=None):
    global LAST_CHAT_ID
    chat_id = update.effective_chat.id
    LAST_CHAT_ID = chat_id
    
    # 🆕 1. [搶跑指令]: 在執行任何邏輯前，第一時間觸發原生 Typing 動畫
    try: await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)
    except: pass

    # 🆕 2. [優先任務]: 立即啟動不間斷 Typing 循環
    keep_typing = True
    async def typing_loop():
        while keep_typing:
            try: await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)
            except: pass
            await asyncio.sleep(3.8) # 稍微縮短間隔，確保動畫「無縫接力」
    typing_task = asyncio.create_task(typing_loop())

    # 3. 接下來才開始加載配置與準備數據
    cfg = get_config()
    timeout_val = float(cfg.get("tg_timeout_sec", 180.0))
    show_buttons = cfg.get("tg_show_quick_buttons", False) 
    filter_code = cfg.get("tg_filter_code", False)       

    current_step = "📡 準備戰術鏈路..."
    async def telegram_step_callback(step_text):
        nonlocal current_step
        current_step = step_text
        # 🆕 [戰術攔截]: 如果偵測到攔截信號，主動發送核准按鈕
        if "🛑 [INTERCEPT]" in step_text:
            c = get_config()
            act = c.get("pending_action", {})
            kbd = InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ 核准執行", callback_data=f"approve_action"),
                 InlineKeyboardButton("❌ 否決動作", callback_data=f"reject_action")]
            ])
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"🚧 **戰術動作攔截**\nAgnet 請求調用工具: `{act.get('tool')}`\n參數: `{act.get('args')}`\n\n請核准或否決此項操作：",
                reply_markup=kbd,
                parse_mode='Markdown'
            )

    msg_to_edit = None
    current_full_text = ""
    last_ui_update_t = 0 # 🆕 初始設為 0 以確保第一時間觸發建立
    
    async def telegram_stream_callback(text_chunk):
        nonlocal current_full_text, last_ui_update_t, msg_to_edit
        current_full_text += text_chunk
        
        now = time.time()
        # 🚀 [效能平衡]: 將更新頻率調至 0.8 秒，兼顧「打字感」與 Telegram API 限制
        # 並且在串流過程中即時過濾 <think> 標籤
        if now - last_ui_update_t > 0.8:
            if not current_full_text.strip(): return
            
            display_text = current_full_text
            if cfg.get("tg_filter_think", True):
                # 移除 think 區塊，若還在思考則顯示提示
                display_text = re.sub(r'<think>.*?(?:</think>|$)', '', display_text, flags=re.DOTALL)
            
            if filter_code: # 🆕 僅在顯式啟用時過濾
                display_text = re.sub(r'```[\s\S]*?```', '\n[📦 程式碼已隱藏]\n', display_text)
            
            if not display_text.strip() and "<think>" in current_full_text:
                display_text = "_🧠 AGNET 正在深層思考中..._"
            
            if not display_text.strip(): return # 真的沒東西就不傳

            try:
                if msg_to_edit is None:
                    msg_to_edit = await update.message.reply_text(display_text, parse_mode='Markdown')
                else:
                    await context.bot.edit_message_text(
                        chat_id=chat_id, 
                        message_id=msg_to_edit.message_id, 
                        text=display_text,
                        parse_mode='Markdown'
                    )
                last_ui_update_t = now
            except Exception as e:
                # 如果 Markdown 解析失敗，退回純文字模式
                try:
                    if msg_to_edit:
                        await context.bot.edit_message_text(
                            chat_id=chat_id, 
                            message_id=msg_to_edit.message_id, 
                            text=display_text
                        )
                except: pass
                last_ui_update_t = now

    try:
        response_text = await asyncio.wait_for(
            run_agent_query(
                user_text, 
                step_callback=telegram_step_callback,
                stream_callback=telegram_stream_callback, 
                attachment_path=attachment_path
            ),
            timeout=timeout_val
        )
        keep_typing = False
        if typing_task: typing_task.cancel()

        if not response_text or response_text.strip() == "":
            response_text = "⚠️ Agent 未回傳有效內容，請再試一次或檢查 vLLM 服務狀態。"
        
        import re
        if cfg.get("tg_filter_think", True):
            response_text = re.sub(r'<think>.*?</think>', '', response_text, flags=re.DOTALL)
        
        # 🆕 過濾所有戰術指令標籤 (相容有冒號與無冒號格式)
        response_text = re.sub(r'\[[A-Z0-9_]+(:.*?)?\]', '', response_text).strip()
        
        if filter_code:
            response_text = re.sub(r'```[\s\S]*?```', '\n[📦 程式碼區塊已根據設定隱藏]\n', response_text)
        if cfg.get("tg_filter_garbled", True):
            response_text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', response_text)
        if cfg.get("tg_filter_empty_lines", False):
            response_text = re.sub(r'\n{3,}', '\n\n', response_text)
            
        response_text = response_text.strip()
        if not response_text: response_text = "⚠️ 內容過濾後為空。"

        # 戰術快捷按鈕 (根據配置決定是否顯示)
        kbd = None  # 預設初始化為 None
        if show_buttons:
            kbd = InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 重新生成", callback_data="regen"), 
                 InlineKeyboardButton("🧹 清空記憶", callback_data="new_start")],
                [InlineKeyboardButton("📊 系統狀態", callback_data="status"),
                 InlineKeyboardButton("🌌 技能樹", callback_data="skills")]
            ])

        vid_match = re.search(r"\[VIDEO:(.+?)\]", response_text)
        img_match = re.search(r"\[IMAGE:(.+?)\]", response_text)

        if vid_match and os.path.exists(vid_match.group(1)):
            if msg_to_edit: await context.bot.delete_message(chat_id, msg_to_edit.message_id)
            await update.message.reply_video(video=open(vid_match.group(1), 'rb'), caption="🎬 戰術錄影回傳", reply_markup=kbd)
        elif img_match and os.path.exists(img_match.group(1)):
            if msg_to_edit: await context.bot.delete_message(chat_id, msg_to_edit.message_id)
            await update.message.reply_photo(photo=open(img_match.group(1), 'rb'), caption="📸 實時截圖", reply_markup=kbd)
        else:
            final_text = response_text if len(response_text) <= 4000 else response_text[:4000]
            if msg_to_edit:
                try:
                    await context.bot.edit_message_text(
                        chat_id=chat_id, 
                        message_id=msg_to_edit.message_id, 
                        text=final_text, 
                        parse_mode='Markdown',
                        reply_markup=kbd
                    )
                except:
                    await context.bot.edit_message_text(chat_id=chat_id, message_id=msg_to_edit.message_id, text=final_text, reply_markup=kbd)
            else:
                try: await update.message.reply_text(final_text, parse_mode='Markdown', reply_markup=kbd)
                except: await update.message.reply_text(final_text, reply_markup=kbd)

    except asyncio.TimeoutError:
        keep_typing = False
        if typing_task: typing_task.cancel()
        await update.message.reply_text(f"⏰ 神之腦思考超時（{timeout_val}秒）。vLLM 可能負載過高，請稍後再試或簡化指令。")
    except Exception as e:
        keep_typing = False
        if typing_task: typing_task.cancel()
        await update.message.reply_text(f"❌ 異常：{str(e)}")

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.text: return
    await process_with_typing(update, context, update.message.text)

async def handle_media_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    user_text = msg.caption if msg.caption else "請幫我分析這個檔案"
    file_obj = None; ext = ".dat"
    if msg.photo: file_obj = await msg.photo[-1].get_file(); ext = ".jpg"
    elif msg.video: file_obj = await msg.video.get_file(); ext = ".mp4"
    elif msg.video_note: file_obj = await msg.video_note.get_file(); ext = ".mp4"
    elif msg.document: file_obj = await msg.document.get_file(); ext = os.path.splitext(msg.document.file_name)[1]
    
    if file_obj:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        save_dir = os.path.join(base_dir, "brain", "recordings")
        os.makedirs(save_dir, exist_ok=True)
        target_path = os.path.join(save_dir, f"tg_upload_{int(time.time())}{ext}")
        await file_obj.download_to_drive(target_path)
        await process_with_typing(update, context, user_text, attachment_path=target_path)
    else:
        await msg.reply_text("❌ 無法解析此檔案類型。")

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer()
    if query.data == "regen":
        await query.message.reply_text("🔄 **正在重新執行最後一項戰術指令...**")
    elif query.data == "new_start":
        await cmd_new(update, context)
    elif query.data == "status":
        await cmd_status(update, context)
    elif query.data == "skills":
        await cmd_skills(update, context)
    elif query.data == "approve_action":
        c = get_config(); c["action_status"] = "APPROVED"; 
        from brain.core import save_config
        save_config(c)
        await query.message.edit_text("✅ **已核准執行。** 戰術進程繼續...")
    elif query.data == "reject_action":
        c = get_config(); c["action_status"] = "REJECTED"; 
        from brain.core import save_config
        save_config(c)
        await query.message.edit_text("❌ **已否決動作。** 戰術進程中斷。")

if __name__ == "__main__":
    conf = get_config(); token = conf.get("tg_token", "")
    if token:
        app = ApplicationBuilder().token(token).post_init(post_init).build()
        app.add_handler(CommandHandler("start", start))
        app.add_handler(CommandHandler("new", cmd_new))
        app.add_handler(CommandHandler("skills", cmd_skills))
        app.add_handler(CommandHandler("restart", cmd_restart))
        app.add_handler(CommandHandler("status", cmd_status))
        app.add_handler(CommandHandler("logs", cmd_logs))
        app.add_handler(CommandHandler("sh", cmd_sh))
        app.add_handler(CommandHandler("config", cmd_config))
        app.add_handler(CommandHandler("broadcast", cmd_broadcast))
        app.add_handler(CommandHandler("help", cmd_help))
        app.add_handler(CallbackQueryHandler(handle_callback))
        app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_text_message))
        app.add_handler(MessageHandler(filters.PHOTO | filters.VIDEO | filters.VIDEO_NOTE | filters.Document.ALL | filters.VOICE, handle_media_message))
        app.run_polling()
