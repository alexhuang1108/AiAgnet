# 💠 TOP Agnet 專業安裝精靈核心邏輯 (v4.2.0)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$baseDir = Get-Location
Clear-Host

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "      💠 TOP Agnet 巔峰自主進化戰略終端 - 安裝精靈" -ForegroundColor White
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# 1. 偵測環境
Write-Host "[1/4] 正在診斷系統環境..." -ForegroundColor Yellow
$pythonCheck = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCheck) {
    Write-Host "❌ 錯誤：找不到 Python 環境！" -ForegroundColor Red
    Write-Host "理由：TOP Agnet 需要 Python 3.10+ 作為運算大腦。"
    Write-Host "正在為您開啟下載頁面，請安裝後重新執行此程式。"
    Start-Process "https://www.python.org/downloads/"
    exit
}
Write-Host "✅ Python 環境偵測正常。" -ForegroundColor Green

# 2. 選擇安裝路徑
Write-Host ""
Write-Host "[2/4] 選擇安裝部署路徑..." -ForegroundColor Yellow
Write-Host "預設路徑: $baseDir"
$choice = Read-Host "是否更改安裝目錄? (Y/N, 預設為 N)"
$installPath = $baseDir

if ($choice -eq "Y" -or $choice -eq "y") {
    $folderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
    $folderBrowser.Description = "請選擇 TOP Agnet 的安裝資料夾"
    if ($folderBrowser.ShowDialog() -eq "OK") {
        $installPath = $folderBrowser.SelectedPath
        Write-Host "已選擇新路徑: $installPath" -ForegroundColor Cyan
        
        # 搬移檔案
        Write-Host "正在搬移戰術檔案到新路徑..." -ForegroundColor Gray
        Copy-Item -Path "$baseDir\*" -Destination $installPath -Recurse -Force
    }
}

# 3. 安裝依賴庫並解釋
Write-Host ""
Write-Host "[3/4] 正在配置戰術組件 (這可能需要幾分鐘)..." -ForegroundColor Yellow
Set-Location $installPath

Write-Host "📦 建立虛擬環境 (venv)..." -ForegroundColor Cyan
Write-Host "💡 說明：這就像是幫程式蓋一間專屬房間，避免跟您電腦的其他軟體衝突。"
python -m venv venv

Write-Host "🚀 下載戰術依賴庫 (Requirements)..." -ForegroundColor Cyan
Write-Host "💡 說明：我們正在下載 AI 所需的計算庫與網路通訊模組。"
& "$installPath\venv\Scripts\python.exe" -m pip install --upgrade pip | Out-Null
& "$installPath\venv\Scripts\pip.exe" install -r requirements.txt

Write-Host "🌐 配置 Playwright 偵查引擎..." -ForegroundColor Cyan
Write-Host "💡 說明：這是 AI 的『眼睛』，讓它能看懂網頁並自動抓取資料。"
& "$installPath\venv\Scripts\playwright.exe" install chromium

# 4. 建立捷徑
Write-Host ""
Write-Host "[4/4] 正在建立桌面快捷方式..." -ForegroundColor Yellow
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$HOME\Desktop\TOP Agnet 指揮中心.lnk")
$Shortcut.TargetPath = "$installPath\launch_windows.bat"
$Shortcut.WorkingDirectory = "$installPath"
$Shortcut.IconLocation = "$installPath\favicon.ico" # 如果有圖示的話
$Shortcut.Save()

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host " 🎉 安裝完成！TOP Agnet 已經準備就緒。" -ForegroundColor White
Write-Host " 您現在可以關閉此視窗，並從桌面捷徑開啟指揮中心。"
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
