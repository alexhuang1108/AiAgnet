#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中華職棒賽程查詢工具
功能：查詢指定日期 CPBL 賽程與戰況
"""

import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

class CPBLQueryTool:
    """中華職棒賽程查詢工具"""
    
    def __init__(self):
        self.base_url = "https://www.cpbl.com.tw"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def get_schedule(self, date=None):
        """
        查詢指定日期賽程
        
        Args:
            date: 日期格式 "2026-05-03" (預設今天)
        
        Returns:
            dict: 包含賽程資訊的字典
        """
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        
        url = f"{self.base_url}/schedule/{date}"
        
        try:
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            games = []
            for game in soup.select('.game-item'):
                match_data = {
                    'home': game.select_one('.home-team').text.strip(),
                    'away': game.select_one('.away-team').text.strip(),
                    'time': game.select_one('.game-time').text.strip() if game.select_one('.game-time') else '待定',
                    'score': game.select_one('.score').text.strip() if game.select_one('.score') else '進行中',
                    'status': '進行中' if '進行中' in str(game) else '已结束'
                }
                games.append(match_data)
            
            return {
                'date': date,
                'total_games': len(games),
                'games': games
            }
            
        except Exception as e:
            return {'error': str(e), 'date': date}
    
    def get_results_summary(self, date=None):
        """
        查詢指定日期戰況摘要
        
        Args:
            date: 日期格式 "2026-05-03" (預設今天)
        
        Returns:
            dict: 包含戰況摘要的字典
        """
        schedule = self.get_schedule(date)
        
        if 'error' in schedule:
            return schedule
        
        summary = {
            'date': date,
            'total_games': schedule['total_games'],
            'home_wins': 0,
            'away_wins': 0,
            'total_runs': 0,
            'games': []
        }
        
        for game in schedule['games']:
            if game['status'] == '已结束':
                # 解析比分
                home_score = int(game['score'].split(':')[0]) if ':' in game['score'] else 0
                away_score = int(game['score'].split(':')[1]) if ':' in game['score'] else 0
                
                summary['total_runs'] += home_score + away_score
                
                if home_score > away_score:
                    summary['home_wins'] += 1
                else:
                    summary['away_wins'] += 1
                
                summary['games'].append({
                    'teams': f"{game['away']} {away_score} : {home_score} {game['home']}",
                    'result': '主場勝' if home_score > away_score else '客場勝'
                })
        
        return summary

# 使用範例
if __name__ == "__main__":
    query = CPBLQueryTool()
    
    # 查詢 2026年5月3日賽程
    schedule = query.get_schedule("2026-05-03")
    print("📅 賽程查詢結果:")
    print(f"日期：{schedule.get('date')}")
    print(f"總場數：{schedule.get('total_games')}")
    print("-" * 30)
    
    for i, game in enumerate(schedule.get('games', []), 1):
        print(f"比賽{i}: {game['away']} vs {game['home']}")
        print(f"  時間：{game['time']}")
        print(f"  比分：{game['score']}")
        print(f"  狀態：{game['status']}")
        print("-" * 30)
    
    # 查詢戰況摘要
    summary = query.get_results_summary("2026-05-03")
    print("\n📊 戰況摘要:")
    print(f"總場數：{summary.get('total_games')}")
    print(f"主場勝：{summary.get('home_wins')}")
    print(f"客場勝：{summary.get('away_wins')}")
    print(f"總得分：{summary.get('total_runs')}")