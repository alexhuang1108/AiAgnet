import requests

def get_weather(city_name, api_key="YOUR_API_KEY"):
    """
    查詢指定城市的天氣狀況
    使用 OpenWeatherMap API
    
    參數:
        city_name: 城市名稱（英文或中文）
        api_key: OpenWeatherMap API Key（需自行申請免費帳號）
    
    回傳:
        dict: 天氣資訊（溫度、天氣狀況、濕度、風速等）
    """
    url = "https://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": city_name,
        "appid": api_key,
        "units": "metric",
        "lang": "zh_tw"
    }
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        
        weather_info = {
            "city": data.get("name"),
            "temperature": data.get("main", {}).get("temp"),
            "feels_like": data.get("main", {}).get("feels_like"),
            "weather": data.get("weather", [{}])[0].get("description"),
            "humidity": data.get("main", {}).get("humidity"),
            "wind_speed": data.get("wind", {}).get("speed"),
            "pressure": data.get("main", {}).get("pressure"),
            "sunrise": data.get("sys", {}).get("sunrise"),
            "sunset": data.get("sys", {}).get("sunset")
        }
        
        return weather_info
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"發生未知錯誤: {str(e)}"}

def format_weather_report(weather_info):
    """
    格式化天氣報告，適合人類閱讀
    """
    if "error" in weather_info:
        return f"錯誤: {weather_info['error']}"
    
    city = weather_info["city"]
    temp = weather_info["temperature"]
    feels_like = weather_info["feels_like"]
    description = weather_info["weather"]
    humidity = weather_info["humidity"]
    wind_speed = weather_info["wind_speed"]
    
    return f"""
🌤 {city} 今日天氣狀況

🌡 溫度: {temp}°C (體感: {feels_like}°C)
🌦 狀況: {description}
💧 濕度: {humidity}%
💨 風速: {wind_speed} m/s

✅ 資料來源: OpenWeatherMap API
"""