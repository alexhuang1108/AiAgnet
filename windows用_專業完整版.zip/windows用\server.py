from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os
import json
import asyncio
import subprocess
import pyautogui
from typing import List, Optional
from datetime import datetime

# 導入我們的核心腦
from agents import Runner
from brain.master import get_master_agent
from brain.skills import skill_manager

app = FastAPI(title="God Brain CGI Platform")

# 允許跨域請求
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str
    history: List[dict]
    api_key: Optional[str] = None
    model: Optional[str] = "gpt-4o"

class ExecutionLog:
    logs = []

recording_proc = None

@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest):
    if req.api_key:
        os.environ["OPENAI_API_KEY"] = req.api_key
    
    runner = Runner()
    agent = get_master_agent()
    
    # 這裡我們模擬執行步驟日誌
    ExecutionLog.logs.append(f"🚀 接收指令: {req.message[:30]}...")
    
    try:
        # 使用非同步包裝執行 Swarm (因為 Swarm 目前是同步的)
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None, 
            lambda: runner.run(starting_agent=agent, input=req.history + [{"role": "user", "content": req.message}])
        )
        
        final_message = response.messages[-1]["content"]
        ExecutionLog.logs.append("✅ 任務執行完成。")
        
        return {
            "reply": final_message,
            "history": response.messages,
            "skills": [t.__name__ for t in skill_manager.get_tool_list()]
        }
    except Exception as e:
        ExecutionLog.logs.append(f"❌ 錯誤: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/skills")
async def get_skills():
    return {"skills": [t.__name__ for t in skill_manager.get_tool_list()]}

@app.get("/api/logs")
async def get_logs():
    return {"logs": ExecutionLog.logs[-10:]} # 只返回最後 10 條

# 📸 [戰情拍照 API]
@app.post("/api/snapshot")
async def snapshot():
    os.makedirs("web/snapshots", exist_ok=True)
    filename = f"snap_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
    path = f"web/snapshots/{filename}"
    try:
        # 使用 pyautogui 截圖
        pyautogui.screenshot(path)
        ExecutionLog.logs.append(f"📸 戰情拍照成功: {filename}")
        return {"status": "success", "path": f"/static/snapshots/{filename}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

# 🎬 [實體錄影 API]
@app.post("/api/record/start")
async def record_start():
    global recording_proc
    if recording_proc: return {"status": "already_running"}
    
    os.makedirs("web/records", exist_ok=True)
    filename = f"rec_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
    path = f"web/records/{filename}"
    
    # 啟動 ffmpeg 錄製全螢幕 (1920x1080)
    cmd = [
        "ffmpeg", "-y", "-f", "gdigrab", "-framerate", "30", "-i", "desktop", 
        "-c:v", "libx264", "-preset", "ultrafast", path
    ]
    try:
        recording_proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        ExecutionLog.logs.append(f"🎬 開始錄製實體影像: {filename}")
        return {"status": "started", "path": f"/static/records/{filename}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/record/stop")
async def record_stop():
    global recording_proc
    if not recording_proc: return {"status": "not_running"}
    
    try:
        recording_proc.terminate()
        recording_proc.wait(timeout=5)
        recording_proc = None
        ExecutionLog.logs.append("⏹️ 錄製結束，檔案已存檔。")
        return {"status": "stopped"}
    except Exception as e:
        if recording_proc: recording_proc.kill()
        recording_proc = None
        return {"status": "error", "message": str(e)}

# 服務靜態檔案 (前端)
@app.get("/")
async def read_index():
    return FileResponse('web/index.html')

app.mount("/static", StaticFiles(directory="web"), name="static")

if __name__ == "__main__":
    import uvicorn
    # 確保目錄存在
    os.makedirs("web", exist_ok=True)
    uvicorn.run(app, host="0.0.0.0", port=8000)
