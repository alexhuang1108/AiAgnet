# --- 戰術神經中繼器 (Tactical Nerve Relay) ---
import sys

# 🛡️ [神級單例鏈路]: 確保全域唯一性
if not hasattr(sys, "_agnet_global_relay"):
    sys._agnet_global_relay = {
        "step": None,
        "hud": None,
        "progress": None
    }

class TacticalRelay:
    @classmethod
    def set_callback(cls, cb): sys._agnet_global_relay["step"] = cb
    @classmethod
    def set_hud_callback(cls, cb): sys._agnet_global_relay["hud"] = cb
    @classmethod
    def set_progress_callback(cls, cb): sys._agnet_global_relay["progress"] = cb

    @classmethod
    def push_step(cls, s):
        cb = sys._agnet_global_relay.get("step")
        if cb: cb(s)
        else: print(f"📡 [RELAY_STEP]: {s}")

    @classmethod
    def update_hud(cls, html):
        print(f"🖥️ [RELAY_HUD]: 正在推送數據 (長度: {len(html)})")
        cb = sys._agnet_global_relay.get("hud")
        if cb: cb(html)
        else: print("⚠️ [RELAY_WARN]: HUD 回調未就緒")

    @classmethod
    def update_progress(cls, val, label):
        print(f"📊 [RELAY_PROG]: {val}% - {label}")
        cb = sys._agnet_global_relay.get("progress")
        if cb: cb(val, label)
        else: print(f"⚠️ [RELAY_WARN]: 進度回調未就緒")
