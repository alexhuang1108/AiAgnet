import sys
import os
import time
import asyncio
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# 加入專案路徑
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from brain.executor import run_agent_query
from brain.core import get_config

WATCH_DIR = "/home/user/Desktop/專案/inbox"

class SemanticHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory:
            file_name = os.path.basename(event.src_path)
            if file_name.startswith("."): return # 忽略隱藏檔
            
            print(f"📂 [WATCHER]: 偵測到新文件 - {file_name}")
            asyncio.run_coroutine_threadsafe(
                self.process_file(event.src_path), 
                loop
            )

    async def process_file(self, file_path):
        name = os.path.basename(file_path)
        # 觸發 Agent 進行語義分析
        prompt = f"【語義監視器通知】我偵測到您在 inbox 資料夾放入了新文件：'{name}'。我現在就為您分析這份文件的內容並提取關鍵情報。"
        try:
            res = await run_agent_query(prompt, attachment_path=file_path)
            print(f"✅ [WATCHER_ANALYSIS_COMPLETE]: {name}")
        except Exception as e:
            print(f"❌ [WATCHER_ERROR]: {e}")

if __name__ == "__main__":
    os.makedirs(WATCH_DIR, exist_ok=True)
    print(f"哨兵模式啟動：正在監控 {WATCH_DIR}...")
    
    # 建立異步事件循環
    loop = asyncio.new_event_loop()
    import threading
    threading.Thread(target=loop.run_forever, daemon=True).start()
    
    event_handler = SemanticHandler()
    observer = Observer()
    observer.schedule(event_handler, WATCH_DIR, recursive=False)
    observer.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
