import sqlite3
import os
import json
from datetime import datetime

DB_PATH = "brain/memory.sqlite"

def init_db():
    """初始化大腦核心資料庫 (支援巔峰進化)"""
    os.makedirs("brain", exist_ok=True)
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    
    # 基礎與長期記憶
    cursor.execute("CREATE TABLE IF NOT EXISTS chat_history (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, content TEXT, timestamp DATETIME)")
    cursor.execute("CREATE TABLE IF NOT EXISTS memory_summaries (id INTEGER PRIMARY KEY AUTOINCREMENT, summary TEXT, timestamp DATETIME)")
    
    # 系統運作模式
    cursor.execute("CREATE TABLE IF NOT EXISTS operational_modes (mode_name TEXT PRIMARY KEY, description TEXT, active INTEGER DEFAULT 0)")
    
    # 初始化模式
    cursor.execute("INSERT OR IGNORE INTO operational_modes (mode_name, description, active) VALUES ('CRISIS', '戰時模式：極簡回報，最高效率', 0)")
    cursor.execute("INSERT OR IGNORE INTO operational_modes (mode_name, description, active) VALUES ('LEARNING', '學習模式：深度解析，詳細教學', 0)")
    cursor.execute("INSERT OR IGNORE INTO operational_modes (mode_name, description, active) VALUES ('SILENT', '靜默模式：非必要不打擾，僅記錄', 1)") # 預設靜默

    # 定時任務與知識庫
    cursor.execute("CREATE TABLE IF NOT EXISTS scheduled_tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, task_name TEXT, query TEXT, interval_minutes INTEGER, last_run DATETIME, next_run DATETIME, status TEXT DEFAULT 'ACTIVE')")
    cursor.execute("CREATE TABLE IF NOT EXISTS private_knowledge (id INTEGER PRIMARY KEY AUTOINCREMENT, file_path TEXT, content_summary TEXT, tags TEXT, last_indexed DATETIME)")
    
    # 安全日誌與週報
    cursor.execute("CREATE TABLE IF NOT EXISTS security_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT, detail TEXT, severity TEXT, timestamp DATETIME)")
    cursor.execute("CREATE TABLE IF NOT EXISTS weekly_legacy_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, week_number INTEGER, report_content TEXT, timestamp DATETIME)")

    # 進化日誌
    cursor.execute("CREATE TABLE IF NOT EXISTS evolution_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT, impact TEXT, timestamp DATETIME)")

    conn.commit(); conn.close()

def set_active_mode(mode):
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("UPDATE operational_modes SET active=0")
    cursor.execute("UPDATE operational_modes SET active=1 WHERE mode_name=?", (mode,))
    conn.commit(); conn.close()

def get_active_mode():
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("SELECT mode_name FROM operational_modes WHERE active=1")
    res = cursor.fetchone(); conn.close()
    return res[0] if res else "SILENT"

def load_shared_history(limit=50):
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("SELECT id, role, content FROM chat_history ORDER BY id DESC LIMIT ?", (limit,))
    rows = cursor.fetchall(); conn.close()
    return [{"id": r[0], "role": r[1], "content": r[2]} for r in reversed(rows)]

def append_to_shared_history(role, content):
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("INSERT INTO chat_history (role, content, timestamp) VALUES (?, ?, ?)", (role, content, datetime.now().isoformat()))
    conn.commit(); conn.close()

def save_memory_summary(summary):
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("INSERT INTO memory_summaries (summary, timestamp) VALUES (?, ?)", (summary, datetime.now().isoformat()))
    conn.commit(); conn.close()

def get_latest_memory_summary():
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("SELECT summary FROM memory_summaries ORDER BY id DESC LIMIT 1")
    res = cursor.fetchone(); conn.close()
    return res[0] if res else None

def add_scheduled_task(name, query, interval):
    init_db()
    from datetime import timedelta
    next_run = (datetime.now() + timedelta(minutes=interval)).isoformat()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("INSERT INTO scheduled_tasks (task_name, query, interval_minutes, next_run) VALUES (?, ?, ?, ?)", (name, query, interval, next_run))
    conn.commit(); conn.close()

def get_due_tasks():
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    now = datetime.now().isoformat()
    cursor.execute("SELECT id, task_name, query, interval_minutes FROM scheduled_tasks WHERE next_run <= ? AND status='ACTIVE'", (now,))
    rows = cursor.fetchall(); conn.close()
    return rows

def update_task_runtime(task_id, interval):
    init_db()
    from datetime import timedelta
    next_run = (datetime.now() + timedelta(minutes=interval)).isoformat()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("UPDATE scheduled_tasks SET last_run=?, next_run=? WHERE id=?", (datetime.now().isoformat(), next_run, task_id))
    conn.commit(); conn.close()

def upsert_private_knowledge(path, summary, tags):
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO private_knowledge (file_path, content_summary, tags, last_indexed) VALUES (?, ?, ?, ?)", (path, summary, tags, datetime.now().isoformat()))
    conn.commit(); conn.close()

def search_private_knowledge(query):
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("SELECT file_path, content_summary FROM private_knowledge WHERE content_summary LIKE ? OR tags LIKE ? LIMIT 5", (f"%{query}%", f"%{query}%"))
    rows = cursor.fetchall(); conn.close()
    return rows

def log_security_event(etype, detail, severity):
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("INSERT INTO security_logs (event_type, detail, severity, timestamp) VALUES (?, ?, ?, ?)", (etype, detail, severity, datetime.now().isoformat()))
    conn.commit(); conn.close()

def log_evolution(event, impact):
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("INSERT INTO evolution_logs (event, impact, timestamp) VALUES (?, ?, ?)", (event, impact, datetime.now().isoformat()))
    conn.commit(); conn.close()
def clear_all_history():
    """【物理級清除】徹底排空對話歷史與記憶摘要，確保系統進入絕對純淨狀態"""
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("DELETE FROM chat_history")
    cursor.execute("DELETE FROM memory_summaries")
    conn.commit(); conn.close()
    print("🧹 [DATABASE_WIPE]: 物理歷史已徹底排空。")

def get_historical_context(timestamp_str):
    """【時空溯源】獲取指定時間點的歷史對話與記憶狀態"""
    init_db()
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("SELECT role, content FROM chat_history WHERE timestamp <= ? ORDER BY timestamp DESC LIMIT 20", (timestamp_str,))
    history = cursor.fetchall()
    
    cursor.execute("SELECT summary FROM memory_summaries WHERE timestamp <= ? ORDER BY timestamp DESC LIMIT 1", (timestamp_str,))
    summary = cursor.fetchone()
    conn.close()
    
    hist_text = "\n".join([f"{r}: {c}" for r, c in history[::-1]])
    return {
        "history": hist_text,
        "summary": summary[0] if summary else "無歷史摘要"
    }
