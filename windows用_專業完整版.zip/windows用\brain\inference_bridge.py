
import sys
import os
import json
import time
from flask import Flask, request, Response, stream_with_context
from flask_cors import CORS
from llama_cpp import Llama

app = Flask(__name__)
CORS(app)

# 全域模型實例
llm = None
current_model_path = None

@app.route('/health', methods=['GET'])
def health():
    return json.dumps({"status": "ok", "model": current_model_path})

@app.route('/load', methods=['POST'])
def load_model():
    global llm, current_model_path
    data = request.json
    path = data.get("path")
    n_gpu_layers = data.get("gpu_layers", 35)
    n_ctx = data.get("ctx_size", 4096)
    n_threads = data.get("thread_count", 8)
    use_kv_quant = data.get("use_kv_quant", False)
    flash_attn = data.get("use_flash_attn", True)

    if not path or not os.path.exists(path):
        return json.dumps({"status": "error", "message": f"Path not found: {path}"}), 400

    try:
        print(f"📡 [BRIDGE]: Loading {path} (GPU={n_gpu_layers}, Threads={n_threads})...")
        tk = 2 if use_kv_quant else None
        llm = Llama(
            model_path=path,
            n_gpu_layers=n_gpu_layers,
            n_ctx=n_ctx,
            n_threads=n_threads,
            flash_attn=flash_attn,
            type_k=tk,
            type_v=tk,
            verbose=True
        )
        current_model_path = path
        return json.dumps({"status": "success", "message": "Model loaded into bridge environment."})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}), 500

@app.route('/generate', methods=['POST'])
def generate():
    global llm
    if not llm:
        return json.dumps({"status": "error", "message": "Model not loaded"}), 400
    
    data = request.json
    messages = data.get("messages", [])
    
    # 轉換格式
    prompt = ""
    for m in messages:
        role = m['role']
        content = m['content']
        prompt += f"<|im_start|>{role}\n{content}<|im_end|>\n"
    prompt += "<|im_start|>assistant\n"

    def stream_gen():
        try:
            output = llm(
                prompt,
                max_tokens=2048,
                stop=["<|im_end|>", "<|im_start|>", "USER:", "ASSISTANT:"],
                stream=True
            )
            for chunk in output:
                text = chunk['choices'][0]['text']
                yield text
        except Exception as e:
            yield f"\n❌ [BRIDGE_ERR]: {str(e)}"

    return Response(stream_with_context(stream_gen()), mimetype='text/plain')

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8006
    print(f"🚀 [INFERENCE_BRIDGE]: Starting on port {port}...")
    app.run(host='127.0.0.1', port=port, threaded=False) # Threaded=False for stability with llama.cpp
