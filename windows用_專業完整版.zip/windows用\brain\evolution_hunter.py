import os
import subprocess
import sys
import time

# 加入專案路徑
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from brain.skills import push_micro_step

def hunt_for_software():
    push_micro_step("🧠 [NEURAL_EXPANSION]: 正在掃描系統環境以尋找進化契機...")
    
    # 掃描常見工具
    tools = {
        "docker": "Docker 容器管理技能",
        "git": "版本控制深度整合技能",
        "nginx": "網頁伺服器監控技能",
        "ffmpeg": "多媒體處理強化技能"
    }
    
    found = []
    for cmd, skill in tools.items():
        if subprocess.run(["which", cmd], capture_output=True).returncode == 0:
            found.append(skill)
            
    if found:
        push_micro_step(f"💡 [EVOLUTION_ADVICE]: 偵測到環境中存在 {', '.join(found)}。")
        print(f"建議開發新技能以對齊：{found}")
    else:
        push_micro_step("✅ [NEURAL_EXPANSION]: 當前技能集與環境已高度對齊。")

if __name__ == "__main__":
    while True:
        hunt_for_software()
        time.sleep(3600) # 每小時掃描一次
