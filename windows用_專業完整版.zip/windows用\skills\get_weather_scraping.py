import requests
from bs4 import BeautifulSoup
from datetime import datetime

def get_weather_scraping(city="新北市"):
    """
    爬取台灣中央氣象局公開網頁獲取天氣資訊
    不需要 API Key，純網頁爬蟲方式
    """
    
    # 中央氣象局天氣預報頁面
    url = "https://weather.cwa.gov.tw"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 尋找天氣相關內容
        weather_info = {
            'city': city,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'data_source': '中央氣象局公開網頁',
            'note': '網頁爬蟲資料，建議以官方發布為準'
        }
        
        # 尋找溫度、天氣描述等資訊
        temperature_tags = soup.find_all(class_=['temp', 'temperature', 'temp-degree'])
        weather_tags = soup.find_all(class_=['condition', 'weather', 'weather-icon'])
        
        if temperature_tags:
            weather_info['temperature'] = temperature_tags[0].text.strip()
        
        if weather_tags:
            weather_info['weather_condition'] = weather_tags[0].text.strip()
        
        # 搜尋新北市相關資訊
        if '新北' in city or '台北' in city or '台灣' in city:
            # 嘗試從城市頁面獲取更詳細資料
            weather_url = "https://weather.cwa.gov.tw/cities"
            city_response = requests.get(weather_url, headers=headers, timeout=10)
            
            # 簡單返回可用的天氣資訊
            weather_info['status'] = 'success'
            weather_info['message'] = '已找到天氣資料'
            
        return weather_info
        
    except Exception as e:
        return {
            'status': 'error',
            'error_message': str(e),
            'city': city,
            'message': '爬蟲失敗，建議使用官方 API'
        }